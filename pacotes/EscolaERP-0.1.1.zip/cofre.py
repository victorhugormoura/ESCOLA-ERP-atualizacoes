"""ESCOLA-ERP — criptografia e senhas, só com a biblioteca padrão.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import base64
import hashlib
import hmac
import secrets

PREFIXO = 'enc1:'
SCRYPT_N = 2 ** 15
SCRYPT_R = 8
SCRYPT_P = 1
SCRYPT_MEM = 128 * 1024 * 1024


def _b64e(dados):
    return base64.urlsafe_b64encode(dados).decode('ascii')


def _b64d(texto):
    return base64.urlsafe_b64decode(texto.encode('ascii'))


def _derivar(segredo, salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P):
    return hashlib.scrypt(segredo.encode('utf-8'), salt=salt, n=n, r=r, p=p, maxmem=SCRYPT_MEM, dklen=32)


def hash_senha(senha):
    salt = secrets.token_bytes(16)
    return f'scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${_b64e(salt)}${_b64e(_derivar(senha, salt))}'


def conferir_senha(senha, guardado):
    try:
        _, n, r, p, salt, esperado = guardado.split('$')
        calculado = _derivar(senha, _b64d(salt), int(n), int(r), int(p))
    except (ValueError, AttributeError, TypeError):
        return False
    return hmac.compare_digest(calculado, _b64d(esperado))


class Cofre:
    """Fluxo SHAKE-256 com nonce aleatório e HMAC-SHA256 sobre nonce e texto cifrado."""

    def __init__(self, chave):
        if len(chave) != 32:
            raise ValueError('chave precisa ter 32 bytes')
        self.k_enc = hmac.new(chave, b'escola-erp/enc', hashlib.sha256).digest()
        self.k_mac = hmac.new(chave, b'escola-erp/mac', hashlib.sha256).digest()

    def cifrar_bytes(self, dados, contexto=b''):
        nonce = secrets.token_bytes(24)
        fluxo = hashlib.shake_256(self.k_enc + nonce).digest(len(dados)) if dados else b''
        cifrado = _xor(dados, fluxo) if dados else b''
        tag = hmac.new(self.k_mac, contexto + nonce + cifrado, hashlib.sha256).digest()
        return b'\x01' + nonce + cifrado + tag

    def decifrar_bytes(self, blob, contexto=b''):
        if len(blob) < 57 or blob[:1] != b'\x01':
            raise ValueError('dado cifrado inválido')
        nonce, cifrado, tag = blob[1:25], blob[25:-32], blob[-32:]
        esperado = hmac.new(self.k_mac, contexto + nonce + cifrado, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, esperado):
            raise ValueError('falha de integridade')
        if not cifrado:
            return b''
        return _xor(cifrado, hashlib.shake_256(self.k_enc + nonce).digest(len(cifrado)))

    def cifrar(self, texto):
        if texto is None or texto == '':
            return ''
        return PREFIXO + _b64e(self.cifrar_bytes(str(texto).encode('utf-8')))

    def decifrar(self, valor):
        if not isinstance(valor, str) or not valor.startswith(PREFIXO):
            return valor
        try:
            return self.decifrar_bytes(_b64d(valor[len(PREFIXO):])).decode('utf-8')
        except (ValueError, UnicodeDecodeError):
            return '[ilegível]'


def _xor(a, b):
    n = len(a)
    return (int.from_bytes(a, 'little') ^ int.from_bytes(b, 'little')).to_bytes(n, 'little')


def envelopar(chave, segredo):
    salt = secrets.token_bytes(16)
    return {'salt': _b64e(salt), 'blob': _b64e(Cofre(_derivar(segredo, salt)).cifrar_bytes(chave))}


def desenvelopar(envelope, segredo):
    salt = _b64d(envelope['salt'])
    return Cofre(_derivar(segredo, salt)).decifrar_bytes(_b64d(envelope['blob']))


def codigo_recuperacao():
    alfabeto = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    bruto = ''.join(secrets.choice(alfabeto) for _ in range(24))
    return '-'.join(bruto[i:i + 4] for i in range(0, 24, 4))


def token_api():
    return 'esc_' + secrets.token_urlsafe(32)


def hash_token(token):
    return hashlib.sha256(token.encode('utf-8')).hexdigest()
