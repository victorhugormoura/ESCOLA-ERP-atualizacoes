"""ESCOLA-ERP — cópia de segurança cifrada, para pasta, pen drive ou nuvem.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import base64
import datetime as dt
import hashlib
import json
import os
import re
import sqlite3
import tempfile
import urllib.error
import urllib.request
import zlib

import cofre as cf

MAGICA = b'ESCOLABKP1\n'
PADRAO = re.compile(r'escola-\d{8}-\d{6}\.bkp')
RETENCAO = 30


def gerar(banco_caminho, destino, chave, envelope=None):
    os.makedirs(destino, exist_ok=True)
    nome = f'escola-{dt.datetime.now():%Y%m%d-%H%M%S}.bkp'
    with tempfile.TemporaryDirectory() as pasta:
        copia = os.path.join(pasta, 'c.db')
        origem = sqlite3.connect(banco_caminho)
        alvo = sqlite3.connect(copia)
        with alvo:
            origem.backup(alvo)
        origem.close()
        alvo.close()
        with open(copia, 'rb') as f:
            bruto = f.read()
    cabecalho = json.dumps({'envelope': envelope}).encode('utf-8')
    blob = MAGICA + cabecalho + b'\n' + cf.Cofre(chave).cifrar_bytes(zlib.compress(bruto, 6), b'backup')
    final = os.path.join(destino, nome)
    temporario = final + '.tmp'
    with open(temporario, 'wb') as f:
        f.write(blob)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temporario, final)
    conferir(final, chave)
    podar(destino)
    return final


def _partes(caminho):
    with open(caminho, 'rb') as f:
        blob = f.read()
    if not blob.startswith(MAGICA):
        raise ValueError('arquivo não é backup do ESCOLA-ERP')
    cabecalho, _, cifrado = blob[len(MAGICA):].partition(b'\n')
    return json.loads(cabecalho), cifrado


def abrir(caminho, chave):
    return zlib.decompress(cf.Cofre(chave).decifrar_bytes(_partes(caminho)[1], b'backup'))


def chave_do_backup(caminho, codigo):
    """Recupera a chave em outra máquina com o código entregue na instalação."""
    return cf.desenvelopar(_partes(caminho)[0]['envelope'], codigo.strip().upper())


def conferir(caminho, chave):
    bruto = abrir(caminho, chave)
    with tempfile.TemporaryDirectory() as pasta:
        teste = os.path.join(pasta, 't.db')
        with open(teste, 'wb') as f:
            f.write(bruto)
        c = sqlite3.connect(teste)
        ok = c.execute('PRAGMA integrity_check').fetchone()[0]
        c.close()
    if ok != 'ok':
        raise ValueError('backup com banco corrompido')
    return hashlib.sha256(bruto).hexdigest()


def restaurar(caminho, chave, banco_caminho):
    """Guarda o banco atual pela API de backup do SQLite, que inclui o WAL, antes de trocar."""
    bruto = abrir(caminho, chave)
    conferir(caminho, chave)
    if os.path.exists(banco_caminho):
        antigo = sqlite3.connect(banco_caminho)
        copia = sqlite3.connect(banco_caminho + '.antes-da-restauracao')
        with copia:
            antigo.backup(copia)
        antigo.close()
        copia.close()
    temporario = banco_caminho + '.tmp'
    descritor = os.open(temporario, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(descritor, 'wb') as f:
        f.write(bruto)
        f.flush()
        os.fsync(f.fileno())
    for sufixo in ('-wal', '-shm'):
        if os.path.exists(banco_caminho + sufixo):
            os.remove(banco_caminho + sufixo)
    os.replace(temporario, banco_caminho)


def podar(pasta, manter=RETENCAO):
    nomes = sorted(n for n in os.listdir(pasta) if PADRAO.fullmatch(n))
    for nome in nomes[:-manter]:
        os.remove(os.path.join(pasta, nome))


def listar(pasta):
    if not os.path.isdir(pasta):
        return []
    return sorted((n for n in os.listdir(pasta) if PADRAO.fullmatch(n)), reverse=True)


def enviar_webdav(arquivo, url, usuario, senha, tempo=120):
    """Envia para Nextcloud ou outro WebDAV. Falha de rede só adia: a escola segue sem internet."""
    if not url.startswith(('https://', 'http://127.0.0.1')):
        raise ValueError('WebDAV exige https')
    with open(arquivo, 'rb') as f:
        dados = f.read()
    destino = url.rstrip('/') + '/' + os.path.basename(arquivo)
    pedido = urllib.request.Request(destino, data=dados, method='PUT')
    pedido.add_header('Authorization', 'Basic ' + base64.b64encode(f'{usuario}:{senha}'.encode()).decode())
    try:
        with urllib.request.urlopen(pedido, timeout=tempo) as r:
            return r.status in (200, 201, 204)
    except (urllib.error.URLError, OSError):
        return False
