"""ESCOLA-ERP — banco SQLite, esquema, trilha de auditoria e eventos.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import hashlib
import hmac
import json
import os
import sqlite3
import threading
import time
import uuid

VERSAO_ESQUEMA = 4
ZERO = '0' * 64
_local = threading.local()

ESQUEMA = """
CREATE TABLE config (chave TEXT PRIMARY KEY, valor TEXT NOT NULL);
CREATE TABLE usuario (
  id INTEGER PRIMARY KEY, login TEXT NOT NULL UNIQUE COLLATE NOCASE, nome TEXT NOT NULL,
  papel TEXT NOT NULL CHECK (papel IN ('direcao','secretaria','professor','coordenacao','aluno','responsavel','rede')),
  senha TEXT NOT NULL, pessoa_id INTEGER REFERENCES pessoa(id), ativo INTEGER NOT NULL DEFAULT 1,
  trocar_senha INTEGER NOT NULL DEFAULT 0, criado_em TEXT NOT NULL);
CREATE TABLE sessao (
  token_hash TEXT PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuario(id), csrf TEXT NOT NULL,
  criada_em REAL NOT NULL, visto_em REAL NOT NULL, aparelho TEXT NOT NULL DEFAULT '');
CREATE TABLE token_api (
  id INTEGER PRIMARY KEY, nome TEXT NOT NULL, token_hash TEXT NOT NULL UNIQUE, escopos TEXT NOT NULL,
  criado_em TEXT NOT NULL, ultimo_uso TEXT, ativo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE pessoa (
  id INTEGER PRIMARY KEY, uid TEXT NOT NULL UNIQUE, nome TEXT NOT NULL, nome_social TEXT NOT NULL DEFAULT '',
  nascimento TEXT, sexo TEXT NOT NULL DEFAULT '', cor_raca TEXT NOT NULL DEFAULT '', nacionalidade TEXT NOT NULL DEFAULT 'brasileira',
  naturalidade TEXT NOT NULL DEFAULT '', cpf TEXT NOT NULL DEFAULT '', nis TEXT NOT NULL DEFAULT '', id_inep TEXT NOT NULL DEFAULT '',
  endereco TEXT NOT NULL DEFAULT '', telefone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '',
  saude TEXT NOT NULL DEFAULT '', restricao_alimentar TEXT NOT NULL DEFAULT '', necessidade_especifica TEXT NOT NULL DEFAULT '',
  transporte TEXT NOT NULL DEFAULT '', eh_aluno INTEGER NOT NULL DEFAULT 0, eh_responsavel INTEGER NOT NULL DEFAULT 0,
  eh_servidor INTEGER NOT NULL DEFAULT 0, anonimizado INTEGER NOT NULL DEFAULT 0, criado_em TEXT NOT NULL);
CREATE INDEX pessoa_nome ON pessoa(nome);
CREATE TABLE vinculo (
  aluno_id INTEGER NOT NULL REFERENCES pessoa(id), responsavel_id INTEGER NOT NULL REFERENCES pessoa(id),
  parentesco TEXT NOT NULL DEFAULT 'responsável', legal INTEGER NOT NULL DEFAULT 1, PRIMARY KEY (aluno_id, responsavel_id));
CREATE TABLE ano_letivo (id INTEGER PRIMARY KEY, ano INTEGER NOT NULL UNIQUE, inicio TEXT NOT NULL, fim TEXT NOT NULL, encerrado INTEGER NOT NULL DEFAULT 0);
CREATE TABLE periodo (id INTEGER PRIMARY KEY, ano_id INTEGER NOT NULL REFERENCES ano_letivo(id), nome TEXT NOT NULL, ordem INTEGER NOT NULL,
  inicio TEXT NOT NULL, fim TEXT NOT NULL, fechado INTEGER NOT NULL DEFAULT 0, UNIQUE (ano_id, ordem));
CREATE TABLE dia_calendario (id INTEGER PRIMARY KEY, ano_id INTEGER NOT NULL REFERENCES ano_letivo(id), data TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('letivo','feriado','recesso','suspensao','planejamento')), descricao TEXT NOT NULL DEFAULT '',
  codigo_justificativa TEXT NOT NULL DEFAULT '', UNIQUE (ano_id, data));
CREATE TABLE componente (id INTEGER PRIMARY KEY, nome TEXT NOT NULL UNIQUE, area TEXT NOT NULL DEFAULT '');
CREATE TABLE habilidade (codigo TEXT PRIMARY KEY, descricao TEXT NOT NULL, etapa TEXT NOT NULL DEFAULT '', local INTEGER NOT NULL DEFAULT 0);
CREATE TABLE turma (id INTEGER PRIMARY KEY, ano_id INTEGER NOT NULL REFERENCES ano_letivo(id), nome TEXT NOT NULL,
  etapa TEXT NOT NULL CHECK (etapa IN ('infantil','fundamental','medio','eja','aee')), serie TEXT NOT NULL DEFAULT '',
  turno TEXT NOT NULL DEFAULT 'manhã', sala TEXT NOT NULL DEFAULT '', multisserie INTEGER NOT NULL DEFAULT 0, vagas INTEGER NOT NULL DEFAULT 40,
  UNIQUE (ano_id, nome));
CREATE TABLE turma_componente (id INTEGER PRIMARY KEY, turma_id INTEGER NOT NULL REFERENCES turma(id), componente_id INTEGER NOT NULL REFERENCES componente(id),
  professor_id INTEGER REFERENCES usuario(id), carga_horaria REAL NOT NULL DEFAULT 80, UNIQUE (turma_id, componente_id));
CREATE TABLE matricula (id INTEGER PRIMARY KEY, uid TEXT NOT NULL UNIQUE, codigo TEXT NOT NULL UNIQUE, aluno_id INTEGER NOT NULL REFERENCES pessoa(id),
  turma_id INTEGER NOT NULL REFERENCES turma(id), numero INTEGER NOT NULL DEFAULT 0,
  situacao TEXT NOT NULL DEFAULT 'cursando' CHECK (situacao IN ('cursando','transferido','abandono','falecido','aprovado','reprovado','remanejado')),
  entrada TEXT NOT NULL, saida TEXT, UNIQUE (aluno_id, turma_id));
CREATE INDEX matricula_turma ON matricula(turma_id);
CREATE TABLE transferencia (id INTEGER PRIMARY KEY, uid TEXT NOT NULL UNIQUE, matricula_id INTEGER REFERENCES matricula(id), sentido TEXT NOT NULL CHECK (sentido IN ('saida','chegada')),
  escola_outra TEXT NOT NULL DEFAULT '', estado TEXT NOT NULL DEFAULT 'pedida' CHECK (estado IN ('pedida','confirmada','cancelada')),
  data TEXT NOT NULL, pacote TEXT NOT NULL DEFAULT '');
CREATE TABLE aula (id INTEGER PRIMARY KEY, uid TEXT NOT NULL UNIQUE, turma_componente_id INTEGER NOT NULL REFERENCES turma_componente(id), data TEXT NOT NULL,
  horas REAL NOT NULL DEFAULT 1, conteudo TEXT NOT NULL DEFAULT '', habilidades TEXT NOT NULL DEFAULT '', professor_id INTEGER REFERENCES usuario(id),
  validada_por INTEGER REFERENCES usuario(id), validada_em TEXT, ocorreu_em TEXT NOT NULL, sincronizou_em TEXT NOT NULL);
CREATE INDEX aula_data ON aula(turma_componente_id, data);
CREATE TABLE presenca (aula_id INTEGER NOT NULL REFERENCES aula(id), matricula_id INTEGER NOT NULL REFERENCES matricula(id), presente INTEGER NOT NULL,
  justificativa TEXT NOT NULL DEFAULT '', ocorreu_em TEXT NOT NULL, sincronizou_em TEXT NOT NULL, aparelho TEXT NOT NULL DEFAULT '', PRIMARY KEY (aula_id, matricula_id));
CREATE TABLE pedido_alteracao (id INTEGER PRIMARY KEY, tabela TEXT NOT NULL, registro TEXT NOT NULL, novo TEXT NOT NULL, motivo TEXT NOT NULL,
  pedido_por INTEGER REFERENCES usuario(id), criado_em TEXT NOT NULL, estado TEXT NOT NULL DEFAULT 'pendente' CHECK (estado IN ('pendente','aprovado','recusado')),
  decidido_por INTEGER REFERENCES usuario(id), decidido_em TEXT);
CREATE TABLE avaliacao (id INTEGER PRIMARY KEY, turma_componente_id INTEGER NOT NULL REFERENCES turma_componente(id), periodo_id INTEGER NOT NULL REFERENCES periodo(id),
  nome TEXT NOT NULL, peso REAL NOT NULL DEFAULT 1, tipo TEXT NOT NULL DEFAULT 'regular' CHECK (tipo IN ('regular','recuperacao')), data TEXT);
CREATE TABLE nota (avaliacao_id INTEGER NOT NULL REFERENCES avaliacao(id), matricula_id INTEGER NOT NULL REFERENCES matricula(id), valor REAL,
  lancada_por INTEGER REFERENCES usuario(id), lancada_em TEXT NOT NULL, PRIMARY KEY (avaliacao_id, matricula_id));
CREATE TABLE parecer (id INTEGER PRIMARY KEY, matricula_id INTEGER NOT NULL REFERENCES matricula(id), periodo_id INTEGER NOT NULL REFERENCES periodo(id),
  campo TEXT NOT NULL DEFAULT 'geral', texto TEXT NOT NULL, autor_id INTEGER REFERENCES usuario(id), criado_em TEXT NOT NULL, UNIQUE (matricula_id, periodo_id, campo));
CREATE TABLE conselho (id INTEGER PRIMARY KEY, turma_id INTEGER NOT NULL REFERENCES turma(id), periodo_id INTEGER REFERENCES periodo(id), data TEXT NOT NULL, ata TEXT NOT NULL DEFAULT '', autor_id INTEGER REFERENCES usuario(id));
CREATE TABLE decisao_conselho (matricula_id INTEGER NOT NULL REFERENCES matricula(id), componente_id INTEGER NOT NULL REFERENCES componente(id), decisao TEXT NOT NULL CHECK (decisao IN ('aprovado','reprovado')),
  motivo TEXT NOT NULL, conselho_id INTEGER REFERENCES conselho(id), PRIMARY KEY (matricula_id, componente_id));
CREATE TABLE conteudo (id INTEGER PRIMARY KEY, turma_componente_id INTEGER NOT NULL REFERENCES turma_componente(id), titulo TEXT NOT NULL, corpo TEXT NOT NULL DEFAULT '',
  link TEXT NOT NULL DEFAULT '', habilidades TEXT NOT NULL DEFAULT '', publicado INTEGER NOT NULL DEFAULT 1, autor_id INTEGER REFERENCES usuario(id), criado_em TEXT NOT NULL);
CREATE TABLE plano_aula (id INTEGER PRIMARY KEY, turma_componente_id INTEGER NOT NULL REFERENCES turma_componente(id), semana TEXT NOT NULL, objetivos TEXT NOT NULL DEFAULT '',
  habilidades TEXT NOT NULL DEFAULT '', metodologia TEXT NOT NULL DEFAULT '', autor_id INTEGER REFERENCES usuario(id), criado_em TEXT NOT NULL);
CREATE TABLE sinal (id INTEGER PRIMARY KEY, hora TEXT NOT NULL, descricao TEXT NOT NULL DEFAULT '', duracao_s INTEGER NOT NULL DEFAULT 5, dias TEXT NOT NULL DEFAULT '12345', ativo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE ponto_registro (id INTEGER PRIMARY KEY, cpf_hash TEXT NOT NULL, data_hora TEXT NOT NULL, origem TEXT NOT NULL, UNIQUE (cpf_hash, data_hora));
CREATE TABLE documento (id INTEGER PRIMARY KEY, codigo TEXT NOT NULL UNIQUE, tipo TEXT NOT NULL, referencia TEXT NOT NULL, hash TEXT NOT NULL, emitido_por INTEGER REFERENCES usuario(id), emitido_em TEXT NOT NULL);
CREATE TABLE foto_censo (ano INTEGER PRIMARY KEY, data TEXT NOT NULL, dados TEXT NOT NULL);
CREATE TABLE evento_recebido (uid TEXT PRIMARY KEY, recebido_em TEXT NOT NULL);
CREATE TABLE pacote_rede (uid TEXT PRIMARY KEY, escola TEXT NOT NULL, gerado_em TEXT NOT NULL, importado_em TEXT NOT NULL, resumo TEXT NOT NULL);
CREATE TABLE auditoria (
  id INTEGER PRIMARY KEY, quando TEXT NOT NULL, usuario_id INTEGER, usuario TEXT NOT NULL, acao TEXT NOT NULL, tabela TEXT NOT NULL,
  registro TEXT NOT NULL, finalidade TEXT NOT NULL DEFAULT '', detalhe TEXT NOT NULL DEFAULT '', anterior TEXT NOT NULL, hash TEXT NOT NULL);
CREATE TRIGGER auditoria_sem_update BEFORE UPDATE ON auditoria BEGIN SELECT RAISE(ABORT, 'auditoria só aceita acréscimo'); END;
CREATE TRIGGER auditoria_sem_delete BEFORE DELETE ON auditoria BEGIN SELECT RAISE(ABORT, 'auditoria só aceita acréscimo'); END;
"""


MIGRACOES = {
    4: "ALTER TABLE turma_componente ADD COLUMN validado_ate TEXT;",
    3: """
CREATE INDEX presenca_matricula ON presenca(matricula_id);
CREATE INDEX avaliacao_tc ON avaliacao(turma_componente_id, periodo_id);
CREATE INDEX nota_matricula ON nota(matricula_id);
""",
    2: """
CREATE TABLE patrimonio (id INTEGER PRIMARY KEY, tombo TEXT NOT NULL UNIQUE, descricao TEXT NOT NULL, local TEXT NOT NULL DEFAULT '', origem TEXT NOT NULL DEFAULT '', valor REAL NOT NULL DEFAULT 0, situacao TEXT NOT NULL DEFAULT 'em uso');
CREATE TABLE almoxarifado (id INTEGER PRIMARY KEY, item TEXT NOT NULL UNIQUE, unidade TEXT NOT NULL DEFAULT 'un', saldo REAL NOT NULL DEFAULT 0, minimo REAL NOT NULL DEFAULT 0, validade TEXT);
CREATE TABLE movimento_estoque (id INTEGER PRIMARY KEY, item_id INTEGER NOT NULL REFERENCES almoxarifado(id), tipo TEXT NOT NULL CHECK (tipo IN ('entrada','saida')), quantidade REAL NOT NULL CHECK (quantidade>0), data TEXT NOT NULL, motivo TEXT NOT NULL DEFAULT '');
CREATE TABLE acervo (id INTEGER PRIMARY KEY, codigo TEXT NOT NULL UNIQUE, titulo TEXT NOT NULL, autor TEXT NOT NULL DEFAULT '', pnld INTEGER NOT NULL DEFAULT 0, exemplares INTEGER NOT NULL DEFAULT 1);
CREATE TABLE emprestimo (id INTEGER PRIMARY KEY, acervo_id INTEGER NOT NULL REFERENCES acervo(id), pessoa_id INTEGER NOT NULL REFERENCES pessoa(id), retirada TEXT NOT NULL, prazo TEXT, devolucao TEXT);
CREATE TABLE rota_transporte (id INTEGER PRIMARY KEY, nome TEXT NOT NULL UNIQUE, veiculo TEXT NOT NULL DEFAULT '', motorista TEXT NOT NULL DEFAULT '', turno TEXT NOT NULL DEFAULT '', rural INTEGER NOT NULL DEFAULT 1);
CREATE TABLE cardapio (id INTEGER PRIMARY KEY, data TEXT NOT NULL, refeicao TEXT NOT NULL DEFAULT 'merenda', descricao TEXT NOT NULL, servidas INTEGER NOT NULL DEFAULT 0, UNIQUE (data, refeicao));
CREATE TABLE ocorrencia (id INTEGER PRIMARY KEY, aluno_id INTEGER REFERENCES pessoa(id), data TEXT NOT NULL, tipo TEXT NOT NULL DEFAULT 'pedagogica', descricao TEXT NOT NULL, encaminhamento TEXT NOT NULL DEFAULT '');
CREATE TABLE lotacao (id INTEGER PRIMARY KEY, pessoa_id INTEGER NOT NULL REFERENCES pessoa(id), funcao TEXT NOT NULL, vinculo TEXT NOT NULL DEFAULT '', carga_semanal REAL NOT NULL DEFAULT 0, inicio TEXT, fim TEXT);
CREATE TABLE livro_caixa (id INTEGER PRIMARY KEY, data TEXT NOT NULL, programa TEXT NOT NULL DEFAULT 'PDDE', descricao TEXT NOT NULL, tipo TEXT NOT NULL CHECK (tipo IN ('entrada','saida')), valor REAL NOT NULL CHECK (valor>=0), documento TEXT NOT NULL DEFAULT '');
CREATE TABLE plano_individual (id INTEGER PRIMARY KEY, aluno_id INTEGER NOT NULL REFERENCES pessoa(id), versao INTEGER NOT NULL DEFAULT 1, estudo_de_caso TEXT NOT NULL DEFAULT '', objetivos TEXT NOT NULL DEFAULT '', recursos TEXT NOT NULL DEFAULT '', data TEXT NOT NULL);
""",
}


def agora():
    return time.strftime('%Y-%m-%dT%H:%M:%S%z')


def novo_uid():
    return str(uuid.uuid4())


class Banco:
    def __init__(self, caminho):
        self.caminho = caminho
        os.makedirs(os.path.dirname(os.path.abspath(caminho)), exist_ok=True)
        self.escrita = threading.RLock()
        self.chave_auditoria = b''
        self._preparar()
        if os.name != 'nt':
            os.chmod(caminho, 0o600)

    def conexao(self):
        conexoes = getattr(_local, 'conexoes', None)
        if conexoes is None:
            conexoes = _local.conexoes = {}
        c = conexoes.get(self.caminho)
        if c is None:
            c = sqlite3.connect(self.caminho, timeout=30, isolation_level=None)
            c.row_factory = sqlite3.Row
            c.execute('PRAGMA foreign_keys=ON')
            c.execute('PRAGMA journal_mode=WAL')
            c.execute('PRAGMA synchronous=FULL')
            conexoes[self.caminho] = c
        return c

    def fechar(self):
        c = getattr(_local, 'conexoes', {}).pop(self.caminho, None)
        if c is not None:
            c.close()

    def _preparar(self):
        c = self.conexao()
        versao = c.execute('PRAGMA user_version').fetchone()[0]
        if versao > VERSAO_ESQUEMA:
            raise RuntimeError('banco de versão mais nova que o programa')
        if versao == 0:
            c.executescript('BEGIN;' + ESQUEMA + 'PRAGMA user_version=1; COMMIT;')
            versao = 1
        for numero in range(versao + 1, VERSAO_ESQUEMA + 1):
            c.executescript('BEGIN;' + MIGRACOES[numero] + f'PRAGMA user_version={numero}; COMMIT;')

    def integro(self):
        return self.conexao().execute('PRAGMA quick_check').fetchone()[0] == 'ok'

    def um(self, sql, *args):
        return self.conexao().execute(sql, args).fetchone()

    def todos(self, sql, *args):
        return [dict(l) for l in self.conexao().execute(sql, args).fetchall()]

    def transacao(self):
        return _Transacao(self)

    def obter(self, chave, padrao=None):
        l = self.um('SELECT valor FROM config WHERE chave=?', chave)
        return json.loads(l[0]) if l else padrao

    def gravar(self, chave, valor):
        with self.transacao() as c:
            c.execute('INSERT INTO config VALUES (?,?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor',
                      (chave, json.dumps(valor, ensure_ascii=False)))

    def _selar(self, corpo):
        return hmac.new(self.chave_auditoria, corpo.encode('utf-8'), hashlib.sha256).hexdigest()

    def auditar(self, c, usuario, acao, tabela, registro, finalidade='', detalhe=''):
        anterior = c.execute('SELECT hash FROM auditoria ORDER BY id DESC LIMIT 1').fetchone()
        anterior = anterior[0] if anterior else ZERO
        quando = agora()
        uid, nome = (usuario or {}).get('id'), (usuario or {}).get('login', 'sistema')
        corpo = json.dumps([quando, uid, nome, acao, tabela, str(registro), finalidade, detalhe, anterior], ensure_ascii=False)
        c.execute('INSERT INTO auditoria (quando,usuario_id,usuario,acao,tabela,registro,finalidade,detalhe,anterior,hash) VALUES (?,?,?,?,?,?,?,?,?,?)',
                  (quando, uid, nome, acao, tabela, str(registro), finalidade, detalhe, anterior, self._selar(corpo)))

    def conferir_auditoria(self):
        """Devolve o id da primeira linha adulterada, ou None. Sem a chave, recalcular a cadeia não passa."""
        anterior = ZERO
        for l in self.conexao().execute('SELECT * FROM auditoria ORDER BY id'):
            corpo = json.dumps([l['quando'], l['usuario_id'], l['usuario'], l['acao'], l['tabela'], l['registro'],
                                l['finalidade'], l['detalhe'], anterior], ensure_ascii=False)
            if l['anterior'] != anterior or not hmac.compare_digest(self._selar(corpo), l['hash']):
                return l['id']
            anterior = l['hash']
        return None


class _Transacao:
    def __init__(self, banco):
        self.banco = banco

    def __enter__(self):
        self.banco.escrita.acquire()
        try:
            self.c = self.banco.conexao()
            self.c.execute('BEGIN IMMEDIATE')
        except BaseException:
            self.banco.escrita.release()
            raise
        return self.c

    def __exit__(self, tipo, valor, rastro):
        try:
            self.c.execute('COMMIT' if tipo is None else 'ROLLBACK')
        finally:
            self.banco.escrita.release()
        return False
