"""ESCOLA-ERP — planilhas e pacotes para sistemas oficiais e integrações.

As saídas de Censo e CMDEB são de conferência: o layout oficial muda por ano e precisa ser
confirmado na fonte antes de envio direto.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import csv
import datetime as dt
import hashlib
import html
import io
import json
import zipfile

import banco as bd
import regras
import servico


def xlsx(nome_aba, linhas):
    """Planilha XLSX mínima, com texto inline."""
    def coluna(i):
        s = ''
        i += 1
        while i:
            i, r = divmod(i - 1, 26)
            s = chr(65 + r) + s
        return s

    def celula(lin, col, v):
        ref = f'{coluna(col)}{lin}'
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return f'<c r="{ref}"><v>{v}</v></c>'
        return f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{html.escape("" if v is None else str(v), quote=False)}</t></is></c>'

    corpo = ''.join(f'<row r="{i}">' + ''.join(celula(i, j, v) for j, v in enumerate(l)) + '</row>' for i, l in enumerate(linhas, 1))
    planilha = f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>{corpo}</sheetData></worksheet>'
    tipos = ('<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
             '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
             '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
             '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
    livro = ('<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
             f'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="{html.escape(nome_aba)}" sheetId="1" r:id="rId1"/></sheets></workbook>')
    livro_rels = ('<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                  '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
    saida = io.BytesIO()
    with zipfile.ZipFile(saida, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', tipos)
        z.writestr('_rels/.rels', rels)
        z.writestr('xl/workbook.xml', livro)
        z.writestr('xl/_rels/workbook.xml.rels', livro_rels)
        z.writestr('xl/worksheets/sheet1.xml', planilha)
    return saida.getvalue()


class Oficial:
    def __init__(self, escola):
        self.e = escola
        self.b = escola.b

    def frequencia_mensal(self, ano, mes, usuario):
        """Conferência da frequência mensal em horas, por matrícula (base do SGP/CMDEB)."""
        servico.exigir(usuario, *servico.PAPEIS_GESTAO)
        de = f'{ano:04d}-{mes:02d}-01'
        ate = f'{ano + (mes == 12):04d}-{(mes % 12) + 1:02d}-01'
        linhas = [['CODIGO_INEP_ESCOLA', 'CODIGO_MATRICULA', 'ID_INEP_ESTUDANTE', 'NOME_ESTUDANTE', 'TURMA', 'ANO', 'MES', 'HORAS_OFERTADAS', 'HORAS_PRESENCA', 'PERCENTUAL']]
        inep = self.b.obter('escola', {}).get('inep', '')
        for m in self.b.todos("""SELECT m.id, m.codigo, p.nome, p.id_inep, t.nome AS turma FROM matricula m JOIN pessoa p ON p.id=m.aluno_id
                                 JOIN turma t ON t.id=m.turma_id ORDER BY t.nome, p.nome"""):
            presentes, ofertadas, percentual = self.e.frequencia_matricula(m['id'], de, (dt.date.fromisoformat(ate) - dt.timedelta(days=1)).isoformat())
            if ofertadas:
                linhas.append([inep, m['codigo'], m['id_inep'], m['nome'], m['turma'], ano, mes, ofertadas, presentes, percentual])
        return linhas

    def lista_presenca(self, de, ate, usuario):
        """Conferência bimestral do Sistema Presença: faixa de 4 a 18 anos incompletos."""
        servico.exigir(usuario, 'direcao', 'secretaria')
        cfg = self.e.cfg()
        referencia = dt.date.fromisoformat(ate)
        linhas = [['NIS', 'NOME', 'TURMA', 'IDADE', 'HORAS_OFERTADAS', 'HORAS_PRESENCA', 'PERCENTUAL', 'MINIMO', 'SITUACAO']]
        for m in self.b.todos("""SELECT m.id, p.nome, p.nis, p.nascimento, t.nome AS turma FROM matricula m JOIN pessoa p ON p.id=m.aluno_id
                                 JOIN turma t ON t.id=m.turma_id WHERE m.situacao='cursando' ORDER BY p.nome"""):
            if not m['nascimento']:
                continue
            idade = regras.idade_em(m['nascimento'], referencia)
            if not 4 <= idade < 18:
                continue
            presentes, ofertadas, percentual = self.e.frequencia_matricula(m['id'], de, ate)
            minimo = cfg['presenca_menor_6'] if idade < 6 else cfg['presenca_geral']
            situacao = 'sem aula no período' if percentual is None else ('baixa frequência' if percentual < minimo else 'regular')
            linhas.append([self.e.cofre.decifrar(m['nis']), m['nome'], m['turma'], idade, ofertadas, presentes, percentual, minimo, situacao])
        return linhas

    def conferencia_censo(self, usuario):
        """Pendências antes do Educacenso. Não é o arquivo oficial de migração."""
        servico.exigir(usuario, *servico.PAPEIS_GESTAO)
        pendencias = []
        escola = self.b.obter('escola', {})
        if len(str(escola.get('inep', ''))) != 8:
            pendencias.append({'item': 'Escola', 'problema': 'código INEP da escola deve ter 8 dígitos'})
        for a in self.b.todos("""SELECT p.nome, p.nascimento, p.sexo, p.cor_raca, p.id_inep, t.nome AS turma FROM matricula m JOIN pessoa p ON p.id=m.aluno_id
                                 JOIN turma t ON t.id=m.turma_id WHERE m.situacao='cursando'"""):
            for campo, rotulo in (('nascimento', 'data de nascimento'), ('sexo', 'sexo'), ('cor_raca', 'cor/raça')):
                if not a[campo]:
                    pendencias.append({'item': a['nome'], 'problema': f'sem {rotulo}', 'turma': a['turma']})
            if not a['id_inep']:
                pendencias.append({'item': a['nome'], 'problema': 'sem ID INEP (aluno novo pode ir sem)', 'turma': a['turma'], 'aviso': True})
        return pendencias

    def fotografar_censo(self, ano, data, usuario):
        servico.exigir(usuario, 'direcao', 'secretaria')
        dados = self.b.todos("""SELECT m.codigo, p.uid, p.nome, p.id_inep, t.nome AS turma, t.etapa, m.situacao FROM matricula m JOIN pessoa p ON p.id=m.aluno_id
                                JOIN turma t ON t.id=m.turma_id WHERE m.entrada<=? AND (m.saida IS NULL OR m.saida>?)""", data, data)
        with self.b.transacao() as c:
            c.execute('INSERT OR REPLACE INTO foto_censo VALUES (?,?,?)', (ano, data, json.dumps(dados, ensure_ascii=False)))
            self.b.auditar(c, usuario, 'foto', 'censo', ano, 'Censo Escolar', f'{len(dados)} matrículas em {data}')
        return {'matriculas': len(dados)}

    def oneroster(self, usuario):
        """Roster em CSV no formato de arquivos do OneRoster, para Moodle, Classroom e similares."""
        servico.exigir(usuario, 'direcao', 'secretaria', 'coordenacao')
        arquivos = {}

        def tabela(nome, cab, linhas):
            s = io.StringIO()
            w = csv.writer(s, lineterminator='\n')
            w.writerow(cab)
            linhas = _seguras(linhas)
            w.writerows(linhas)
            arquivos[nome] = s.getvalue()

        tabela('orgs.csv', ['sourcedId', 'status', 'name', 'type'], [['escola', 'active', self.b.obter('escola', {}).get('nome', ''), 'school']])
        turmas = self.b.todos('SELECT t.id, t.nome, a.ano FROM turma t JOIN ano_letivo a ON a.id=t.ano_id WHERE a.encerrado=0')
        tabela('classes.csv', ['sourcedId', 'status', 'title', 'schoolSourcedId', 'classType'],
               [[f't{t["id"]}', 'active', f'{t["nome"]} {t["ano"]}', 'escola', 'homeroom'] for t in turmas])
        ativos = self.b.todos("""SELECT m.id, p.uid, p.nome, m.turma_id FROM matricula m JOIN pessoa p ON p.id=m.aluno_id JOIN turma t ON t.id=m.turma_id
                                 JOIN ano_letivo a ON a.id=t.ano_id WHERE m.situacao='cursando' AND a.encerrado=0""")
        tabela('users.csv', ['sourcedId', 'status', 'enabledUser', 'orgSourcedIds', 'role', 'username', 'givenName', 'familyName'],
               [[a['uid'], 'active', 'true', 'escola', 'student', a['uid'][:8], a['nome'].split(' ')[0], ' '.join(a['nome'].split(' ')[1:])] for a in ativos])
        tabela('enrollments.csv', ['sourcedId', 'status', 'classSourcedId', 'schoolSourcedId', 'userSourcedId', 'role'],
               [[f'm{a["id"]}', 'active', f't{a["turma_id"]}', 'escola', a['uid'], 'student'] for a in ativos])
        tabela('manifest.csv', ['propertyName', 'value'], [['manifest.version', '1.0'], ['oneroster.version', '1.2'], ['file.orgs', 'bulk'], ['file.classes', 'bulk'], ['file.users', 'bulk'], ['file.enrollments', 'bulk']])
        saida = io.BytesIO()
        with zipfile.ZipFile(saida, 'w', zipfile.ZIP_DEFLATED) as z:
            for nome, texto in arquivos.items():
                z.writestr(nome, texto)
        with self.b.transacao() as c:
            self.b.auditar(c, usuario, 'exportar', 'oneroster', len(ativos), 'integração com ambiente de aprendizagem')
        return saida.getvalue()

    def importar_afd(self, texto, usuario):
        """Marcações do AFD (Portaria 671, Anexo V): tipo 3 (REP-C e REP-A) e tipo 7 (REP-P).
        Posições: NSR 1-9, tipo 10, data e hora 11-34, CPF 35-46. Guarda só o hash do CPF."""
        servico.exigir(usuario, 'direcao', 'secretaria')
        n, ignoradas = 0, 0
        with self.b.transacao() as c:
            for linha in texto.splitlines():
                if len(linha) < 46 or linha[9] not in '37':
                    ignoradas += 1
                    continue
                quando, cpf = linha[10:34], linha[34:46]
                try:
                    dt.datetime.fromisoformat(quando)
                except ValueError:
                    ignoradas += 1
                    continue
                if not cpf.isdigit():
                    ignoradas += 1
                    continue
                n += c.execute('INSERT OR IGNORE INTO ponto_registro (cpf_hash,data_hora,origem) VALUES (?,?,?)',
                               (hashlib.sha256(cpf.encode()).hexdigest(), quando, 'afd')).rowcount
            self.b.auditar(c, usuario, 'importar', 'ponto', n, 'controle de jornada', f'{ignoradas} linhas ignoradas')
        return {'importados': n, 'ignoradas': ignoradas}

    # ------------------------------------------------------------ pacote para a rede
    def pacote_rede(self, usuario, chave_rede):
        servico.exigir(usuario, 'direcao', 'secretaria')
        import cofre as cf
        hoje = dt.date.today()
        conteudo = {'versao': 1, 'uid': bd.novo_uid(), 'gerado_em': bd.agora(), 'escola': self.b.obter('escola', {}),
                    'matriculas': self.b.todos("""SELECT m.codigo, m.situacao, m.entrada, m.saida, p.uid AS pessoa, p.nome, p.nascimento, p.id_inep, t.nome AS turma, t.etapa
                                                  FROM matricula m JOIN pessoa p ON p.id=m.aluno_id JOIN turma t ON t.id=m.turma_id"""),
                    'frequencia': self.frequencia_mensal(hoje.year, hoje.month, usuario)}
        bruto = json.dumps(conteudo, ensure_ascii=False).encode('utf-8')
        with self.b.transacao() as c:
            self.b.auditar(c, usuario, 'pacote', 'rede', conteudo['uid'], 'envio de dados à secretaria de educação', f'{len(conteudo["matriculas"])} matrículas')
        return cf.Cofre(chave_rede).cifrar_bytes(zlib_comprimir(bruto), b'pacote-rede')

    def importar_pacote(self, blob, usuario, chave_rede):
        servico.exigir(usuario, 'rede', 'direcao')
        import cofre as cf
        try:
            conteudo = json.loads(zlib_abrir(cf.Cofre(chave_rede).decifrar_bytes(blob, b'pacote-rede')))
        except ValueError as e:
            raise servico.Erro('pacote inválido ou chave da rede errada') from e
        resumo = {'matriculas': len(conteudo['matriculas'])}
        with self.b.transacao() as c:
            n = c.execute('INSERT OR IGNORE INTO pacote_rede VALUES (?,?,?,?,?)',
                          (conteudo['uid'], conteudo['escola'].get('nome', ''), conteudo['gerado_em'], bd.agora(), json.dumps(resumo))).rowcount
            self.b.auditar(c, usuario, 'importar', 'pacote_rede', conteudo['uid'], 'consolidação da rede')
        return {**resumo, 'novo': bool(n), 'escola': conteudo['escola'].get('nome', '')}


def csv_moodle(of, usuario):
    """Usuários para o envio em lote do Moodle. O e-mail é provisório e sem senha."""
    servico.exigir(usuario, 'direcao', 'secretaria', 'coordenacao')
    linhas = [['username', 'firstname', 'lastname', 'email', 'cohort1']]
    for a in of.b.todos("""SELECT p.uid, p.nome, t.nome AS turma FROM matricula m JOIN pessoa p ON p.id=m.aluno_id JOIN turma t ON t.id=m.turma_id
                            JOIN ano_letivo l ON l.id=t.ano_id WHERE m.situacao='cursando' AND l.encerrado=0"""):
        partes = a['nome'].split(' ')
        linhas.append([a['uid'][:8], partes[0], ' '.join(partes[1:]) or '-', f'{a["uid"][:8]}@aluno.invalid', a['turma']])
    s = io.StringIO()
    csv.writer(s, lineterminator='\n').writerows(_seguras(linhas))
    return s.getvalue().encode('utf-8')


def zlib_comprimir(dados):
    import zlib
    return zlib.compress(dados, 9)


def zlib_abrir(dados):
    import zlib
    try:
        return zlib.decompress(dados)
    except zlib.error as e:
        raise ValueError('pacote corrompido') from e


def _celula_csv(v):
    s = '' if v is None else str(v)
    return "'" + s if s[:1] in ('=', '+', '-', '@', '\t', '\r') else s


def _seguras(linhas):
    return [[_celula_csv(v) for v in l] for l in linhas]


def csv_de(linhas):
    s = io.StringIO()
    csv.writer(s, delimiter=';', lineterminator='\r\n').writerows(_seguras(linhas))
    return ('\ufeff' + s.getvalue()).encode('utf-8')
