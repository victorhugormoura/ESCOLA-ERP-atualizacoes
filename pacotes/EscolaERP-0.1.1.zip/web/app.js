'use strict';
const app = document.getElementById('app');
let estado = {}, csrf = '', usuario = null, tela = 'painel';
const FILA = 'escola_fila_chamadas';
const EQUIPE = ['direcao', 'secretaria', 'coordenacao', 'professor'];
const GESTAO = ['direcao', 'secretaria', 'coordenacao'];
const AJUDA = [
  { t: 'Primeiros passos da escola', para: GESTAO, p: ['1. Em Calendário, crie o ano letivo e os períodos.', '2. Em Currículo e sinal, cadastre os componentes.', '3. Em Acessos, crie os professores.', '4. Em Turmas, crie a turma, abra-a e adicione componentes com o professor.', '5. Em Alunos e pessoas, cadastre alunos e responsáveis.', '6. Em Turmas, faça as matrículas.'] },
  { t: 'Fazer a chamada', para: EQUIPE, p: ['Abra Chamada, escolha a turma e a data. Todos começam presentes: toque no aluno para marcar falta.', 'Salvar chamada grava no computador da escola. Sem Wi-Fi, a chamada fica no aparelho e é enviada ao reconectar. Mantenha a tela aberta até voltar a conexão.', 'Em Conteúdo da aula, anote o que foi dado e as habilidades BNCC.'] },
  { t: 'Lançar notas e pareceres', para: EQUIPE, p: ['Em Notas, crie a avaliação, informe período e peso, e digite as notas.', 'A recuperação é uma avaliação do tipo recuperacao; vale a maior nota, conforme a regra da rede.', 'Educação infantil não tem nota: em Pedagógico, escreva o relatório descritivo por campo de experiência.'] },
  { t: 'Publicar conteúdo para os alunos', para: EQUIPE, p: ['Em Conteúdo, escreva o texto ou cole um link do Google Docs, Moodle ou vídeo. O aluno vê em Meu boletim.'] },
  { t: 'Diário validado e alterações', para: GESTAO, p: ['Em Pedagógico, a gestão valida o diário até uma data. Depois disso, o professor só altera por pedido, que aparece no Início para aprovação.', 'Quem pediu não pode aprovar o próprio pedido.'] },
  { t: 'Fechar período e encerrar o ano', para: ['direcao'], p: ['Em Calendário, feche cada período. Com ele fechado, não entram aula, nota nem parecer.', 'No fim, resolva as pendências no conselho de classe e use Encerrar ano letivo.'] },
  { t: 'Documentos', para: GESTAO, p: ['Em Turmas, abra a turma para boletim, declaração e ata. Em Alunos e pessoas, abra o histórico.', 'Todo documento tem código de verificação. Acrescente &formato=odt no endereço para editar, ou &formato=pdf com o LibreOffice instalado.'] },
  { t: 'Alertas de frequência', para: GESTAO, p: ['Frequência mostra quem está abaixo do mínimo legal, do Sistema Presença ou do Pé-de-Meia, e quem atingiu o limite de aviso ao Conselho Tutelar.', 'Os limites são da rede e ficam em Configurações. Confirme com a secretaria de educação.'] },
  { t: 'Censo e envios', para: GESTAO, p: ['Censo e envios mostra pendências e gera planilhas de conferência. Elas não substituem o sistema oficial: confira o layout do ano antes de enviar.', 'Sem internet, use o Pacote para a secretaria: ele sai cifrado, por pen drive, e só abre com a chave da rede.'] },
  { t: 'Cópia de segurança', para: ['direcao'], p: ['O sistema faz uma cópia por dia. Em Configurações, aponte a pasta para um pen drive ou para uma pasta do Google Drive ou OneDrive.', 'Guarde o código de recuperação: sem ele, a cópia não abre em outro computador.', 'Para restaurar, pare o programa e rode: escola.py restaurar ARQUIVO'] },
  { t: 'Integrações e API', para: ['direcao'], p: ['Em Integrações, crie uma chave por sistema, com uma permissão só. A chave aparece uma vez; revogue em Acessos.', 'Ponto: envie o arquivo AFD. Sinal: consulte os horários. Moodle e Classroom: use os arquivos CSV.'] },
  { t: 'Celulares', para: GESTAO, p: ['Em Configurações aparece o endereço para os celulares. O navegador avisa do certificado próprio da escola na primeira vez.', 'Celular de aluno em aula é proibido pela Lei 15.100/2025; o terminal é da equipe.'] },
  { t: 'Boletim e conteúdos', para: ['aluno', 'responsavel'], p: ['Em Meu boletim você vê notas, frequência e conteúdos publicados. Para corrigir um dado, procure a secretaria da escola.'] },
];

function el(tag, attrs, ...filhos) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'onclick' || k === 'onsubmit' || k === 'onchange') n[k] = v;
    else if (k === 'class') n.className = v;
    else if (v === true) n.setAttribute(k, '');
    else if (v !== false && v != null) n.setAttribute(k, v);
  }
  for (const f of filhos.flat()) if (f != null && f !== false) n.append(f.nodeType ? f : String(f));
  return n;
}

async function api(caminho, opcoes = {}) {
  const pedido = { method: opcoes.metodo || (opcoes.dados || opcoes.bruto ? 'POST' : 'GET'), headers: {}, credentials: 'same-origin' };
  if (pedido.method !== 'GET') pedido.headers['X-CSRF'] = csrf;
  if (opcoes.dados) { pedido.headers['Content-Type'] = 'application/json'; pedido.body = JSON.stringify(opcoes.dados); }
  if (opcoes.bruto) pedido.body = opcoes.bruto;
  const r = await fetch('/api/' + caminho, pedido);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.erro || 'Falha na conexão'); e.status = r.status; throw e; }
  return j;
}

const hoje = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
const msg = (texto, tipo = 'ok') => el('div', { class: 'msg ' + tipo }, texto);

function formulario(campos, aoEnviar, rotulo = 'Salvar', valores = {}) {
  const saida = el('div');
  const form = el('form', { class: 'grade', onsubmit: async ev => {
    ev.preventDefault();
    const d = {};
    for (const c of campos) {
      const i = form.elements[c.nome];
      if (c.tipo === 'checkbox') d[c.nome] = i.checked ? 1 : 0;
      else if (i.value !== '') d[c.nome] = c.tipo === 'number' ? Number(i.value) : i.value;
    }
    saida.replaceChildren();
    try { const r = await aoEnviar(d); if (r !== false) saida.append(msg(typeof r === 'string' ? r : 'Salvo.')); form.reset(); }
    catch (e) { saida.append(msg(e.message, 'erro')); }
  } });
  for (const c of campos) {
    let i;
    if (c.opcoes) {
      i = el('select', { name: c.nome, required: c.obrigatorio }, !c.obrigatorio && el('option', { value: '' }, '—'),
        c.opcoes.map(o => el('option', { value: o.v ?? o, selected: String(valores[c.nome]) === String(o.v ?? o) }, o.t ?? o)));
    } else if (c.tipo === 'textarea') i = el('textarea', { name: c.nome, rows: 3 }, valores[c.nome] || '');
    else i = el('input', { name: c.nome, type: c.tipo || 'text', required: c.obrigatorio, value: valores[c.nome] ?? '', autocomplete: c.auto || 'off', step: c.passo, checked: c.tipo === 'checkbox' && valores[c.nome] });
    form.append(el('label', {}, c.rotulo, i));
  }
  form.append(el('div', {}, el('button', {}, rotulo)));
  return el('div', {}, form, saida);
}

function tabela(colunas, linhas, vazio = 'Nada cadastrado ainda.') {
  if (!linhas.length) return el('p', {}, vazio);
  return el('div', { class: 'tabela' }, el('table', {}, el('thead', {}, el('tr', {}, colunas.map(c => el('th', {}, c.t)))),
    el('tbody', {}, linhas.map(l => el('tr', {}, colunas.map(c => el('td', {}, c.f ? c.f(l) : l[c.c])))))));
}

const PAPEIS = { direcao: 'Direção', secretaria: 'Secretaria', coordenacao: 'Coordenação', professor: 'Professor(a)', aluno: 'Aluno(a)', responsavel: 'Responsável', rede: 'Rede' };
const MENU = [
  ['painel', 'Início', ['direcao', 'secretaria', 'coordenacao', 'professor']],
  ['chamada', 'Chamada', ['direcao', 'secretaria', 'coordenacao', 'professor']],
  ['notas', 'Notas', ['direcao', 'coordenacao', 'professor']],
  ['conteudo', 'Conteúdo', ['direcao', 'coordenacao', 'professor']],
  ['pedagogico', 'Pedagógico', ['direcao', 'coordenacao', 'professor']],
  ['pessoas', 'Alunos e pessoas', ['direcao', 'secretaria', 'coordenacao']],
  ['turmas', 'Turmas', ['direcao', 'secretaria', 'coordenacao']],
  ['frequencia', 'Frequência', ['direcao', 'secretaria', 'coordenacao']],
  ['calendario', 'Calendário', ['direcao', 'secretaria']],
  ['curriculo', 'Currículo e sinal', ['direcao', 'secretaria', 'coordenacao']],
  ['oficial', 'Censo e envios', ['direcao', 'secretaria']],
  ['administrativo', 'Administrativo', ['direcao', 'secretaria', 'coordenacao']],
  ['integracoes', 'Integrações', ['direcao']],
  ['usuarios', 'Acessos', ['direcao']],
  ['config', 'Configurações', ['direcao']],
  ['portal', 'Meu boletim', ['aluno', 'responsavel']],
  ['ajuda', 'Ajuda', ['direcao', 'secretaria', 'coordenacao', 'professor', 'aluno', 'responsavel', 'rede']],
];

async function iniciar() {
  estado = await api('estado');
  csrf = estado.csrf || '';
  usuario = estado.usuario;
  if (!estado.configurado) return estado.local ? telaInstalar() : telaAviso('Abra este sistema no computador da escola para fazer a configuração inicial.');
  if (!usuario) return telaEntrar();
  if (usuario.trocar_senha) return telaSenha();
  if (['aluno', 'responsavel'].includes(usuario.papel)) tela = 'portal';
  desenhar();
  enviarFila();
}

function telaAviso(t) { app.replaceChildren(el('div', { class: 'entrada' }, el('h1', {}, 'ESCOLA-ERP'), msg(t, 'aviso'))); }

function telaInstalar() {
  const caixa = el('div', { class: 'entrada' }, el('h1', {}, 'Bem-vindo ao ESCOLA-ERP'), el('p', {}, 'Configure a escola. Leva um minuto.'));
  caixa.append(formulario([
    { nome: 'nome_escola', rotulo: 'Nome da escola', obrigatorio: true }, { nome: 'rede', rotulo: 'Rede de ensino' },
    { nome: 'inep', rotulo: 'Código INEP da escola' }, { nome: 'nome', rotulo: 'Seu nome', obrigatorio: true },
    { nome: 'login', rotulo: 'Login', obrigatorio: true }, { nome: 'senha', rotulo: 'Senha (10 caracteres ou mais)', tipo: 'password', obrigatorio: true, auto: 'new-password' },
  ], async d => {
    const r = await api('instalar', { dados: d });
    app.replaceChildren(el('div', { class: 'entrada' }, el('h1', {}, 'Guarde este código'),
      el('p', {}, 'Ele recupera os backups em outro computador. Imprima e guarde em local seguro. Ele não será mostrado de novo.'),
      el('div', { class: 'cartao' }, el('b', {}, r.codigo_recuperacao)), el('button', { onclick: () => location.reload() }, 'Já guardei, continuar')));
    return false;
  }, 'Criar escola'));
  app.replaceChildren(caixa);
}

function telaEntrar() {
  app.replaceChildren(el('div', { class: 'entrada' }, el('h1', {}, estado.escola || 'ESCOLA-ERP'),
    formulario([{ nome: 'login', rotulo: 'Login', obrigatorio: true, auto: 'username' }, { nome: 'senha', rotulo: 'Senha', tipo: 'password', obrigatorio: true, auto: 'current-password' }],
      async d => { await api('entrar', { dados: d }); location.reload(); return false; }, 'Entrar'),
    el('p', { class: 'rodape' }, estado.credito)));
}

function telaSenha() {
  app.replaceChildren(el('div', { class: 'entrada' }, el('h1', {}, 'Crie sua senha'),
    formulario([{ nome: 'atual', rotulo: 'Senha provisória', tipo: 'password', obrigatorio: true }, { nome: 'nova', rotulo: 'Nova senha (10 caracteres ou mais)', tipo: 'password', obrigatorio: true, auto: 'new-password' }],
      async d => { await api('senha', { dados: d }); location.reload(); return false; }, 'Salvar senha')));
}

function desenhar() {
  const principal = el('main');
  const itens = MENU.filter(m => m[2].includes(usuario.papel));
  const nav = el('nav', {}, itens.map(m => el('button', { class: m[0] === tela ? 'ativo' : '', onclick: () => { tela = m[0]; desenhar(); } }, m[1])));
  app.replaceChildren(el('div', { class: 'topo' }, el('b', {}, estado.escola), el('span', { class: 'esp' }), el('span', {}, `${usuario.nome} · ${PAPEIS[usuario.papel]}`),
    el('button', { onclick: async () => { const p = lerFila().filter(x => x.dono === usuario.id && !x.recusada).length; if (p && !confirm(`Há ${p} chamada(s) ainda não enviada(s). Elas ficam neste aparelho até você entrar de novo. Sair?`)) return; sair(); await api('sair', { dados: {} }); location.reload(); } }, 'Sair')),
    el('div', { class: 'corpo' }, nav, principal), el('div', { class: 'rodape' }, `ESCOLA-ERP ${estado.versao} beta · ${estado.credito}`));
  TELAS[tela](principal).catch(e => principal.replaceChildren(msg(e.message, 'erro')));
}

const opcoesDe = (l, t = 'nome', v = 'id') => l.map(x => ({ v: x[v], t: typeof t === 'function' ? t(x) : x[t] }));
const baixar = (url) => { const a = el('a', { href: url, target: '_blank', rel: 'noopener' }); document.body.append(a); a.click(); a.remove(); };

const TELAS = {
  async painel(m) {
    const p = await api('painel');
    m.replaceChildren(el('h1', {}, 'Início'), el('div', { class: 'numeros' },
      [['Alunos', p.alunos], ['Turmas', p.turmas], ['Aulas lançadas hoje', p.aulas_hoje], ['Pedidos pendentes', p.pedidos]].map(([t, v]) => el('div', { class: 'numero' }, el('b', {}, v), t))));
    if (p.pedidos && usuario.papel !== 'professor') {
      const pedidos = await api('pedidos');
      m.append(el('h2', {}, 'Alterações pedidas em diário validado'), tabela([{ t: 'Quem', c: 'pedido_nome' }, { t: 'Motivo', c: 'motivo' }, { t: 'Decisão', f: l => el('span', {},
        el('button', { onclick: async () => { await api('pedido', { dados: { id: l.id, aprovar: true } }); desenhar(); } }, 'Aprovar'), ' ',
        el('button', { class: 'sec', onclick: async () => { await api('pedido', { dados: { id: l.id, aprovar: false } }); desenhar(); } }, 'Recusar')) }], pedidos));
    }
  },

  async chamada(m) {
    const turmas = await api('turmas-minhas');
    const sel = el('select', {}, opcoesDe(turmas, x => `${x.turma} · ${x.componente}`).map(o => el('option', { value: o.v }, o.t)));
    const data = el('input', { type: 'date', value: hoje() });
    const horas = el('input', { type: 'number', value: 1, min: 0.5, step: 0.5, 'aria-label': 'Horas' });
    const conteudo = el('input', { placeholder: 'Conteúdo da aula' });
    const hab = el('input', { placeholder: 'Habilidades BNCC, ex.: EF01LP01' });
    const lista = el('div'), aviso = el('div');
    const recusadas = lerFila().filter(x => x.dono === usuario.id && x.recusada);
    if (recusadas.length) aviso.append(msg(`${recusadas.length} chamada(s) recusada(s): ${recusadas[0].recusada}`, 'erro'));
    let marcas = {};
    async function carregar() {
      lista.replaceChildren();
      if (!sel.value) return;
      let d;
      try { d = await api(`chamada?tc=${sel.value}&data=${data.value}`); localStorage.setItem('escola_ch_' + sel.value, JSON.stringify(d)); }
      catch (e) { d = JSON.parse(localStorage.getItem('escola_ch_' + sel.value) || 'null'); if (!d) { aviso.replaceChildren(msg(e.message, 'erro')); return; } aviso.replaceChildren(msg('Sem conexão: usando a lista guardada.', 'aviso')); }
      marcas = {};
      d.alunos.forEach(a => { marcas[a.matricula_id] = a.presente ? 1 : 0; });
      if (d.aula) { conteudo.value = d.aula.conteudo; horas.value = d.aula.horas; hab.value = d.aula.habilidades; }
      d.alunos.forEach(a => {
        const st = el('span', { class: 'st' }, marcas[a.matricula_id] ? 'P' : 'F');
        const b = el('button', { type: 'button', class: 'aluno' + (marcas[a.matricula_id] ? '' : ' falta'), onclick: () => {
          marcas[a.matricula_id] = marcas[a.matricula_id] ? 0 : 1;
          st.textContent = marcas[a.matricula_id] ? 'P' : 'F';
          b.classList.toggle('falta', !marcas[a.matricula_id]);
        } }, el('span', { class: 'n' }, a.numero), el('span', { class: 'nome' }, a.nome_social || a.nome), st);
        lista.append(b);
      });
    }
    sel.onchange = carregar; data.onchange = carregar;
    const salvar = el('button', { onclick: async () => {
      guardarNaFila({ dono: usuario.id, uid: crypto.randomUUID(), turma_componente_id: Number(sel.value), data: data.value, horas: Number(horas.value), conteudo: conteudo.value, habilidades: hab.value, marcas, ocorreu_em: new Date().toISOString() });
      const r = await enviarFila();
      const recusada = lerFila().filter(x => x.dono === usuario.id && x.recusada).pop();
      aviso.replaceChildren(recusada ? msg('Chamada recusada: ' + recusada.recusada, 'erro') : r === 0 ? msg('Chamada gravada.') : msg(`Sem conexão. ${r} chamada(s) guardada(s) neste aparelho; serão enviadas ao reconectar.`, 'aviso'));
    } }, 'Salvar chamada');
    m.replaceChildren(el('h1', {}, 'Chamada'), el('div', { class: 'cartao' }, el('label', {}, 'Turma', sel), el('div', { class: 'dupla' }, el('label', {}, 'Data', data), el('label', {}, 'Horas', horas)), el('details', {}, el('summary', {}, 'Conteúdo da aula'), conteudo, hab)), aviso, lista, el('div', { class: 'fila' }, salvar));
    await carregar();
  },

  async pedagogico(m) {
    const [turmas, periodos] = await Promise.all([api('turmas-minhas'), api('periodo')]);
    const sel = el('select', {}, opcoesDe(turmas, x => `${x.turma} · ${x.componente}`).map(o => el('option', { value: o.v }, o.t)));
    const area = el('div');
    async function carregar() {
      if (!sel.value) { area.replaceChildren(el('p', {}, 'Nenhuma turma disponível.')); return; }
      const tc = turmas.find(t => String(t.id) === sel.value);
      const [alunos, planos] = await Promise.all([api(`alunos-turma?turma=${tc.turma_id}`), api(`plano_aula?turma_componente_id=${tc.id}`)]);
      const ativos = alunos.filter(a => a.situacao === 'cursando');
      area.replaceChildren(el('div', { class: 'cartao' }, el('h2', {}, tc.etapa === 'infantil' ? 'Relatório descritivo' : 'Parecer'), formulario([
        { nome: 'matricula_id', rotulo: 'Aluno(a)', opcoes: opcoesDe(ativos, 'nome', 'matricula_id'), obrigatorio: true }, { nome: 'periodo_id', rotulo: 'Período', opcoes: opcoesDe(periodos), obrigatorio: true },
        { nome: 'campo', rotulo: 'Campo', opcoes: tc.etapa === 'infantil' ? ['O eu, o outro e o nós', 'Corpo, gestos e movimentos', 'Traços, sons, cores e formas', 'Escuta, fala, pensamento e imaginação', 'Espaços, tempos, quantidades, relações e transformações'] : ['geral'], obrigatorio: true }, { nome: 'texto', rotulo: 'Texto', tipo: 'textarea' },
      ], d => api('parecer', { dados: { ...d, matricula_id: Number(d.matricula_id), periodo_id: Number(d.periodo_id) } }))),
      el('div', { class: 'cartao' }, el('h2', {}, 'Plano de aula'), formulario([{ nome: 'semana', rotulo: 'Semana', tipo: 'date', obrigatorio: true }, { nome: 'objetivos', rotulo: 'Objetivos', tipo: 'textarea' }, { nome: 'habilidades', rotulo: 'Habilidades BNCC' }, { nome: 'metodologia', rotulo: 'Metodologia', tipo: 'textarea' }],
        async d => { await api('plano_aula', { dados: { ...d, turma_componente_id: tc.id } }); carregar(); return false; }, 'Salvar plano'), tabela([{ t: 'Semana', c: 'semana' }, { t: 'Habilidades', c: 'habilidades' }, { t: 'Objetivos', c: 'objetivos' }], planos, 'Nenhum plano.')),
      el('p', {}, el('a', { href: `/api/documento/diario?tc=${tc.id}`, target: '_blank' }, 'Imprimir diário de classe')),
      usuario.papel !== 'professor' && el('div', { class: 'cartao' }, el('h2', {}, 'Validar diário'), el('p', {}, 'Depois de validado, o professor só altera por pedido.'), formulario([{ nome: 'ate', rotulo: 'Validar até', tipo: 'date', obrigatorio: true }], async d => { const r = await api('validar-aulas', { dados: { tc: tc.id, ate: d.ate } }); return `${r.validadas} aula(s) validada(s).`; }, 'Validar')),
      usuario.papel !== 'professor' && el('div', { class: 'cartao' }, el('h2', {}, 'Conselho de classe'), formulario([{ nome: 'matricula_id', rotulo: 'Aluno(a)', opcoes: opcoesDe(ativos, 'nome', 'matricula_id'), obrigatorio: true }, { nome: 'decisao', rotulo: 'Decisão', opcoes: ['aprovado', 'reprovado'], obrigatorio: true }, { nome: 'motivo', rotulo: 'Motivo', tipo: 'textarea' }],
        async d => { const b = await api(`boletim?matricula=${d.matricula_id}`); const c = b.linhas.find(l => l.componente === tc.componente); await api('conselho', { dados: { ...d, matricula_id: Number(d.matricula_id), componente_id: c.componente_id } }); return 'Decisão registrada.'; }, 'Registrar')));
    }
    sel.onchange = carregar;
    m.replaceChildren(el('h1', {}, 'Pedagógico'), el('label', {}, 'Turma', sel), area);
    await carregar();
  },

  async curriculo(m) {
    const [comps, hab, sinais] = await Promise.all([api('componente'), api('habilidade'), api('sinal')]);
    const editar = usuario.papel !== 'professor';
    m.replaceChildren(el('h1', {}, 'Currículo e sinal'), el('div', { class: 'cartao' }, el('h2', {}, 'Componentes curriculares'), editar && formulario([{ nome: 'nome', rotulo: 'Nome', obrigatorio: true }, { nome: 'area', rotulo: 'Área' }], async d => { await api('componente', { dados: d }); desenhar(); return false; }), tabela([{ t: 'Nome', c: 'nome' }, { t: 'Área', c: 'area' }], comps)),
      el('div', { class: 'cartao' }, el('h2', {}, 'Habilidades BNCC e locais'), ['direcao', 'coordenacao'].includes(usuario.papel) && formulario([{ nome: 'codigo', rotulo: 'Código', obrigatorio: true }, { nome: 'descricao', rotulo: 'Descrição', obrigatorio: true }, { nome: 'etapa', rotulo: 'Etapa' }], async d => { await api('habilidade', { dados: d }); desenhar(); return false; }), tabela([{ t: 'Código', c: 'codigo' }, { t: 'Descrição', c: 'descricao' }], hab)),
      el('div', { class: 'cartao' }, el('h2', {}, 'Sinal escolar'), ['direcao', 'secretaria'].includes(usuario.papel) && formulario([{ nome: 'hora', rotulo: 'Hora (HH:MM)', obrigatorio: true }, { nome: 'descricao', rotulo: 'Descrição' }, { nome: 'duracao_s', rotulo: 'Duração em segundos', tipo: 'number' }], async d => { await api('sinal', { dados: { ...d, ativo: 1 } }); desenhar(); return false; }), tabela([{ t: 'Hora', c: 'hora' }, { t: 'Descrição', c: 'descricao' }], sinais)));
  },

  async ajuda(m) {
    const secoes = AJUDA.filter(s => s.para.includes(usuario.papel));
    m.replaceChildren(el('h1', {}, 'Ajuda'), ...secoes.map(s => el('details', { class: 'cartao' }, el('summary', {}, el('b', {}, s.t)), s.p.map(x => el('p', {}, x)))), el('p', {}, 'Dúvida ou problema: victorhugormoura@gmail.com'));
  },

  async notas(m) {
    const turmas = await api('turmas-minhas');
    const sel = el('select', {}, opcoesDe(turmas, x => `${x.turma} · ${x.componente}`).map(o => el('option', { value: o.v }, o.t)));
    const area = el('div');
    async function carregar() {
      if (!sel.value) return;
      const tc = turmas.find(t => String(t.id) === sel.value);
      const [avs, alunos, periodos] = await Promise.all([api(`avaliacoes?tc=${sel.value}`), api(`alunos-turma?turma=${tc.turma_id}`), api('periodo')]);
      area.replaceChildren(el('h2', {}, 'Nova avaliação'), formulario([
        { nome: 'nome', rotulo: 'Nome', obrigatorio: true }, { nome: 'periodo_id', rotulo: 'Período', opcoes: opcoesDe(periodos), obrigatorio: true },
        { nome: 'peso', rotulo: 'Peso', tipo: 'number', passo: '0.1', obrigatorio: true }, { nome: 'tipo', rotulo: 'Tipo', opcoes: ['regular', 'recuperacao'], obrigatorio: true },
      ], async d => { await api('avaliacao', { dados: { ...d, turma_componente_id: Number(sel.value) } }); carregar(); return false; }, 'Criar'));
      for (const av of avs) {
        const notas = Object.fromEntries((await api(`notas?avaliacao=${av.id}`)).map(n => [n.matricula_id, n.valor]));
        const entradas = {};
        area.append(el('h2', {}, `${av.nome} (peso ${av.peso})`), tabela([{ t: 'Nº', c: 'numero' }, { t: 'Aluno', c: 'nome' }, { t: 'Nota', f: l => (entradas[l.matricula_id] = el('input', { type: 'number', step: '0.1', min: 0, value: notas[l.matricula_id] ?? '' })) }], alunos.filter(a => a.situacao === 'cursando')),
          el('p', {}, el('button', { onclick: async ev => { const d = {}; for (const [k, i] of Object.entries(entradas)) if (i.value !== '') d[k] = i.value; try { await api('notas', { dados: { avaliacao_id: av.id, notas: d } }); ev.target.textContent = 'Salvo'; } catch (e) { alert(e.message); } } }, 'Salvar notas')));
      }
    }
    sel.onchange = carregar;
    m.replaceChildren(el('h1', {}, 'Notas'), el('label', {}, 'Turma', sel), area);
    await carregar();
  },

  async conteudo(m) {
    const turmas = await api('turmas-minhas');
    const lista = await api('conteudo');
    m.replaceChildren(el('h1', {}, 'Conteúdo para os alunos'), el('div', { class: 'cartao' }, formulario([
      { nome: 'turma_componente_id', rotulo: 'Turma', opcoes: opcoesDe(turmas, x => `${x.turma} · ${x.componente}`), obrigatorio: true }, { nome: 'titulo', rotulo: 'Título', obrigatorio: true },
      { nome: 'link', rotulo: 'Link (Google Docs, Moodle, vídeo)', tipo: 'url' }, { nome: 'corpo', rotulo: 'Texto', tipo: 'textarea' }, { nome: 'habilidades', rotulo: 'Habilidades BNCC' },
    ], async d => { await api('conteudo', { dados: { ...d, publicado: 1 } }); desenhar(); return false; }, 'Publicar')), tabela([{ t: 'Título', c: 'titulo' }, { t: 'Publicado em', f: l => (l.criado_em || '').slice(0, 10) }], lista));
  },

  async pessoas(m) {
    const area = el('div');
    const busca = el('input', { placeholder: 'Buscar por nome' });
    async function listar() {
      const l = await api('pessoa?busca=' + encodeURIComponent(busca.value));
      area.replaceChildren(tabela([{ t: 'Nome', c: 'nome' }, { t: 'Nascimento', c: 'nascimento' }, { t: 'ID INEP', c: 'id_inep' }, { t: '', f: x => el('span', {}, el('a', { href: `/api/documento/historico?aluno=${x.id}`, target: '_blank' }, 'Histórico'), ' · ', el('a', { href: '#', onclick: ev => { ev.preventDefault(); ficha(x); } }, 'Responsáveis')) }], l));
    }
    const painelFicha = el('div');
    async function ficha(x) {
      const [f, todos] = await Promise.all([api(`pessoa/${x.id}`), api('pessoa')]);
      const resp = todos.filter(p => p.eh_responsavel);
      painelFicha.replaceChildren(el('div', { class: 'cartao' }, el('h2', {}, `Responsáveis de ${x.nome}`), tabela([{ t: 'Nome', c: 'nome' }, { t: 'Parentesco', c: 'parentesco' }, { t: '', f: v => el('button', { class: 'sec', onclick: async () => { await api('desvincular', { dados: { aluno_id: x.id, responsavel_id: v.responsavel_id } }); ficha(x); } }, 'Remover') }], f.vinculos, 'Nenhum responsável.'),
        formulario([{ nome: 'responsavel_id', rotulo: 'Responsável', opcoes: opcoesDe(resp), obrigatorio: true }, { nome: 'parentesco', rotulo: 'Parentesco', opcoes: ['mãe', 'pai', 'avó', 'avô', 'tio(a)', 'responsável legal', 'outro'], obrigatorio: true }],
          async d => { await api('vincular', { dados: { aluno_id: x.id, responsavel_id: Number(d.responsavel_id), parentesco: d.parentesco } }); ficha(x); return false; }, 'Vincular')));
    }
    busca.onchange = listar;
    m.replaceChildren(el('h1', {}, 'Alunos e pessoas'), el('details', { class: 'cartao' }, el('summary', {}, 'Novo cadastro'), formulario([
      { nome: 'nome', rotulo: 'Nome civil', obrigatorio: true }, { nome: 'nome_social', rotulo: 'Nome social' }, { nome: 'nascimento', rotulo: 'Nascimento', tipo: 'date' },
      { nome: 'sexo', rotulo: 'Sexo', opcoes: ['Feminino', 'Masculino'] }, { nome: 'cor_raca', rotulo: 'Cor/raça', opcoes: ['Branca', 'Preta', 'Parda', 'Amarela', 'Indígena', 'Não declarada'] },
      { nome: 'naturalidade', rotulo: 'Naturalidade' }, { nome: 'cpf', rotulo: 'CPF' }, { nome: 'nis', rotulo: 'NIS' }, { nome: 'id_inep', rotulo: 'ID INEP' }, { nome: 'telefone', rotulo: 'Telefone' }, { nome: 'endereco', rotulo: 'Endereço' },
      { nome: 'transporte', rotulo: 'Transporte escolar' }, { nome: 'restricao_alimentar', rotulo: 'Restrição alimentar' }, { nome: 'eh_aluno', rotulo: 'É aluno(a)', tipo: 'checkbox' }, { nome: 'eh_responsavel', rotulo: 'É responsável', tipo: 'checkbox' },
    ], async d => { await api('pessoa', { dados: d }); listar(); return 'Cadastrado.'; })), busca, ' ', painelFicha, area);
    await listar();
  },

  async turmas(m) {
    const [anos, turmas, pessoas] = await Promise.all([api('ano_letivo'), api('turma'), api('pessoa')]);
    const alunos = pessoas.filter(p => p.eh_aluno);
    const detalhe = el('div');
    const abrir = async t => {
      const [l, comps, tcs, usuarios] = await Promise.all([api(`alunos-turma?turma=${t.id}`), api('componente'), api(`turma_componente?turma_id=${t.id}`), usuario.papel === 'direcao' ? api('usuarios') : Promise.resolve([])]);
      const nomeComp = id => (comps.find(c => c.id === id) || {}).nome;
      const nomeProf = id => (usuarios.find(u => u.id === id) || {}).nome || '—';
      const mover = async (dados, rota = 'saida') => { try { await api(rota, { dados }); abrir(t); } catch (e) { alert(e.message); } };
      detalhe.replaceChildren(el('h2', {}, `Turma ${t.nome}`), el('p', {}, el('a', { href: `/api/documento/ata?turma=${t.id}`, target: '_blank' }, 'Ata de resultados')),
        el('h2', {}, 'Componentes e professores'), tabela([{ t: 'Componente', f: x => nomeComp(x.componente_id) }, { t: 'Professor(a)', f: x => nomeProf(x.professor_id) }, { t: 'Carga', c: 'carga_horaria' }], tcs, 'Nenhum componente nesta turma.'),
        el('details', { class: 'cartao' }, el('summary', {}, 'Adicionar componente'), formulario([{ nome: 'componente_id', rotulo: 'Componente', opcoes: opcoesDe(comps), obrigatorio: true },
          { nome: 'professor_id', rotulo: 'Professor(a)', opcoes: opcoesDe(usuarios.filter(u => u.papel === 'professor')) }, { nome: 'carga_horaria', rotulo: 'Carga horária', tipo: 'number' }],
        async d => { await api('turma_componente', { dados: { ...d, turma_id: t.id } }); abrir(t); return false; }, 'Adicionar')),
        el('h2', {}, 'Alunos'), tabela([{ t: 'Nº', c: 'numero' }, { t: 'Aluno', c: 'nome' }, { t: 'Situação', c: 'situacao' }, { t: 'Documentos', f: a => el('span', {}, el('a', { href: `/api/documento/boletim?matricula=${a.matricula_id}`, target: '_blank' }, 'Boletim'), ' · ', el('a', { href: `/api/documento/declaracao?matricula=${a.matricula_id}`, target: '_blank' }, 'Declaração')) },
          { t: 'Mover', f: a => a.situacao === 'cursando' && el('span', {},
            el('button', { class: 'sec', onclick: () => { const e = prompt('Escola de destino'); if (e) mover({ matricula_id: a.matricula_id, situacao: 'transferido', escola_outra: e }); } }, 'Transferir'), ' ',
            el('select', { 'aria-label': 'Remanejar', onchange: ev => { if (ev.target.value) mover({ matricula_id: a.matricula_id, turma_id: Number(ev.target.value) }, 'remanejar'); } }, el('option', { value: '' }, 'Remanejar…'), turmas.filter(o => o.id !== t.id).map(o => el('option', { value: o.id }, o.nome))), ' ',
            el('button', { class: 'sec', onclick: () => { if (confirm('Registrar abandono?')) mover({ matricula_id: a.matricula_id, situacao: 'abandono' }); } }, 'Abandono')) }], l));
    };
    m.replaceChildren(el('h1', {}, 'Turmas'), el('div', { class: 'cartao' }, el('h2', {}, 'Nova turma'), formulario([
      { nome: 'ano_id', rotulo: 'Ano letivo', opcoes: opcoesDe(anos, 'ano'), obrigatorio: true }, { nome: 'nome', rotulo: 'Nome', obrigatorio: true },
      { nome: 'etapa', rotulo: 'Etapa', opcoes: ['infantil', 'fundamental', 'medio', 'eja', 'aee'], obrigatorio: true }, { nome: 'serie', rotulo: 'Série/ano' }, { nome: 'turno', rotulo: 'Turno', opcoes: ['manhã', 'tarde', 'noite', 'integral'] },
      { nome: 'vagas', rotulo: 'Vagas', tipo: 'number' }, { nome: 'multisserie', rotulo: 'Multissérie', tipo: 'checkbox' },
    ], async d => { await api('turma', { dados: d }); desenhar(); return false; })),
    el('div', { class: 'cartao' }, el('h2', {}, 'Matricular'), formulario([{ nome: 'aluno_id', rotulo: 'Aluno', opcoes: opcoesDe(alunos), obrigatorio: true }, { nome: 'turma_id', rotulo: 'Turma', opcoes: opcoesDe(turmas), obrigatorio: true }],
      async d => { const r = await api('matricular', { dados: { aluno_id: Number(d.aluno_id), turma_id: Number(d.turma_id) } }); return `Matrícula ${r.codigo}, número ${r.numero}.`; }, 'Matricular')),
    tabela([{ t: 'Turma', f: t => el('a', { href: '#', onclick: ev => { ev.preventDefault(); abrir(t); } }, t.nome) }, { t: 'Etapa', c: 'etapa' }, { t: 'Turno', c: 'turno' }, { t: 'Vagas', c: 'vagas' }], turmas), detalhe);
  },

  async frequencia(m) {
    const l = await api('frequencia-painel');
    const nomes = { conselho_tutelar: 'Conselho Tutelar', reprovacao_frequencia: 'Abaixo do mínimo', sistema_presenca: 'Sistema Presença', pe_de_meia: 'Pé-de-Meia' };
    const alerta = l.filter(x => x.alertas.length);
    m.replaceChildren(el('h1', {}, 'Frequência'), el('p', {}, `${alerta.length} aluno(s) com alerta, de ${l.length}.`),
      tabela([{ t: 'Aluno', c: 'nome' }, { t: 'Turma', c: 'turma' }, { t: 'Horas', f: x => `${x.horas_presentes} de ${x.horas_ofertadas}` }, { t: '%', c: 'percentual' }, { t: 'Alertas', f: x => el('span', {}, x.alertas.map(a => el('span', { class: 'selo' }, nomes[a] || a))) }], l));
  },

  async calendario(m) {
    const anos = await api('ano_letivo');
    const dias = await api('dia_calendario');
    const periodos = await api('periodo');
    m.replaceChildren(el('h1', {}, 'Calendário'), el('div', { class: 'cartao' }, el('h2', {}, 'Ano letivo'), formulario([{ nome: 'ano', rotulo: 'Ano', tipo: 'number', obrigatorio: true }, { nome: 'inicio', rotulo: 'Início', tipo: 'date', obrigatorio: true }, { nome: 'fim', rotulo: 'Fim', tipo: 'date', obrigatorio: true }],
      async d => { await api('ano_letivo', { dados: d }); desenhar(); return false; })),
    el('div', { class: 'cartao' }, el('h2', {}, 'Período'), formulario([{ nome: 'ano_id', rotulo: 'Ano', opcoes: opcoesDe(anos, 'ano'), obrigatorio: true }, { nome: 'nome', rotulo: 'Nome', obrigatorio: true }, { nome: 'ordem', rotulo: 'Ordem', tipo: 'number', obrigatorio: true }, { nome: 'inicio', rotulo: 'Início', tipo: 'date', obrigatorio: true }, { nome: 'fim', rotulo: 'Fim', tipo: 'date', obrigatorio: true }],
      async d => { await api('periodo', { dados: d }); desenhar(); return false; })),
    el('div', { class: 'cartao' }, el('h2', {}, 'Dia especial'), formulario([{ nome: 'ano_id', rotulo: 'Ano', opcoes: opcoesDe(anos, 'ano'), obrigatorio: true }, { nome: 'data', rotulo: 'Data', tipo: 'date', obrigatorio: true }, { nome: 'tipo', rotulo: 'Tipo', opcoes: ['feriado', 'recesso', 'suspensao', 'planejamento', 'letivo'], obrigatorio: true }, { nome: 'descricao', rotulo: 'Descrição' }],
      async d => { await api('dia_calendario', { dados: d }); desenhar(); return false; })),
    tabela([{ t: 'Período', c: 'nome' }, { t: 'Início', c: 'inicio' }, { t: 'Fim', c: 'fim' }, { t: 'Situação', f: x => (x.fechado ? 'Fechado' : 'Aberto') }, { t: '', f: x => usuario.papel === 'direcao' && el('button', { class: 'sec', onclick: async () => { await api('periodo/fechar', { dados: { id: x.id, fechado: !x.fechado } }); desenhar(); } }, x.fechado ? 'Reabrir' : 'Fechar') }], periodos), el('h2', {}, 'Dias'), tabela([{ t: 'Data', c: 'data' }, { t: 'Tipo', c: 'tipo' }, { t: 'Descrição', c: 'descricao' }], dias),
    usuario.papel === 'direcao' && el('div', { class: 'cartao' }, el('h2', {}, 'Encerrar ano letivo'), el('p', {}, 'Grava o resultado final. Feche todos os períodos e resolva as pendências antes.'), formulario([{ nome: 'id', rotulo: 'Ano', opcoes: opcoesDe(anos, 'ano'), obrigatorio: true }], async d => { if (!confirm('Encerrar o ano letivo?')) return false; const r = await api('ano/encerrar', { dados: { id: Number(d.id) } }); return `${r.matriculas} matrículas encerradas.`; }, 'Encerrar')));
  },

  async oficial(m) {
    const p = await api('censo-conferencia');
    const agora = new Date();
    m.replaceChildren(el('h1', {}, 'Censo e envios'), msg('Estes arquivos são de conferência. Confirme o layout oficial do ano antes de enviar.', 'aviso'),
      el('div', { class: 'cartao' }, el('h2', {}, 'Planilhas'), el('div', { class: 'linha' },
        el('button', { onclick: () => baixar(`/api/exportar/frequencia-mensal?ano=${agora.getFullYear()}&mes=${agora.getMonth() + 1}`) }, 'Frequência do mês (XLSX)'),
        el('button', { onclick: () => baixar(`/api/exportar/presenca?de=${agora.getFullYear()}-01-01&ate=${hoje()}`) }, 'Sistema Presença (CSV)'),
        el('button', { onclick: () => baixar('/api/exportar/pacote-rede') }, 'Pacote para a secretaria'))),
      el('h2', {}, `Pendências do Censo (${p.length})`), tabela([{ t: 'Item', c: 'item' }, { t: 'Turma', c: 'turma' }, { t: 'Problema', c: 'problema' }], p, 'Nenhuma pendência.'));
  },

  async administrativo(m) {
    const metas = await api('metadados');
    const ROTULOS = { valor: 'Valor', data: 'Data', tipo: 'Tipo', descricao: 'Descrição', nome: 'Nome', codigo: 'Código', titulo: 'Título', autor: 'Autor', item: 'Item', tombo: 'Tombo', local: 'Local', origem: 'Origem', situacao: 'Situação', unidade: 'Unidade', minimo: 'Mínimo', validade: 'Validade', exemplares: 'Exemplares', pnld: 'PNLD', veiculo: 'Veículo', motorista: 'Motorista', turno: 'Turno', rural: 'Rural', refeicao: 'Refeição', servidas: 'Refeições servidas', aluno_id: 'Aluno (número)', pessoa_id: 'Pessoa (número)', encaminhamento: 'Encaminhamento', funcao: 'Função', vinculo: 'Vínculo', carga_semanal: 'Carga semanal', inicio: 'Início', fim: 'Fim', programa: 'Programa', documento: 'Documento', versao: 'Versão', estudo_de_caso: 'Estudo de caso', objetivos: 'Objetivos', recursos: 'Recursos' };
    const TIPOS = { data: 'date', inicio: 'date', fim: 'date', validade: 'date', valor: 'number', minimo: 'number', exemplares: 'number', servidas: 'number', carga_semanal: 'number', aluno_id: 'number', pessoa_id: 'number', versao: 'number' };
    const area = el('div');
    const pessoas = await api('pessoa').catch(() => []);
    const abrir = async meta => {
      const linhas = await api(meta.recurso);
      const campos = meta.campos.map(c => (['aluno_id', 'pessoa_id'].includes(c) ? { nome: c, rotulo: c === 'aluno_id' ? 'Aluno(a)' : 'Pessoa', opcoes: opcoesDe(pessoas), obrigatorio: meta.obrigatorios.includes(c) } : { nome: c, rotulo: ROTULOS[c] || c, tipo: ['estudo_de_caso', 'objetivos', 'recursos', 'descricao'].includes(c) ? 'textarea' : (['pnld', 'rural'].includes(c) ? 'checkbox' : TIPOS[c]), obrigatorio: meta.obrigatorios.includes(c), passo: c === 'valor' ? '0.01' : undefined, opcoes: c === 'tipo' && meta.recurso !== 'ocorrencia' ? ['entrada', 'saida'] : undefined }));
      const nomePessoa = id => (pessoas.find(p => p.id === id) || {}).nome || id;
      const extra = el('div');
      if (meta.recurso === 'almoxarifado' && linhas.length) extra.append(el('details', { class: 'cartao' }, el('summary', {}, 'Entrada ou saída'), formulario([{ nome: 'item_id', rotulo: 'Item', opcoes: opcoesDe(linhas, 'item'), obrigatorio: true }, { nome: 'tipo', rotulo: 'Tipo', opcoes: ['entrada', 'saida'], obrigatorio: true }, { nome: 'quantidade', rotulo: 'Quantidade', tipo: 'number', passo: '0.01', obrigatorio: true }, { nome: 'motivo', rotulo: 'Motivo' }],
        async d => { await api('movimentar', { dados: { ...d, item_id: Number(d.item_id) } }); abrir(meta); return false; }, 'Registrar')));
      if (meta.recurso === 'acervo' && linhas.length) {
        const fora = await api('emprestimos');
        extra.append(el('details', { class: 'cartao' }, el('summary', {}, 'Empréstimo'), formulario([{ nome: 'acervo_id', rotulo: 'Livro', opcoes: opcoesDe(linhas, 'titulo'), obrigatorio: true }, { nome: 'pessoa_id', rotulo: 'Pessoa', opcoes: opcoesDe(pessoas), obrigatorio: true }, { nome: 'prazo', rotulo: 'Devolver até', tipo: 'date' }],
          async d => { await api('emprestar', { dados: { ...d, acervo_id: Number(d.acervo_id), pessoa_id: Number(d.pessoa_id) } }); abrir(meta); return false; }, 'Emprestar')),
        el('h2', {}, 'Emprestados'), tabela([{ t: 'Livro', c: 'titulo' }, { t: 'Com', c: 'nome' }, { t: 'Prazo', c: 'prazo' }, { t: '', f: x => el('button', { class: 'sec', onclick: async () => { await api('devolver', { dados: { id: x.id } }); abrir(meta); } }, 'Devolver') }], fora, 'Nenhum livro emprestado.'));
      }
      area.replaceChildren(el('h2', {}, meta.titulo), meta.escrever && el('details', { class: 'cartao' }, el('summary', {}, 'Novo registro'), formulario(campos, async d => { await api(meta.recurso, { dados: d }); abrir(meta); return false; })), extra,
        tabela([...meta.campos.slice(0, 5), ...meta.mostra].map(c => (['aluno_id', 'pessoa_id'].includes(c) ? { t: 'Pessoa', f: x => nomePessoa(x[c]) } : { t: ROTULOS[c] || (c === 'saldo' ? 'Saldo' : c), c })), linhas));
    };
    m.replaceChildren(el('h1', {}, 'Administrativo'), el('div', { class: 'linha' }, metas.map(x => el('button', { class: 'sec', onclick: () => abrir(x) }, x.titulo))), area);
    if (metas.length) await abrir(metas[0]);
  },

  async integracoes(m) {
    const area = el('div');
    m.replaceChildren(el('h1', {}, 'Integrações'), el('div', { class: 'cartao' }, el('h2', {}, 'Moodle, Google Classroom e similares'), el('p', {}, 'Turmas e alunos para ambientes de aprendizagem.'), el('div', { class: 'linha' }, el('button', { onclick: () => baixar('/api/exportar/oneroster') }, 'OneRoster'), el('button', { onclick: () => baixar('/api/exportar/moodle') }, 'Moodle (CSV)'))),
      el('div', { class: 'cartao' }, el('h2', {}, 'Documentos'), el('p', {}, 'Todo documento abre para impressão. Acrescente &formato=odt no endereço para editar no LibreOffice, Google Docs ou Word, ou &formato=pdf para PDF, lido por Foxit e outros leitores.')),
      el('div', { class: 'cartao' }, el('h2', {}, 'Chave de API'), el('p', {}, el('a', { href: '/api/v1/openapi.json', target: '_blank' }, 'Documentação da API')), formulario([{ nome: 'nome', rotulo: 'Sistema', obrigatorio: true }, { nome: 'escopo', rotulo: 'Permissão', opcoes: ['leitura', 'frequencia', 'sinal', 'ponto', 'conteudo'], obrigatorio: true }],
        async d => { const r = await api('token', { dados: { nome: d.nome, escopos: [d.escopo] } }); area.replaceChildren(msg('Copie agora; ela não será mostrada de novo: ' + r.token)); return false; }, 'Criar chave'), area));
  },

  async usuarios(m) {
    const [l, tokens, pessoas] = await Promise.all([api('usuarios'), api('tokens'), api('pessoa')]);
    const area = el('div');
    const acao = async (rota, dados) => { const r = await api(rota, { dados }); if (r.senha_provisoria) area.replaceChildren(msg(`Senha provisória: ${r.senha_provisoria}`)); else desenhar(); };
    m.replaceChildren(el('h1', {}, 'Acessos'), el('div', { class: 'cartao' }, formulario([{ nome: 'nome', rotulo: 'Nome', obrigatorio: true }, { nome: 'login', rotulo: 'Login', obrigatorio: true }, { nome: 'papel', rotulo: 'Perfil', opcoes: Object.entries(PAPEIS).map(([v, t]) => ({ v, t })), obrigatorio: true }, { nome: 'pessoa_id', rotulo: 'Pessoa (aluno ou responsável)', opcoes: opcoesDe(pessoas) }],
      async d => { if (d.pessoa_id) d.pessoa_id = Number(d.pessoa_id); const r = await api('usuario', { dados: d }); area.replaceChildren(msg(`Senha provisória: ${r.senha_provisoria}`)); return false; }, 'Criar acesso'), area),
    tabela([{ t: 'Nome', c: 'nome' }, { t: 'Login', c: 'login' }, { t: 'Perfil', f: x => PAPEIS[x.papel] }, { t: 'Situação', f: x => (x.ativo ? 'Ativo' : 'Desativado') }, { t: '', f: x => el('span', {},
      el('button', { class: 'sec', onclick: () => acao('usuario/senha', { id: x.id }) }, 'Nova senha'), ' ',
      x.id !== usuario.id && el('button', { class: 'sec', onclick: () => acao('usuario/ativo', { id: x.id, ativo: !x.ativo }) }, x.ativo ? 'Desativar' : 'Reativar')) }], l),
    el('h2', {}, 'Chaves de API'), tabela([{ t: 'Sistema', c: 'nome' }, { t: 'Permissão', c: 'escopos' }, { t: 'Último uso', f: x => (x.ultimo_uso || '—').slice(0, 16) }, { t: '', f: x => el('button', { class: 'sec', onclick: () => acao('token/revogar', { id: x.id }) }, 'Revogar') }], tokens, 'Nenhuma chave ativa.'),
    el('h2', {}, 'Trilha de auditoria'), tabela([{ t: 'Quando', f: x => x.quando.slice(0, 16) }, { t: 'Quem', c: 'usuario' }, { t: 'Ação', c: 'acao' }, { t: 'Onde', c: 'tabela' }, { t: 'Detalhe', c: 'detalhe' }], await api('trilha')));
  },

  async config(m) {
    const c = await api('config');
    const estadoBk = el('div');
    m.replaceChildren(el('h1', {}, 'Configurações'), el('div', { class: 'cartao' }, el('h2', {}, 'Cópia de segurança'),
      c.backup_erro && msg(`A última cópia falhou: ${c.backup_erro.erro}`, 'erro'), !c.auditoria_ok && msg('A trilha de auditoria foi alterada fora do sistema.', 'erro'), el('p', {}, c.backup_ultimo ? `Última cópia: ${c.backup_ultimo.quando.slice(0, 16)}` : 'Nenhuma cópia feita ainda.'), el('p', {}, `Pasta: ${c.backup_pasta}`),
      el('button', { onclick: async () => { try { const r = await api('backup', { dados: {} }); estadoBk.replaceChildren(msg('Cópia feita e conferida: ' + r.arquivo)); } catch (e) { estadoBk.replaceChildren(msg(e.message, 'erro')); } } }, 'Fazer cópia agora'), estadoBk,
      el('h2', {}, 'Destino e nuvem'), formulario([{ nome: 'pasta', rotulo: 'Pasta (pen drive, Google Drive, OneDrive)' }, { nome: 'webdav_url', rotulo: 'Endereço WebDAV (Nextcloud)', tipo: 'url' }, { nome: 'webdav_usuario', rotulo: 'Usuário WebDAV' }, { nome: 'webdav_senha', rotulo: 'Senha WebDAV', tipo: 'password' }], d => api('config/backup', { dados: d }))),
    el('div', { class: 'cartao' }, el('h2', {}, 'Regras da rede'), formulario([{ nome: 'media_aprovacao', rotulo: 'Média de aprovação', tipo: 'number', passo: '0.1' }, { nome: 'frequencia_minima', rotulo: 'Frequência mínima (%)', tipo: 'number' }, { nome: 'dias_letivos', rotulo: 'Dias letivos', tipo: 'number' }], d => api('config/regras', { dados: { ...c.regras, ...d } }), 'Salvar', c.regras)),
    el('div', { class: 'cartao' }, el('h2', {}, 'Celulares'), (c.endereco_lan || ['Inicie com a opção de rede para liberar os celulares.']).map(x => el('p', {}, x)), el('p', {}, c.libreoffice ? 'LibreOffice encontrado: PDF direto disponível.' : 'LibreOffice não encontrado: use imprimir em PDF no navegador.')),
    el('div', { class: 'cartao' }, el('h2', {}, 'Chave da rede'), el('p', {}, 'Use a mesma chave na secretaria e nas escolas para abrir os pacotes.'), el('details', {}, el('summary', {}, 'Mostrar chave desta instalação'), el('p', {}, c.chave_rede)), formulario([{ nome: 'chave', rotulo: 'Definir chave recebida da rede', obrigatorio: true }], d => api('config/chave-rede', { dados: d }))),
    el('div', { class: 'cartao' }, el('h2', {}, 'Atualização'), el('p', {}, `Versão ${estado.versao}.`), el('button', { class: 'sec', onclick: async ev => { try { const r = await api('atualizacao/verificar', { dados: {} }); ev.target.textContent = r.disponivel ? 'Atualização baixada' : 'Sem novidade'; } catch (e) { ev.target.textContent = 'Sem conexão'; } } }, 'Procurar atualização')));
  },

  async portal(m) {
    const l = await api('portal');
    m.replaceChildren(el('h1', {}, 'Boletim e conteúdos'));
    if (!l.length) m.append(el('p', {}, 'Nenhuma matrícula encontrada.'));
    for (const a of l) {
      m.append(el('h2', {}, `${a.aluno} · ${a.turma}`), tabela([{ t: 'Componente', c: 'componente' }, { t: 'Final', c: 'final' }, { t: 'Frequência', c: 'frequencia' }, { t: 'Resultado', c: 'resultado' }], a.boletim.linhas),
        el('p', {}, el('a', { href: `/api/documento/boletim?matricula=${a.matricula_id}`, target: '_blank' }, 'Imprimir boletim')), el('h2', {}, 'Conteúdos'),
        tabela([{ t: 'Componente', c: 'componente' }, { t: 'Título', c: 'titulo' }, { t: 'Texto', c: 'corpo' }, { t: 'Link', f: x => (/^https?:\/\//.test(x.link) ? el('a', { href: x.link, target: '_blank', rel: 'noopener noreferrer' }, 'Abrir') : '') }], a.conteudos, 'Nenhum conteúdo publicado.'));
    }
  },
};

function lerFila() { return JSON.parse(localStorage.getItem(FILA) || '[]'); }
function guardarNaFila(ev) { const f = lerFila(); f.push(ev); localStorage.setItem(FILA, JSON.stringify(f)); }

async function enviarFila() {
  if (!usuario) return 0;
  const meus = lerFila().filter(e => e.dono === usuario.id && !e.recusada);
  if (!meus.length) return 0;
  try {
    const r = await api('chamada/lote', { dados: { eventos: meus.slice(0, 200) } });
    const feitos = new Set(r.resultados.filter(x => !x.erro).map(x => x.uid));
    const recusas = Object.fromEntries(r.resultados.filter(x => x.erro).map(x => [x.uid, x.erro]));
    const atual = lerFila().filter(e => !feitos.has(e.uid)).map(e => (recusas[e.uid] ? { ...e, recusada: recusas[e.uid] } : e));
    localStorage.setItem(FILA, JSON.stringify(atual));
    return atual.filter(e => e.dono === usuario.id && !e.recusada).length;
  } catch (e) { return lerFila().filter(x => x.dono === usuario.id && !x.recusada).length; }
}

function sair() {
  for (const k of Object.keys(localStorage)) if (k.startsWith('escola_ch_')) localStorage.removeItem(k);
}

window.addEventListener('online', enviarFila);
setInterval(enviarFila, 60000);
iniciar().catch(e => telaAviso(e.message));
