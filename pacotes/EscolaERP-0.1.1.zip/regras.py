"""ESCOLA-ERP — regras de frequência e avaliação, sem acesso ao banco.

Todo limite vem de configuração da rede; os padrões ficam em PADRAO.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import datetime as dt
import math
import re

PADRAO = {
    'media_aprovacao': 6.0,
    'nota_maxima': 10.0,
    'frequencia_minima': 75.0,
    'frequencia_minima_infantil': 60.0,
    'presenca_menor_6': 60.0,
    'presenca_geral': 75.0,
    'pe_de_meia': 80.0,
    'fracao_conselho_tutelar': 0.30,
    'dias_letivos': 200,
    'carga_fundamental': 800,
    'carga_medio': 1000,
    'recuperacao_substitui': True,
    'frequencia_por_componente': False,
}
HABILIDADE = re.compile(r'^(EI\d{2}[A-Z]{2}\d{2}|EF\d{2}[A-Z]{2}\d{2}|EF\d{2}[A-Z]{2}\d{2}[A-Z]?|EM13[A-Z]{3}\d{3}|[A-Z0-9-]{4,24})$')


def configurar(rede=None):
    final = dict(PADRAO)
    final.update({k: v for k, v in (rede or {}).items() if k in PADRAO})
    return final


def idade_em(nascimento, data):
    n = dt.date.fromisoformat(nascimento)
    return data.year - n.year - ((data.month, data.day) < (n.month, n.day))


def frequencia(horas_presentes, horas_ofertadas):
    if horas_ofertadas <= 0:
        return None
    return round(100.0 * horas_presentes / horas_ofertadas, 2)


def minimo_de_frequencia(etapa, cfg):
    return cfg['frequencia_minima_infantil'] if etapa == 'infantil' else cfg['frequencia_minima']


def limite_conselho_tutelar(etapa, cfg):
    """Percentual de faltas que dispara o aviso (art. 12, VIII, LDB; fração configurável pela rede)."""
    return round((100.0 - minimo_de_frequencia(etapa, cfg)) * cfg['fracao_conselho_tutelar'], 2)


def alertas_frequencia(percentual, etapa, idade, cfg, ensino_medio=False):
    if percentual is None:
        return []
    alertas = []
    faltas = 100.0 - percentual
    if faltas > limite_conselho_tutelar(etapa, cfg):
        alertas.append('conselho_tutelar')
    if percentual < minimo_de_frequencia(etapa, cfg):
        alertas.append('reprovacao_frequencia')
    if idade is not None and 4 <= idade < 18:
        minimo = cfg['presenca_menor_6'] if idade < 6 else cfg['presenca_geral']
        if percentual < minimo:
            alertas.append('sistema_presenca')
    if ensino_medio and percentual < cfg['pe_de_meia']:
        alertas.append('pe_de_meia')
    return alertas


def media_ponderada(itens):
    validos = [(float(v), float(p)) for v, p in itens if v is not None and float(p) > 0]
    soma = sum(p for _, p in validos)
    if not soma:
        return None
    return round(sum(v * p for v, p in validos) / soma, 2)


def media_com_recuperacao(media, recuperacao, cfg):
    if recuperacao is None:
        return media
    if media is None:
        return float(recuperacao)
    if cfg['recuperacao_substitui']:
        return max(media, float(recuperacao))
    return round(max(media, (media + float(recuperacao)) / 2), 2)


def resultado_final(media, percentual, etapa, cfg, decisao_conselho=None):
    """Resultado por componente. Educação infantil não tem promoção por nota (art. 31, I, LDB)."""
    if etapa == 'infantil':
        return 'acompanhamento'
    if percentual is not None and percentual < minimo_de_frequencia(etapa, cfg):
        return 'reprovado_frequencia'
    if decisao_conselho in ('aprovado', 'reprovado'):
        return decisao_conselho
    if media is None:
        return 'pendente'
    return 'aprovado' if media >= cfg['media_aprovacao'] else 'recuperacao'


def validar_nota(valor, cfg):
    if valor is None or valor == '':
        return None
    numero = float(str(valor).replace(',', '.'))
    if not 0 <= numero <= cfg['nota_maxima']:
        raise ValueError(f'nota fora de 0 a {cfg["nota_maxima"]}')
    return round(numero, 2)


def numero_finito(valor, minimo=None):
    numero = float(valor)
    if not math.isfinite(numero) or (minimo is not None and numero < minimo):
        raise ValueError('número inválido')
    return numero


def validar_cpf(cpf):
    d = re.sub(r'\D', '', cpf or '')
    if len(d) != 11 or len(set(d)) == 1:
        return False
    for t in (9, 10):
        soma = sum(int(d[i]) * (t + 1 - i) for i in range(t))
        if (soma * 10 % 11) % 10 != int(d[t]):
            return False
    return True


def validar_habilidade(codigo):
    return bool(HABILIDADE.match(codigo or ''))
