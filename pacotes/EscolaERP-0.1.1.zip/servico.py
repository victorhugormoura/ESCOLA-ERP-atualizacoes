"""ESCOLA-ERP — regras de negócio sobre o banco.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import datetime as dt
import json
import re

import banco as bd
import regras

PAPEIS_GESTAO = ('direcao', 'secretaria', 'coordenacao')
PAPEIS_EQUIPE = PAPEIS_GESTAO + ('professor',)
CAMPOS_CIFRADOS = ('cpf', 'nis', 'saude', 'necessidade_especifica', 'restricao_alimentar', 'endereco', 'telefone', 'email')
CAMPOS_RESTRITOS = CAMPOS_CIFRADOS + ('cor_raca', 'transporte')
INTEIROS = ('ano', 'ordem', 'ano_id', 'turma_id', 'componente_id', 'professor_id', 'turma_componente_id', 'vagas', 'exemplares', 'servidas', 'duracao_s', 'aluno_id', 'pessoa_id', 'versao',
            'multisserie', 'eh_aluno', 'eh_responsavel', 'eh_servidor', 'pnld', 'rural', 'ativo', 'publicado')
DECIMAIS = ('carga_horaria', 'carga_semanal', 'valor', 'minimo')

RECURSOS = {
    'pessoa': {'campos': ('nome', 'nome_social', 'nascimento', 'sexo', 'cor_raca', 'nacionalidade', 'naturalidade', 'cpf', 'nis', 'id_inep',
                          'endereco', 'telefone', 'email', 'saude', 'restricao_alimentar', 'necessidade_especifica', 'transporte',
                          'eh_aluno', 'eh_responsavel', 'eh_servidor'),
               'obrigatorios': ('nome',), 'escrever': ('direcao', 'secretaria'), 'ler': PAPEIS_GESTAO, 'ordem': 'nome'},
    'ano_letivo': {'campos': ('ano', 'inicio', 'fim'), 'obrigatorios': ('ano', 'inicio', 'fim'),
                   'escrever': ('direcao', 'secretaria'), 'ler': PAPEIS_EQUIPE, 'ordem': 'ano DESC'},
    'periodo': {'campos': ('ano_id', 'nome', 'ordem', 'inicio', 'fim'), 'obrigatorios': ('ano_id', 'nome', 'ordem', 'inicio', 'fim'),
                'escrever': ('direcao', 'secretaria'), 'ler': PAPEIS_EQUIPE, 'ordem': 'ordem'},
    'dia_calendario': {'campos': ('ano_id', 'data', 'tipo', 'descricao', 'codigo_justificativa'), 'obrigatorios': ('ano_id', 'data', 'tipo'),
                       'escrever': ('direcao', 'secretaria'), 'ler': PAPEIS_EQUIPE, 'ordem': 'data'},
    'componente': {'campos': ('nome', 'area'), 'obrigatorios': ('nome',), 'escrever': ('direcao', 'secretaria', 'coordenacao'),
                   'ler': PAPEIS_EQUIPE, 'ordem': 'nome'},
    'habilidade': {'campos': ('codigo', 'descricao', 'etapa', 'local'), 'obrigatorios': ('codigo', 'descricao'),
                   'escrever': ('direcao', 'coordenacao'), 'ler': PAPEIS_EQUIPE, 'ordem': 'codigo', 'chave': 'codigo'},
    'turma': {'campos': ('ano_id', 'nome', 'etapa', 'serie', 'turno', 'sala', 'multisserie', 'vagas'), 'obrigatorios': ('ano_id', 'nome', 'etapa'),
              'escrever': ('direcao', 'secretaria'), 'ler': PAPEIS_EQUIPE, 'ordem': 'nome'},
    'turma_componente': {'campos': ('turma_id', 'componente_id', 'professor_id', 'carga_horaria'), 'obrigatorios': ('turma_id', 'componente_id'),
                         'escrever': ('direcao', 'secretaria', 'coordenacao'), 'ler': PAPEIS_EQUIPE, 'ordem': 'id'},
    'sinal': {'campos': ('hora', 'descricao', 'duracao_s', 'dias', 'ativo'), 'obrigatorios': ('hora',),
              'escrever': ('direcao', 'secretaria'), 'ler': PAPEIS_EQUIPE, 'ordem': 'hora'},
    'plano_aula': {'campos': ('turma_componente_id', 'semana', 'objetivos', 'habilidades', 'metodologia'), 'obrigatorios': ('turma_componente_id', 'semana'),
                   'escrever': PAPEIS_EQUIPE, 'ler': PAPEIS_EQUIPE, 'ordem': 'semana DESC', 'autor': True},
    'conteudo': {'campos': ('turma_componente_id', 'titulo', 'corpo', 'link', 'habilidades', 'publicado'), 'obrigatorios': ('turma_componente_id', 'titulo'),
                 'escrever': PAPEIS_EQUIPE, 'ler': PAPEIS_EQUIPE, 'ordem': 'id DESC', 'autor': True},
}
ADMIN = ('direcao', 'secretaria')
RECURSOS.update({
    'patrimonio': {'campos': ('tombo', 'descricao', 'local', 'origem', 'valor', 'situacao'), 'obrigatorios': ('tombo', 'descricao'), 'escrever': ADMIN, 'ler': ADMIN, 'ordem': 'tombo',
                   'titulo': 'Patrimônio'},
    'almoxarifado': {'campos': ('item', 'unidade', 'minimo', 'validade'), 'obrigatorios': ('item',), 'escrever': ADMIN, 'ler': ADMIN, 'ordem': 'item', 'titulo': 'Almoxarifado', 'mostra': ('saldo',)},
    'acervo': {'campos': ('codigo', 'titulo', 'autor', 'pnld', 'exemplares'), 'obrigatorios': ('codigo', 'titulo'), 'escrever': ADMIN + ('coordenacao',), 'ler': PAPEIS_EQUIPE, 'ordem': 'titulo', 'titulo': 'Biblioteca'},
    'rota_transporte': {'campos': ('nome', 'veiculo', 'motorista', 'turno', 'rural'), 'obrigatorios': ('nome',), 'escrever': ADMIN, 'ler': ADMIN, 'ordem': 'nome', 'titulo': 'Transporte'},
    'cardapio': {'campos': ('data', 'refeicao', 'descricao', 'servidas'), 'obrigatorios': ('data', 'descricao'), 'escrever': ADMIN, 'ler': PAPEIS_EQUIPE, 'ordem': 'data DESC', 'titulo': 'Merenda'},
    'ocorrencia': {'campos': ('aluno_id', 'data', 'tipo', 'descricao', 'encaminhamento'), 'obrigatorios': ('data', 'descricao'), 'escrever': PAPEIS_GESTAO, 'ler': ('direcao', 'coordenacao'), 'ordem': 'data DESC',
                   'titulo': 'Ocorrências', 'sensivel': True, 'cifrados': ('descricao', 'encaminhamento')},
    'lotacao': {'campos': ('pessoa_id', 'funcao', 'vinculo', 'carga_semanal', 'inicio', 'fim'), 'obrigatorios': ('pessoa_id', 'funcao'), 'escrever': ADMIN, 'ler': ADMIN, 'ordem': 'id', 'titulo': 'Servidores'},
    'livro_caixa': {'campos': ('data', 'programa', 'descricao', 'tipo', 'valor', 'documento'), 'obrigatorios': ('data', 'descricao', 'tipo', 'valor'), 'escrever': ('direcao',), 'ler': ADMIN, 'ordem': 'data DESC', 'titulo': 'Livro-caixa'},
    'plano_individual': {'campos': ('aluno_id', 'versao', 'estudo_de_caso', 'objetivos', 'recursos', 'data'), 'obrigatorios': ('aluno_id', 'data'), 'escrever': ('direcao', 'coordenacao'), 'ler': ('direcao', 'coordenacao'), 'ordem': 'data DESC',
                         'titulo': 'PEI/PAEE', 'sensivel': True, 'cifrados': ('estudo_de_caso', 'objetivos', 'recursos')},
})


class Erro(Exception):
    def __init__(self, mensagem, codigo=400):
        super().__init__(mensagem)
        self.codigo = codigo


def exigir(usuario, *papeis):
    if not usuario or usuario['papel'] not in papeis:
        raise Erro('sem permissão', 403)


class Escola:
    def __init__(self, base, cofre):
        self.b = base
        self.cofre = cofre

    def cfg(self):
        return regras.configurar(self.b.obter('regras', {}))

    def _cifrar_pessoa(self, dados):
        for campo in CAMPOS_CIFRADOS:
            if campo in dados:
                dados[campo] = self.cofre.cifrar(dados[campo])
        return dados

    def _abrir_pessoa(self, linha, usuario):
        for campo in CAMPOS_CIFRADOS:
            linha[campo] = self.cofre.decifrar(linha.get(campo, ''))
        if usuario['papel'] not in ('direcao', 'secretaria'):
            for campo in CAMPOS_RESTRITOS:
                linha[campo] = ''
        return linha

    def _abrir_recurso(self, recurso, linha):
        for campo in RECURSOS[recurso].get('cifrados', ()):
            linha[campo] = self.cofre.decifrar(linha.get(campo, ''))
        return linha

    def _turmas_do_professor(self, usuario):
        return {l['turma_id'] for l in self.b.todos('SELECT turma_id FROM turma_componente WHERE professor_id=?', usuario['id'])}

    def exigir_turma(self, usuario, turma_id):
        """Equipe de gestão vê tudo; professor só as turmas em que leciona."""
        exigir(usuario, *PAPEIS_EQUIPE)
        if usuario['papel'] == 'professor' and turma_id not in self._turmas_do_professor(usuario):
            raise Erro('esta turma não é sua', 403)

    def exigir_matricula(self, usuario, matricula_id):
        m = self.b.um('SELECT turma_id FROM matricula WHERE id=?', matricula_id)
        if not m:
            raise Erro('matrícula não encontrada', 404)
        self.exigir_turma(usuario, m['turma_id'])

    def turma_da_avaliacao(self, avaliacao_id):
        a = self.b.um('SELECT tc.turma_id FROM avaliacao av JOIN turma_componente tc ON tc.id=av.turma_componente_id WHERE av.id=?', avaliacao_id)
        if not a:
            raise Erro('avaliação não encontrada', 404)
        return a['turma_id']

    def notas_da_avaliacao(self, avaliacao_id, usuario):
        self.exigir_turma(usuario, self.turma_da_avaliacao(avaliacao_id))
        return self.b.todos('SELECT matricula_id, valor FROM nota WHERE avaliacao_id=?', avaliacao_id)

    # ------------------------------------------------------------ cadastros
    def listar(self, recurso, usuario, filtros=None):
        r = self._recurso(recurso)
        exigir(usuario, *r['ler'])
        onde, args = [], []
        for campo, valor in (filtros or {}).items():
            if campo in r['campos'] and campo not in r.get('cifrados', ()) and not (recurso == 'pessoa' and campo in CAMPOS_RESTRITOS):
                onde.append(f'{campo}=?')
                args.append(valor)
            elif campo == 'busca' and recurso == 'pessoa':
                onde.append('nome LIKE ?')
                args.append(f'%{valor}%')
        if recurso in ('conteudo', 'plano_aula') and usuario['papel'] == 'professor':
            onde.append('turma_componente_id IN (SELECT id FROM turma_componente WHERE professor_id=?)')
            args.append(usuario['id'])
        sql = f'SELECT * FROM {recurso}' + (' WHERE ' + ' AND '.join(onde) if onde else '') + f' ORDER BY {r["ordem"]} LIMIT 500'
        linhas = self.b.todos(sql, *args)
        if recurso == 'pessoa' or r.get('sensivel'):
            with self.b.transacao() as c:
                self.b.auditar(c, usuario, 'leitura', recurso, 'lista', 'consulta escolar', f'{len(linhas)} registros')
        if recurso == 'pessoa':
            return [self._abrir_pessoa(l, usuario) for l in linhas]
        return [self._abrir_recurso(recurso, l) for l in linhas]

    def metadados(self, usuario):
        return [{'recurso': k, 'titulo': r['titulo'], 'campos': list(r['campos']), 'obrigatorios': list(r['obrigatorios']), 'mostra': list(r.get('mostra', ())), 'escrever': usuario['papel'] in r['escrever']}
                for k, r in RECURSOS.items() if 'titulo' in r and usuario['papel'] in r['ler']]

    def movimentar(self, dados, usuario):
        exigir(usuario, *ADMIN)
        quantidade = float(dados['quantidade'])
        if quantidade <= 0 or dados.get('tipo') not in ('entrada', 'saida'):
            raise Erro('movimento inválido')
        data = dados.get('data') or dt.date.today().isoformat()
        self._data(data)
        delta = quantidade if dados['tipo'] == 'entrada' else -quantidade
        with self.b.transacao() as c:
            item = c.execute('SELECT * FROM almoxarifado WHERE id=?', (dados['item_id'],)).fetchone()
            if not item:
                raise Erro('item não encontrado', 404)
            if item['saldo'] + delta < 0:
                raise Erro('saldo insuficiente')
            c.execute('UPDATE almoxarifado SET saldo=saldo+? WHERE id=?', (delta, item['id']))
            c.execute('INSERT INTO movimento_estoque (item_id,tipo,quantidade,data,motivo) VALUES (?,?,?,?,?)', (item['id'], dados['tipo'], quantidade, data, str(dados.get('motivo', ''))))
            self.b.auditar(c, usuario, dados['tipo'], 'almoxarifado', item['id'], 'controle de estoque', str(quantidade))
        return {'saldo': item['saldo'] + delta}

    def emprestar(self, dados, usuario):
        exigir(usuario, *ADMIN, 'coordenacao')
        with self.b.transacao() as c:
            a = c.execute('SELECT * FROM acervo WHERE id=?', (dados['acervo_id'],)).fetchone()
            if not a:
                raise Erro('livro não encontrado', 404)
            fora = c.execute('SELECT count(*) FROM emprestimo WHERE acervo_id=? AND devolucao IS NULL', (a['id'],)).fetchone()[0]
            if fora >= a['exemplares']:
                raise Erro('todos os exemplares estão emprestados')
            cur = c.execute('INSERT INTO emprestimo (acervo_id,pessoa_id,retirada,prazo) VALUES (?,?,?,?)', (a['id'], dados['pessoa_id'], dt.date.today().isoformat(), dados.get('prazo')))
            self.b.auditar(c, usuario, 'emprestar', 'acervo', a['id'], 'biblioteca')
        return {'id': cur.lastrowid}

    def devolver(self, emprestimo_id, usuario):
        exigir(usuario, *ADMIN, 'coordenacao')
        with self.b.transacao() as c:
            if not c.execute('UPDATE emprestimo SET devolucao=? WHERE id=? AND devolucao IS NULL', (dt.date.today().isoformat(), emprestimo_id)).rowcount:
                raise Erro('empréstimo não encontrado', 404)
        return {'ok': True}

    def ler_pessoa(self, pessoa_id, usuario):
        exigir(usuario, *PAPEIS_EQUIPE)
        if usuario['papel'] == 'professor':
            turmas = self._turmas_do_professor(usuario)
            if not any(m['turma_id'] in turmas for m in self.b.todos('SELECT turma_id FROM matricula WHERE aluno_id=?', pessoa_id)):
                raise Erro('este aluno não é da sua turma', 403)
        l = self.b.um('SELECT * FROM pessoa WHERE id=?', pessoa_id)
        if not l:
            raise Erro('pessoa não encontrada', 404)
        dados = self._abrir_pessoa(dict(l), usuario)
        with self.b.transacao() as c:
            self.b.auditar(c, usuario, 'leitura', 'pessoa', pessoa_id, 'atendimento escolar', 'ficha')
        dados['vinculos'] = self.b.todos('SELECT v.*, p.nome FROM vinculo v JOIN pessoa p ON p.id=v.responsavel_id WHERE v.aluno_id=?', pessoa_id)
        return dados

    def criar(self, recurso, dados, usuario):
        r = self._recurso(recurso)
        exigir(usuario, *r['escrever'])
        limpos = self._validar(recurso, r, dados, novo=True)
        self._conferir_dono(recurso, limpos.get('turma_componente_id'), usuario)
        limpos = self._cifrar_recurso(recurso, limpos)
        if r.get('autor'):
            limpos.update(autor_id=usuario['id'], criado_em=bd.agora())
        if recurso == 'pessoa':
            limpos.update(uid=bd.novo_uid(), criado_em=bd.agora())
            self._cifrar_pessoa(limpos)
        campos = ','.join(limpos)
        marcas = ','.join('?' * len(limpos))
        with self.b.transacao() as c:
            try:
                cur = c.execute(f'INSERT INTO {recurso} ({campos}) VALUES ({marcas})', tuple(limpos.values()))
            except bd.sqlite3.IntegrityError as e:
                raise Erro(f'registro repetido ou inválido: {e}') from e
            chave = limpos[r['chave']] if 'chave' in r else cur.lastrowid
            self.b.auditar(c, usuario, 'criar', recurso, chave, 'cadastro escolar')
        return {'id': chave}

    def alterar(self, recurso, registro, dados, usuario):
        r = self._recurso(recurso)
        exigir(usuario, *r['escrever'])
        limpos = self._validar(recurso, r, dados, novo=False)
        if not limpos:
            raise Erro('nada para alterar')
        if r.get('autor'):
            atual = self.b.um(f'SELECT turma_componente_id FROM {recurso} WHERE id=?', registro)
            if not atual:
                raise Erro('registro não encontrado', 404)
            self._conferir_dono(recurso, atual['turma_componente_id'], usuario)
            self._conferir_dono(recurso, limpos.get('turma_componente_id'), usuario)
        limpos = self._cifrar_recurso(recurso, limpos)
        if recurso == 'pessoa':
            self._cifrar_pessoa(limpos)
        chave = r.get('chave', 'id')
        conjunto = ','.join(f'{c}=?' for c in limpos)
        with self.b.transacao() as c:
            try:
                n = c.execute(f'UPDATE {recurso} SET {conjunto} WHERE {chave}=?', (*limpos.values(), registro)).rowcount
            except bd.sqlite3.IntegrityError as e:
                raise Erro(f'registro repetido ou inválido: {e}') from e
            if not n:
                raise Erro('registro não encontrado', 404)
            self.b.auditar(c, usuario, 'alterar', recurso, registro, 'cadastro escolar', ','.join(limpos))
        return {'ok': True}

    def _conferir_dono(self, recurso, tc_id, usuario):
        if RECURSOS[recurso].get('autor') and tc_id is not None:
            self._turma_componente(int(tc_id), usuario)

    def _cifrar_recurso(self, recurso, limpos):
        for campo in RECURSOS[recurso].get('cifrados', ()):
            if campo in limpos:
                limpos[campo] = self.cofre.cifrar(limpos[campo])
        return limpos

    def _recurso(self, nome):
        if nome not in RECURSOS:
            raise Erro('recurso desconhecido', 404)
        return RECURSOS[nome]

    def _validar(self, nome, r, dados, novo):
        limpos = {c: dados[c] for c in r['campos'] if c in dados}
        if novo:
            faltam = [c for c in r['obrigatorios'] if limpos.get(c) in (None, '')]
            if faltam:
                raise Erro('campo obrigatório: ' + ', '.join(faltam))
        for campo, valor in limpos.items():
            if isinstance(valor, str):
                limpos[campo] = valor.strip()
        try:
            for campo in limpos:
                if limpos[campo] in (None, ''):
                    continue
                if campo in INTEIROS:
                    limpos[campo] = int(limpos[campo])
                elif campo in DECIMAIS:
                    limpos[campo] = regras.numero_finito(limpos[campo], 0)
        except (TypeError, ValueError, OverflowError) as e:
            raise Erro(f'número inválido em {campo}') from e
        if nome == 'pessoa':
            if limpos.get('cpf') and not regras.validar_cpf(limpos['cpf']):
                raise Erro('CPF inválido')
            if limpos.get('id_inep') and not re.fullmatch(r'\d{12}', limpos['id_inep']):
                raise Erro('ID INEP deve ter 12 dígitos')
            if limpos.get('nascimento'):
                self._data(limpos['nascimento'])
        for campo in ('inicio', 'fim', 'data'):
            if limpos.get(campo):
                self._data(limpos[campo])
        if nome == 'habilidade' and limpos.get('codigo') and not regras.validar_habilidade(limpos['codigo']):
            raise Erro('código de habilidade inválido')
        if nome == 'sinal' and limpos.get('hora') and not re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d', limpos['hora']):
            raise Erro('hora inválida, use HH:MM')
        return limpos

    @staticmethod
    def _data(texto):
        try:
            return dt.date.fromisoformat(texto)
        except (TypeError, ValueError) as e:
            raise Erro(f'data inválida: {texto}') from e

    def possiveis_duplicados(self, nome, nascimento):
        return self.b.todos('SELECT id, nome, nascimento FROM pessoa WHERE lower(nome)=lower(?) AND nascimento=? AND anonimizado=0', nome.strip(), nascimento)

    def desvincular(self, aluno_id, responsavel_id, usuario):
        exigir(usuario, 'direcao', 'secretaria')
        with self.b.transacao() as c:
            if not c.execute('DELETE FROM vinculo WHERE aluno_id=? AND responsavel_id=?', (aluno_id, responsavel_id)).rowcount:
                raise Erro('vínculo não encontrado', 404)
            self.b.auditar(c, usuario, 'desvincular', 'vinculo', f'{aluno_id}:{responsavel_id}', 'cadastro escolar')
        return {'ok': True}

    def vincular(self, aluno_id, responsavel_id, parentesco, usuario):
        exigir(usuario, 'direcao', 'secretaria')
        with self.b.transacao() as c:
            c.execute('INSERT OR REPLACE INTO vinculo (aluno_id,responsavel_id,parentesco) VALUES (?,?,?)', (aluno_id, responsavel_id, parentesco))
            self.b.auditar(c, usuario, 'vincular', 'vinculo', f'{aluno_id}:{responsavel_id}', 'cadastro escolar')
        return {'ok': True}

    # ------------------------------------------------------------ matrícula
    def _matricular(self, c, aluno_id, turma_id, usuario, entrada):
        turma = c.execute('SELECT t.*, a.ano, a.encerrado FROM turma t JOIN ano_letivo a ON a.id=t.ano_id WHERE t.id=?', (turma_id,)).fetchone()
        if not turma:
            raise Erro('turma não encontrada', 404)
        if turma['encerrado']:
            raise Erro('ano letivo encerrado')
        if not c.execute('SELECT id FROM pessoa WHERE id=?', (aluno_id,)).fetchone():
            raise Erro('aluno não encontrado', 404)
        ativa = c.execute("""SELECT t.nome FROM matricula m JOIN turma t ON t.id=m.turma_id
                             WHERE m.aluno_id=? AND m.situacao='cursando' AND t.ano_id=?""", (aluno_id, turma['ano_id'])).fetchone()
        if ativa:
            raise Erro(f'aluno já matriculado na turma {ativa["nome"]}')
        ocupadas = c.execute("SELECT count(*) FROM matricula WHERE turma_id=? AND situacao='cursando'", (turma_id,)).fetchone()[0]
        if ocupadas >= turma['vagas']:
            raise Erro('turma sem vagas')
        numero = c.execute('SELECT coalesce(max(numero),0)+1 FROM matricula WHERE turma_id=?', (turma_id,)).fetchone()[0]
        sequencial = c.execute('SELECT coalesce(max(id),0)+1 FROM matricula').fetchone()[0]
        codigo = f'{turma["ano"]}{sequencial:06d}'
        try:
            cur = c.execute('INSERT INTO matricula (uid,codigo,aluno_id,turma_id,numero,entrada) VALUES (?,?,?,?,?,?)',
                            (bd.novo_uid(), codigo, aluno_id, turma_id, numero, entrada))
        except bd.sqlite3.IntegrityError as e:
            raise Erro('aluno já teve matrícula nesta turma') from e
        c.execute('UPDATE pessoa SET eh_aluno=1 WHERE id=?', (aluno_id,))
        self.b.auditar(c, usuario, 'matricular', 'matricula', cur.lastrowid, 'matrícula escolar')
        return {'id': cur.lastrowid, 'codigo': codigo, 'numero': numero}

    def matricular(self, aluno_id, turma_id, usuario, entrada=None):
        exigir(usuario, 'direcao', 'secretaria')
        entrada = entrada or dt.date.today().isoformat()
        self._data(entrada)
        with self.b.transacao() as c:
            return self._matricular(c, aluno_id, turma_id, usuario, entrada)

    def alunos_da_turma(self, turma_id):
        return self.b.todos("""SELECT m.id AS matricula_id, m.numero, m.situacao, m.codigo, p.id AS aluno_id, p.nome, p.nome_social, p.nascimento, p.id_inep
                               FROM matricula m JOIN pessoa p ON p.id=m.aluno_id WHERE m.turma_id=? ORDER BY m.numero""", turma_id)

    def _sair(self, c, matricula_id, situacao, usuario, escola_outra, data):
        n = c.execute("UPDATE matricula SET situacao=?, saida=? WHERE id=? AND situacao='cursando'", (situacao, data, matricula_id)).rowcount
        if not n:
            raise Erro('matrícula não está ativa', 404)
        if situacao == 'transferido':
            c.execute('INSERT INTO transferencia (uid,matricula_id,sentido,escola_outra,data) VALUES (?,?,?,?,?)',
                      (bd.novo_uid(), matricula_id, 'saida', escola_outra, data))
        self.b.auditar(c, usuario, 'saida', 'matricula', matricula_id, 'movimentação escolar', situacao)

    def sair(self, matricula_id, situacao, usuario, escola_outra='', data=None):
        exigir(usuario, 'direcao', 'secretaria')
        if situacao not in ('transferido', 'abandono', 'falecido'):
            raise Erro('situação inválida')
        data = data or dt.date.today().isoformat()
        self._data(data)
        with self.b.transacao() as c:
            self._sair(c, matricula_id, situacao, usuario, escola_outra, data)
        return {'ok': True}

    def remanejar(self, matricula_id, turma_nova, usuario):
        """Saída e nova matrícula na mesma transação: se a nova falhar, a antiga fica como estava."""
        exigir(usuario, 'direcao', 'secretaria')
        hoje = dt.date.today().isoformat()
        with self.b.transacao() as c:
            m = c.execute('SELECT * FROM matricula WHERE id=?', (matricula_id,)).fetchone()
            if not m:
                raise Erro('matrícula não encontrada', 404)
            self._sair(c, matricula_id, 'remanejado', usuario, '', hoje)
            return self._matricular(c, m['aluno_id'], turma_nova, usuario, hoje)

    # ------------------------------------------------------------ diário
    def _turma_componente(self, tc_id, usuario):
        exigir(usuario, *PAPEIS_EQUIPE)
        tc = self.b.um("""SELECT tc.*, t.nome AS turma, t.etapa, t.ano_id, c.nome AS componente FROM turma_componente tc
                          JOIN turma t ON t.id=tc.turma_id JOIN componente c ON c.id=tc.componente_id WHERE tc.id=?""", tc_id)
        if not tc:
            raise Erro('componente da turma não encontrado', 404)
        if usuario['papel'] == 'professor' and tc['professor_id'] != usuario['id']:
            raise Erro('esta turma não é sua', 403)
        return tc

    def minhas_turmas(self, usuario):
        exigir(usuario, *PAPEIS_EQUIPE)
        sql = """SELECT tc.id, tc.turma_id, t.nome AS turma, t.etapa, c.nome AS componente, tc.carga_horaria, u.nome AS professor
                 FROM turma_componente tc JOIN turma t ON t.id=tc.turma_id JOIN componente c ON c.id=tc.componente_id
                 JOIN ano_letivo a ON a.id=t.ano_id LEFT JOIN usuario u ON u.id=tc.professor_id WHERE a.encerrado=0"""
        if usuario['papel'] == 'professor':
            return self.b.todos(sql + ' AND tc.professor_id=? ORDER BY t.nome, c.nome', usuario['id'])
        return self.b.todos(sql + ' ORDER BY t.nome, c.nome')

    def _conferir_aberto(self, c, ano_id, data):
        ano = c.execute('SELECT * FROM ano_letivo WHERE id=?', (ano_id,)).fetchone()
        if ano['encerrado']:
            raise Erro('ano letivo encerrado')
        if not ano['inicio'] <= data <= ano['fim']:
            raise Erro(f'{data} fora do ano letivo')
        if dt.date.fromisoformat(data) > dt.date.today() + dt.timedelta(days=1):
            raise Erro('data no futuro')
        if c.execute('SELECT 1 FROM periodo WHERE ano_id=? AND fechado=1 AND inicio<=? AND fim>=?', (ano_id, data, data)).fetchone():
            raise Erro('período fechado; peça alteração à direção')

    def _marcas(self, dados, turma_id):
        validas = {m['id'] for m in self.b.todos('SELECT id FROM matricula WHERE turma_id=?', turma_id)}
        marcas = {int(k): 1 if v else 0 for k, v in (dados.get('marcas') or {}).items()}
        if set(marcas) - validas:
            raise Erro('aluno fora desta turma')
        return marcas

    def _gravar_aula(self, c, uid, tc, dados, marcas, usuario, ocorreu, aparelho):
        agora = bd.agora()
        existente = c.execute('SELECT * FROM aula WHERE turma_componente_id=? AND data=?', (tc['id'], dados['data'])).fetchone()
        base = existente or {'horas': 1, 'conteudo': '', 'habilidades': ''}
        campos = tuple(dados[k] if dados.get(k) is not None else base[k] for k in ('horas', 'conteudo', 'habilidades'))
        if existente:
            aula_id = existente['id']
            c.execute('UPDATE aula SET horas=?, conteudo=?, habilidades=? WHERE id=?', (*campos, aula_id))
        else:
            aula_id = c.execute("""INSERT INTO aula (uid,turma_componente_id,data,horas,conteudo,habilidades,professor_id,ocorreu_em,sincronizou_em)
                                   VALUES (?,?,?,?,?,?,?,?,?)""", (uid, tc['id'], dados['data'], *campos, usuario['id'], ocorreu, agora)).lastrowid
        for mid, presente in marcas.items():
            c.execute("""INSERT INTO presenca (aula_id,matricula_id,presente,ocorreu_em,sincronizou_em,aparelho) VALUES (?,?,?,?,?,?)
                         ON CONFLICT(aula_id,matricula_id) DO UPDATE SET presente=excluded.presente, ocorreu_em=excluded.ocorreu_em,
                         sincronizou_em=excluded.sincronizou_em, aparelho=excluded.aparelho""", (aula_id, mid, presente, ocorreu, agora, aparelho[:80]))
        return aula_id

    def registrar_aula(self, dados, usuario, aparelho=''):
        """Idempotente pelo uid do evento: o celular pode reenviar a fila sem duplicar."""
        exigir(usuario, *PAPEIS_EQUIPE)
        uid = str(dados.get('uid') or '')
        if not re.fullmatch(r'[0-9a-fA-F-]{36}', uid):
            raise Erro('uid do evento inválido')
        data = dados.get('data', '')
        self._data(data)
        ocorreu = str(dados.get('ocorreu_em') or bd.agora())
        tc = self._turma_componente(int(dados['turma_componente_id']), usuario)
        horas = regras.numero_finito(dados.get('horas', 1))
        if not 0 < horas <= 12:
            raise Erro('horas da aula fora do intervalo')
        marcas = self._marcas(dados, tc['turma_id'])
        with self.b.transacao() as c:
            if c.execute('SELECT 1 FROM evento_recebido WHERE uid=?', (uid,)).fetchone():
                return {'ok': True, 'repetido': True}
            self._conferir_aberto(c, tc['ano_id'], data)
            dia = c.execute('SELECT tipo FROM dia_calendario WHERE ano_id=? AND data=?', (tc['ano_id'], data)).fetchone()
            if dia and dia['tipo'] != 'letivo':
                raise Erro(f'{data} não é dia letivo ({dia["tipo"]})')
            if tc['validado_ate'] and data <= tc['validado_ate']:
                novo = {k: dados[k] for k in ('data', 'horas', 'conteudo', 'habilidades') if k in dados}
                novo.update(uid=uid, turma_componente_id=tc['id'], marcas=marcas, ocorreu_em=ocorreu)
                cur = c.execute('INSERT INTO pedido_alteracao (tabela,registro,novo,motivo,pedido_por,criado_em) VALUES (?,?,?,?,?,?)',
                                ('aula', tc['id'], json.dumps(novo, ensure_ascii=False), str(dados.get('motivo') or 'lançamento depois da validação'), usuario['id'], bd.agora()))
                c.execute('INSERT INTO evento_recebido VALUES (?,?)', (uid, bd.agora()))
                self.b.auditar(c, usuario, 'pedido', 'aula', cur.lastrowid, 'diário de classe')
                return {'ok': True, 'pendente': True}
            aula_id = self._gravar_aula(c, uid, tc, dados, marcas, usuario, ocorreu, aparelho)
            c.execute('INSERT INTO evento_recebido VALUES (?,?)', (uid, bd.agora()))
            self.b.auditar(c, usuario, 'chamada', 'aula', aula_id, 'diário de classe', f'{len(marcas)} alunos')
        return {'ok': True, 'aula_id': aula_id}

    def validar_aulas(self, tc_id, ate, usuario):
        exigir(usuario, *PAPEIS_GESTAO)
        self._data(ate)
        with self.b.transacao() as c:
            n = c.execute('UPDATE aula SET validada_por=?, validada_em=? WHERE turma_componente_id=? AND data<=? AND validada_em IS NULL',
                          (usuario['id'], bd.agora(), tc_id, ate)).rowcount
            c.execute('UPDATE turma_componente SET validado_ate=max(coalesce(validado_ate,\'\'),?) WHERE id=?', (ate, tc_id))
            self.b.auditar(c, usuario, 'validar', 'aula', tc_id, 'diário de classe', f'{n} aulas até {ate}')
        return {'validadas': n}

    def decidir_pedido(self, pedido_id, aprovar, usuario):
        exigir(usuario, 'direcao', 'coordenacao')
        with self.b.transacao() as c:
            p = c.execute("SELECT * FROM pedido_alteracao WHERE id=? AND estado='pendente'", (pedido_id,)).fetchone()
            if not p:
                raise Erro('pedido não encontrado', 404)
            if p['pedido_por'] == usuario['id']:
                raise Erro('quem pediu a alteração não pode aprová-la', 403)
            if aprovar:
                novo = json.loads(p['novo'])
                tc = c.execute('SELECT tc.*, t.ano_id FROM turma_componente tc JOIN turma t ON t.id=tc.turma_id WHERE tc.id=?', (novo['turma_componente_id'],)).fetchone()
                self._conferir_aberto(c, tc['ano_id'], novo['data'])
                marcas = {int(k): v for k, v in novo['marcas'].items()}
                self._gravar_aula(c, novo['uid'], tc, novo, marcas, {'id': p['pedido_por']}, novo['ocorreu_em'], '')
            c.execute('UPDATE pedido_alteracao SET estado=?, decidido_por=?, decidido_em=? WHERE id=?',
                      ('aprovado' if aprovar else 'recusado', usuario['id'], bd.agora(), pedido_id))
            self.b.auditar(c, usuario, 'aprovar' if aprovar else 'recusar', 'pedido_alteracao', pedido_id, 'diário de classe', p['motivo'])
        return {'ok': True}

    def fechar_periodo(self, periodo_id, fechado, usuario):
        exigir(usuario, 'direcao')
        with self.b.transacao() as c:
            if not c.execute('UPDATE periodo SET fechado=? WHERE id=?', (1 if fechado else 0, periodo_id)).rowcount:
                raise Erro('período não encontrado', 404)
            self.b.auditar(c, usuario, 'fechar' if fechado else 'reabrir', 'periodo', periodo_id, 'calendário escolar')
        return {'ok': True}

    def encerrar_ano(self, ano_id, usuario):
        """Grava o resultado final nas matrículas; recusa enquanto houver período aberto ou aluno pendente."""
        exigir(usuario, 'direcao')
        if self.b.um('SELECT 1 FROM periodo WHERE ano_id=? AND fechado=0', ano_id):
            raise Erro('feche todos os períodos antes')
        resultados = {}
        for m in self.b.todos("""SELECT m.id, t.etapa FROM matricula m JOIN turma t ON t.id=m.turma_id WHERE t.ano_id=? AND m.situacao='cursando'""", ano_id):
            estados = {l['resultado'] for l in self.boletim(m['id'])['linhas']}
            if estados & {'pendente', 'recuperacao'}:
                raise Erro(f'matrícula {m["id"]} com resultado pendente; resolva no conselho de classe')
            if m['etapa'] != 'infantil':
                resultados[m['id']] = 'reprovado' if estados & {'reprovado', 'reprovado_frequencia'} else 'aprovado'
            else:
                resultados[m['id']] = 'aprovado'
        with self.b.transacao() as c:
            for mid, r in resultados.items():
                c.execute('UPDATE matricula SET situacao=? WHERE id=?', (r, mid))
            c.execute('UPDATE ano_letivo SET encerrado=1 WHERE id=?', (ano_id,))
            self.b.auditar(c, usuario, 'encerrar', 'ano_letivo', ano_id, 'fechamento do ano', f'{len(resultados)} matrículas')
        return {'matriculas': len(resultados)}

    def pedidos(self, usuario):
        exigir(usuario, *PAPEIS_GESTAO)
        return self.b.todos("SELECT p.*, u.nome AS pedido_nome FROM pedido_alteracao p LEFT JOIN usuario u ON u.id=p.pedido_por WHERE estado='pendente' ORDER BY p.id")

    def chamada(self, tc_id, data, usuario):
        tc = self._turma_componente(tc_id, usuario)
        self._data(data)
        aula = self.b.um('SELECT * FROM aula WHERE turma_componente_id=? AND data=?', tc_id, data)
        presencas = {}
        if aula:
            presencas = {l['matricula_id']: l['presente'] for l in self.b.todos('SELECT * FROM presenca WHERE aula_id=?', aula['id'])}
        alunos = [dict(a, presente=presencas.get(a['matricula_id'], 1)) for a in self.alunos_da_turma(tc['turma_id']) if a['situacao'] == 'cursando']
        return {'turma': tc['turma'], 'componente': tc['componente'], 'alunos': alunos, 'aula': dict(aula) if aula else None}

    # ------------------------------------------------------------ frequência e notas
    def frequencia_matricula(self, matricula_id, de=None, ate=None):
        sql = """SELECT coalesce(sum(a.horas),0) AS ofertadas, coalesce(sum(CASE WHEN p.presente THEN a.horas ELSE 0 END),0) AS presentes
                 FROM presenca p JOIN aula a ON a.id=p.aula_id WHERE p.matricula_id=?"""
        args = [matricula_id]
        if de:
            sql += ' AND a.data>=?'
            args.append(de)
        if ate:
            sql += ' AND a.data<=?'
            args.append(ate)
        l = self.b.um(sql, *args)
        return l['presentes'], l['ofertadas'], regras.frequencia(l['presentes'], l['ofertadas'])

    def painel_frequencia(self, usuario, turma_id=None):
        exigir(usuario, *PAPEIS_GESTAO)
        cfg = self.cfg()
        hoje = dt.date.today()
        sql = """SELECT m.id AS matricula_id, p.nome, p.nascimento, t.nome AS turma, t.etapa
                 FROM matricula m JOIN pessoa p ON p.id=m.aluno_id JOIN turma t ON t.id=m.turma_id
                 JOIN ano_letivo a ON a.id=t.ano_id WHERE m.situacao='cursando' AND a.encerrado=0"""
        linhas = self.b.todos(sql + (' AND t.id=?' if turma_id else '') + ' ORDER BY t.nome, p.nome', *((turma_id,) if turma_id else ()))
        somas = {l['matricula_id']: l for l in self.b.todos("""SELECT p.matricula_id, sum(a.horas) AS ofertadas, sum(CASE WHEN p.presente THEN a.horas ELSE 0 END) AS presentes
                                                                FROM presenca p JOIN aula a ON a.id=p.aula_id GROUP BY p.matricula_id""")}
        saida = []
        for l in linhas:
            s = somas.get(l['matricula_id'], {'ofertadas': 0, 'presentes': 0})
            percentual = regras.frequencia(s['presentes'], s['ofertadas'])
            idade = regras.idade_em(l['nascimento'], hoje) if l['nascimento'] else None
            alertas = regras.alertas_frequencia(percentual, l['etapa'], idade, cfg, l['etapa'] == 'medio')
            saida.append({**l, 'horas_presentes': s['presentes'], 'horas_ofertadas': s['ofertadas'], 'percentual': percentual, 'alertas': alertas})
        return saida

    def criar_avaliacao(self, dados, usuario):
        tc = self._turma_componente(int(dados['turma_componente_id']), usuario)
        periodo = self.b.um('SELECT * FROM periodo WHERE id=?', dados.get('periodo_id'))
        if not periodo:
            raise Erro('período não encontrado', 404)
        if periodo['fechado']:
            raise Erro('período fechado')
        if tc['etapa'] == 'infantil':
            raise Erro('educação infantil usa parecer descritivo, sem nota')
        peso = regras.numero_finito(dados.get('peso', 1))
        if peso <= 0:
            raise Erro('peso inválido')
        if dados.get('tipo', 'regular') not in ('regular', 'recuperacao'):
            raise Erro('tipo inválido')
        with self.b.transacao() as c:
            cur = c.execute('INSERT INTO avaliacao (turma_componente_id,periodo_id,nome,peso,tipo,data) VALUES (?,?,?,?,?,?)',
                            (tc['id'], periodo['id'], str(dados.get('nome', 'Avaliação')).strip(), peso, dados.get('tipo', 'regular'), dados.get('data')))
            self.b.auditar(c, usuario, 'criar', 'avaliacao', cur.lastrowid, 'avaliação escolar')
        return {'id': cur.lastrowid}

    def lancar_notas(self, avaliacao_id, notas, usuario):
        a = self.b.um("""SELECT av.*, pe.fechado, tc.turma_id FROM avaliacao av JOIN periodo pe ON pe.id=av.periodo_id
                         JOIN turma_componente tc ON tc.id=av.turma_componente_id WHERE av.id=?""", avaliacao_id)
        if not a:
            raise Erro('avaliação não encontrada', 404)
        self._turma_componente(a['turma_componente_id'], usuario)
        if a['fechado']:
            raise Erro('período fechado; peça alteração à direção')
        cfg = self.cfg()
        validas = {m['id'] for m in self.b.todos('SELECT id FROM matricula WHERE turma_id=?', a['turma_id'])}
        with self.b.transacao() as c:
            for chave, valor in notas.items():
                mid = int(chave)
                if mid not in validas:
                    raise Erro('aluno fora desta turma')
                try:
                    v = regras.validar_nota(valor, cfg)
                except ValueError as e:
                    raise Erro(str(e)) from e
                antes = c.execute('SELECT valor FROM nota WHERE avaliacao_id=? AND matricula_id=?', (avaliacao_id, mid)).fetchone()
                c.execute("""INSERT INTO nota VALUES (?,?,?,?,?) ON CONFLICT(avaliacao_id,matricula_id)
                             DO UPDATE SET valor=excluded.valor, lancada_por=excluded.lancada_por, lancada_em=excluded.lancada_em""",
                          (avaliacao_id, mid, v, usuario['id'], bd.agora()))
                if antes is None or antes['valor'] != v:
                    self.b.auditar(c, usuario, 'nota', 'avaliacao', avaliacao_id, 'avaliação escolar', f'matrícula {mid}: {antes["valor"] if antes else "-"} -> {v}')
        return {'ok': True}

    def gravar_parecer(self, dados, usuario):
        self.exigir_matricula(usuario, int(dados['matricula_id']))
        texto = str(dados.get('texto', '')).strip()
        if not texto:
            raise Erro('parecer vazio')
        periodo = self.b.um('SELECT fechado FROM periodo WHERE id=?', dados['periodo_id'])
        if not periodo:
            raise Erro('período não encontrado', 404)
        if periodo['fechado']:
            raise Erro('período fechado; peça alteração à direção')
        with self.b.transacao() as c:
            c.execute("""INSERT INTO parecer (matricula_id,periodo_id,campo,texto,autor_id,criado_em) VALUES (?,?,?,?,?,?)
                         ON CONFLICT(matricula_id,periodo_id,campo) DO UPDATE SET texto=excluded.texto, autor_id=excluded.autor_id""",
                      (dados['matricula_id'], dados['periodo_id'], dados.get('campo', 'geral'), self.cofre.cifrar(texto), usuario['id'], bd.agora()))
            self.b.auditar(c, usuario, 'parecer', 'matricula', dados['matricula_id'], 'avaliação escolar')
        return {'ok': True}

    def decidir_conselho(self, dados, usuario):
        exigir(usuario, 'direcao', 'coordenacao')
        if not str(dados.get('motivo', '')).strip():
            raise Erro('decisão do conselho exige motivo')
        if dados.get('decisao') not in ('aprovado', 'reprovado'):
            raise Erro('decisão inválida')
        with self.b.transacao() as c:
            m = c.execute('SELECT a.encerrado FROM matricula m JOIN turma t ON t.id=m.turma_id JOIN ano_letivo a ON a.id=t.ano_id WHERE m.id=?', (dados['matricula_id'],)).fetchone()
            if not m:
                raise Erro('matrícula não encontrada', 404)
            if m['encerrado']:
                raise Erro('ano letivo encerrado')
            c.execute('INSERT OR REPLACE INTO decisao_conselho (matricula_id,componente_id,decisao,motivo,conselho_id) VALUES (?,?,?,?,?)',
                      (dados['matricula_id'], dados['componente_id'], dados['decisao'], dados['motivo'], dados.get('conselho_id')))
            self.b.auditar(c, usuario, 'conselho', 'matricula', dados['matricula_id'], 'conselho de classe', dados['decisao'])
        return {'ok': True}

    def boletim(self, matricula_id, usuario=None):
        m = self.b.um("""SELECT m.*, p.nome, p.nome_social, p.nascimento, t.nome AS turma, t.etapa, t.ano_id, a.ano FROM matricula m
                         JOIN pessoa p ON p.id=m.aluno_id JOIN turma t ON t.id=m.turma_id JOIN ano_letivo a ON a.id=t.ano_id WHERE m.id=?""", matricula_id)
        if not m:
            raise Erro('matrícula não encontrada', 404)
        self._pode_ver_aluno(m, usuario)
        cfg = self.cfg()
        periodos = self.b.todos('SELECT * FROM periodo WHERE ano_id=? ORDER BY ordem', m['ano_id'])
        presentes, ofertadas, geral = self.frequencia_matricula(matricula_id)
        linhas = []
        for tc in self.b.todos("""SELECT tc.id, tc.componente_id, c.nome FROM turma_componente tc JOIN componente c ON c.id=tc.componente_id
                                  WHERE tc.turma_id=? ORDER BY c.nome""", m['turma_id']):
            medias = {}
            for pe in periodos:
                regular = self.b.todos("""SELECT n.valor, av.peso FROM avaliacao av LEFT JOIN nota n ON n.avaliacao_id=av.id AND n.matricula_id=?
                                          WHERE av.turma_componente_id=? AND av.periodo_id=? AND av.tipo='regular'""", matricula_id, tc['id'], pe['id'])
                completa = regular and all(l['valor'] is not None for l in regular)
                media = regras.media_ponderada([(l['valor'], l['peso']) for l in regular]) if completa else None
                rec = self.b.um("""SELECT max(n.valor) AS v FROM avaliacao av JOIN nota n ON n.avaliacao_id=av.id AND n.matricula_id=?
                                   WHERE av.turma_componente_id=? AND av.periodo_id=? AND av.tipo='recuperacao'""", matricula_id, tc['id'], pe['id'])
                medias[pe['id']] = regras.media_com_recuperacao(media, rec['v'], cfg)
            faltando = bool(periodos) and any(v is None for v in medias.values())
            final = None if faltando else regras.media_ponderada([(v, 1) for v in medias.values()])
            f = self.b.um("""SELECT coalesce(sum(a.horas),0) AS o, coalesce(sum(CASE WHEN p.presente THEN a.horas ELSE 0 END),0) AS q
                             FROM presenca p JOIN aula a ON a.id=p.aula_id WHERE p.matricula_id=? AND a.turma_componente_id=?""", matricula_id, tc['id'])
            percentual = regras.frequencia(f['q'], f['o'])
            d = self.b.um('SELECT decisao FROM decisao_conselho WHERE matricula_id=? AND componente_id=?', matricula_id, tc['componente_id'])
            base = percentual if cfg['frequencia_por_componente'] else geral
            linhas.append({'componente': tc['nome'], 'componente_id': tc['componente_id'], 'medias': [medias[pe['id']] for pe in periodos], 'final': final,
                           'parcial': regras.media_ponderada([(v, 1) for v in medias.values() if v is not None]), 'frequencia': percentual, 'faltas_h': f['o'] - f['q'],
                           'resultado': regras.resultado_final(final, base, m['etapa'], cfg, d['decisao'] if d else None)})
        pareceres = [dict(p, texto=self.cofre.decifrar(p['texto'])) for p in
                     self.b.todos('SELECT pa.*, pe.nome AS periodo FROM parecer pa JOIN periodo pe ON pe.id=pa.periodo_id WHERE matricula_id=? ORDER BY pe.ordem', matricula_id)]
        return {'matricula': dict(m), 'periodos': [p['nome'] for p in periodos], 'linhas': linhas, 'frequencia_geral': geral,
                'horas_ofertadas': ofertadas, 'horas_presentes': presentes, 'pareceres': pareceres}

    def _pode_ver_aluno(self, matricula, usuario):
        if usuario is None:
            return
        if usuario['papel'] in PAPEIS_EQUIPE:
            self.exigir_turma(usuario, matricula['turma_id'])
            return
        pessoa = usuario.get('pessoa_id')
        if usuario['papel'] == 'aluno' and pessoa == matricula['aluno_id']:
            return
        if usuario['papel'] == 'responsavel' and self.b.um('SELECT 1 FROM vinculo WHERE aluno_id=? AND responsavel_id=?', matricula['aluno_id'], pessoa):
            return
        raise Erro('sem permissão', 403)

    def portal(self, usuario):
        pessoa = usuario.get('pessoa_id')
        if usuario['papel'] == 'aluno':
            alunos = [pessoa]
        elif usuario['papel'] == 'responsavel':
            alunos = [l['aluno_id'] for l in self.b.todos('SELECT aluno_id FROM vinculo WHERE responsavel_id=?', pessoa)]
        else:
            raise Erro('sem permissão', 403)
        saida = []
        for aluno in alunos:
            for m in self.b.todos("""SELECT m.id, m.turma_id, t.nome AS turma, p.nome FROM matricula m JOIN turma t ON t.id=m.turma_id JOIN pessoa p ON p.id=m.aluno_id
                                     JOIN ano_letivo a ON a.id=t.ano_id WHERE m.aluno_id=? AND a.encerrado=0""", aluno):
                conteudos = self.b.todos("""SELECT co.id, co.titulo, co.corpo, co.link, c.nome AS componente FROM conteudo co
                    JOIN turma_componente tc ON tc.id=co.turma_componente_id JOIN componente c ON c.id=tc.componente_id
                    WHERE tc.turma_id=? AND co.publicado=1 ORDER BY co.id DESC LIMIT 100""", m['turma_id'])
                saida.append({'matricula_id': m['id'], 'aluno': m['nome'], 'turma': m['turma'], 'boletim': self.boletim(m['id'], usuario), 'conteudos': conteudos})
        return saida

    def publicar_conteudo(self, dados, usuario):
        """Recebe conteúdo da escola local em uma instalação hospedada; repetido pelo uid não duplica."""
        uid = str(dados.get('uid') or '')
        if not re.fullmatch(r'[0-9a-fA-F-]{36}', uid):
            raise Erro('uid inválido')
        with self.b.transacao() as c:
            if c.execute('SELECT 1 FROM evento_recebido WHERE uid=?', (uid,)).fetchone():
                return {'ok': True, 'repetido': True}
            if not c.execute('SELECT 1 FROM turma_componente WHERE id=?', (dados['turma_componente_id'],)).fetchone():
                raise Erro('turma não encontrada', 404)
            c.execute('INSERT INTO conteudo (turma_componente_id,titulo,corpo,link,habilidades,publicado,criado_em) VALUES (?,?,?,?,?,1,?)',
                      (dados['turma_componente_id'], str(dados['titulo']), str(dados.get('corpo', '')), str(dados.get('link', '')), str(dados.get('habilidades', '')), bd.agora()))
            c.execute('INSERT INTO evento_recebido VALUES (?,?)', (uid, bd.agora()))
            self.b.auditar(c, usuario, 'publicar', 'conteudo', uid, 'portal de conteúdo')
        return {'ok': True}

    # ------------------------------------------------------------ LGPD
    def anonimizar(self, pessoa_id, motivo, usuario):
        exigir(usuario, 'direcao')
        if not str(motivo).strip():
            raise Erro('informe o motivo')
        if self.b.um('SELECT 1 FROM matricula WHERE aluno_id=?', pessoa_id):
            raise Erro('há registro escolar de guarda obrigatória; a ficha acadêmica não pode ser anonimizada')
        with self.b.transacao() as c:
            n = c.execute("""UPDATE pessoa SET nome='(dados removidos)', nome_social='', cpf='', nis='', id_inep='', endereco='', telefone='', email='',
                             saude='', restricao_alimentar='', necessidade_especifica='', cor_raca='', naturalidade='', anonimizado=1 WHERE id=?""", (pessoa_id,)).rowcount
            if not n:
                raise Erro('pessoa não encontrada', 404)
            self.b.auditar(c, usuario, 'anonimizar', 'pessoa', pessoa_id, 'pedido do titular', str(motivo)[:200])
        return {'ok': True}

    def trilha(self, usuario, limite=200):
        exigir(usuario, 'direcao')
        return self.b.todos('SELECT id,quando,usuario,acao,tabela,registro,finalidade,detalhe FROM auditoria ORDER BY id DESC LIMIT ?', limite)

    def painel(self, usuario):
        exigir(usuario, *PAPEIS_EQUIPE)
        um = lambda sql: self.b.um(sql)[0]
        return {'alunos': um("SELECT count(*) FROM matricula m JOIN turma t ON t.id=m.turma_id JOIN ano_letivo a ON a.id=t.ano_id WHERE m.situacao='cursando' AND a.encerrado=0"),
                'turmas': um('SELECT count(*) FROM turma t JOIN ano_letivo a ON a.id=t.ano_id WHERE a.encerrado=0'),
                'pedidos': um("SELECT count(*) FROM pedido_alteracao WHERE estado='pendente'"),
                'aulas_hoje': self.b.um('SELECT count(*) FROM aula WHERE data=?', dt.date.today().isoformat())[0]}
