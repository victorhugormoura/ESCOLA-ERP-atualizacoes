"""ESCOLA-ERP — documentos escolares em HTML para impressão e em ODT para edição.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import datetime as dt
import hashlib
import html
import io
import re
import shutil
import subprocess
import tempfile
import os
import zipfile

import banco as bd

CSS = """body{font:12pt 'Liberation Serif',Georgia,serif;color:#000;max-width:190mm;margin:10mm auto}
h1{font-size:15pt;text-align:center;margin:0}h2{font-size:12pt;text-align:center;font-weight:normal;margin:2mm 0 6mm}
table{border-collapse:collapse;width:100%;margin:4mm 0}td,th{border:1px solid #000;padding:1.5mm;font-size:10pt;text-align:center}
td:first-child,th:first-child{text-align:left}.ass{margin-top:18mm;display:flex;justify-content:space-around}
.ass div{border-top:1px solid #000;width:70mm;text-align:center;padding-top:1mm;font-size:10pt}
.ver{margin-top:8mm;font-size:8pt;color:#333}@media print{.ver{position:fixed;bottom:4mm}}"""


def e(valor):
    return html.escape('' if valor is None else str(valor))


def num(v):
    return '—' if v is None else f'{v:.1f}'.replace('.', ',')


class Documentos:
    def __init__(self, escola):
        self.e = escola
        self.b = escola.b

    def _cabecalho(self):
        c = self.b.obter('escola', {})
        return c.get('nome', 'Escola'), c.get('rede', ''), c.get('inep', '')

    def _emitir(self, tipo, referencia, corpo, usuario):
        codigo = '-'.join(hashlib.sha256(bd.novo_uid().encode()).hexdigest()[:4].upper() for _ in range(3))
        with self.b.transacao() as c:
            c.execute('INSERT INTO documento (codigo,tipo,referencia,hash,emitido_por,emitido_em) VALUES (?,?,?,?,?,?)',
                      (codigo, tipo, str(referencia), hashlib.sha256(corpo.encode('utf-8')).hexdigest(), (usuario or {}).get('id'), bd.agora()))
            self.b.auditar(c, usuario, 'emitir', 'documento', codigo, 'documento escolar', tipo)
        return codigo

    def _pagina(self, titulo, corpo, tipo, referencia, usuario, assinaturas=('Secretaria escolar', 'Direção')):
        nome, rede, inep = self._cabecalho()
        codigo = self._emitir(tipo, referencia, corpo, usuario)
        ass = ''.join(f'<div>{e(a)}</div>' for a in assinaturas)
        return (f'<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>{e(titulo)}</title><style>{CSS}</style>'
                f'<h1>{e(nome)}</h1><h2>{e(rede)} · INEP {e(inep)}<br><b>{e(titulo)}</b></h2>{corpo}'
                f'<div class="ass">{ass}</div><p class="ver">Código de verificação {codigo} · emitido em {dt.date.today():%d/%m/%Y}</p></html>')

    def boletim(self, matricula_id, usuario):
        d = self.e.boletim(matricula_id, usuario)
        m = d['matricula']
        corpo = f'<p><b>Aluno(a):</b> {e(m["nome_social"] or m["nome"])} · <b>Turma:</b> {e(m["turma"])} · <b>Ano:</b> {e(m["ano"])}</p>'
        if m['etapa'] == 'infantil':
            for p in d['pareceres']:
                corpo += f'<h3>{e(p["periodo"])} — {e(p["campo"])}</h3><p>{e(p["texto"])}</p>'
        else:
            cab = ''.join(f'<th>{e(p)}</th>' for p in d['periodos'])
            corpo += f'<table><tr><th>Componente</th>{cab}<th>Final</th><th>Freq.</th><th>Resultado</th></tr>'
            for l in d['linhas']:
                medias = ''.join(f'<td>{num(v)}</td>' for v in l['medias'])
                freq = '—' if l['frequencia'] is None else f'{l["frequencia"]:.1f}%'.replace('.', ',')
                corpo += f'<tr><td>{e(l["componente"])}</td>{medias}<td>{num(l["final"])}</td><td>{freq}</td><td>{e(RESULTADOS.get(l["resultado"], l["resultado"]))}</td></tr>'
            corpo += '</table>'
        geral = d['frequencia_geral']
        corpo += f'<p><b>Frequência geral:</b> {"—" if geral is None else str(geral).replace(".", ",") + "%"} ({d["horas_presentes"]:g} de {d["horas_ofertadas"]:g} horas)</p>'
        return self._pagina('Boletim escolar', corpo, 'boletim', matricula_id, usuario)

    def declaracao(self, matricula_id, usuario):
        m = self.b.um("""SELECT m.*, p.nome, p.nome_social, t.nome AS turma, t.turno, a.ano FROM matricula m JOIN pessoa p ON p.id=m.aluno_id
                         JOIN turma t ON t.id=m.turma_id JOIN ano_letivo a ON a.id=t.ano_id WHERE m.id=?""", matricula_id)
        if not m:
            raise ValueError('matrícula não encontrada')
        nome = self._cabecalho()[0]
        corpo = (f'<p style="line-height:2;text-align:justify;margin-top:15mm">Declaramos, para os devidos fins, que <b>{e(m["nome_social"] or m["nome"])}</b> '
                 f'está regularmente matriculado(a) nesta unidade, {e(nome)}, na turma {e(m["turma"])}, turno {e(m["turno"])}, no ano letivo de {e(m["ano"])}, '
                 f'situação: {e(m["situacao"])}.</p>')
        return self._pagina('Declaração de matrícula', corpo, 'declaracao', matricula_id, usuario)

    def ata_resultados(self, turma_id, usuario):
        t = self.b.um('SELECT t.*, a.ano FROM turma t JOIN ano_letivo a ON a.id=t.ano_id WHERE t.id=?', turma_id)
        if not t:
            raise ValueError('turma não encontrada')
        comps = None
        linhas = ''
        for a in self.e.alunos_da_turma(turma_id):
            d = self.e.boletim(a['matricula_id'], usuario)
            if comps is None:
                comps = [l['componente'] for l in d['linhas']]
            notas = ''.join(f'<td>{num(l["final"])}</td>' for l in d['linhas'])
            geral = '—' if d['frequencia_geral'] is None else f'{d["frequencia_geral"]:.0f}%'
            linhas += f'<tr><td>{a["numero"]}. {e(a["nome"])}</td>{notas}<td>{geral}</td><td>{e(self._resultado(d, a))}</td></tr>'
        cab = ''.join(f'<th>{e(c[:12])}</th>' for c in (comps or []))
        corpo = (f'<p>Turma {e(t["nome"])}, ano letivo de {e(t["ano"])}.</p><table><tr><th>Aluno(a)</th>{cab}<th>Freq.</th><th>Resultado</th></tr>{linhas}</table>')
        return self._pagina('Ata de resultados finais', corpo, 'ata', turma_id, usuario)

    @staticmethod
    def _resultado(d, aluno):
        if aluno['situacao'] != 'cursando':
            return aluno['situacao']
        estados = {l['resultado'] for l in d['linhas']}
        if 'reprovado_frequencia' in estados or 'reprovado' in estados:
            return 'Reprovado'
        if 'recuperacao' in estados:
            return 'Em recuperação'
        if 'pendente' in estados or not estados:
            return 'Pendente'
        return 'Aprovado' if 'aprovado' in estados else 'Acompanhamento'

    def diario(self, tc_id, usuario):
        tc = self.e._turma_componente(tc_id, usuario)
        aulas = self.b.todos('SELECT * FROM aula WHERE turma_componente_id=? ORDER BY data', tc_id)
        corpo = f'<p>Turma {e(tc["turma"])} · {e(tc["componente"])}</p><table><tr><th>Data</th><th>Horas</th><th>Conteúdo</th><th>Faltas</th><th>Validada</th></tr>'
        for a in aulas:
            faltas = self.b.um('SELECT count(*) FROM presenca WHERE aula_id=? AND presente=0', a['id'])[0]
            corpo += f'<tr><td>{e(a["data"])}</td><td>{a["horas"]:g}</td><td>{e(a["conteudo"])}</td><td>{faltas}</td><td>{"sim" if a["validada_em"] else "não"}</td></tr>'
        return self._pagina('Diário de classe', corpo + '</table>', 'diario', tc_id, usuario, ('Professor(a)', 'Direção'))

    def historico(self, aluno_id, usuario):
        p = self.b.um('SELECT * FROM pessoa WHERE id=?', aluno_id)
        if not p:
            raise ValueError('aluno não encontrado')
        corpo = (f'<p><b>Nome:</b> {e(p["nome_social"] or p["nome"])} · <b>Nascimento:</b> {e(p["nascimento"])} · '
                 f'<b>Naturalidade:</b> {e(p["naturalidade"])} · <b>Nacionalidade:</b> {e(p["nacionalidade"])}</p>')
        for m in self.b.todos('SELECT id FROM matricula WHERE aluno_id=? ORDER BY id', aluno_id):
            d = self.e.boletim(m['id'], usuario)
            mm = d['matricula']
            corpo += f'<h3>{e(mm["ano"])} — {e(mm["turma"])} ({e(mm["situacao"])})</h3><table><tr><th>Componente</th><th>Final</th><th>Freq.</th><th>Resultado</th></tr>'
            for l in d['linhas']:
                freq = '—' if l['frequencia'] is None else f'{l["frequencia"]:.1f}%'
                corpo += f'<tr><td>{e(l["componente"])}</td><td>{num(l["final"])}</td><td>{freq}</td><td>{e(RESULTADOS.get(l["resultado"], l["resultado"]))}</td></tr>'
            corpo += '</table>'
        return self._pagina('Histórico escolar', corpo, 'historico', aluno_id, usuario)

    def verificar(self, codigo):
        l = self.b.um('SELECT tipo, emitido_em FROM documento WHERE codigo=?', codigo.strip().upper())
        return dict(l) if l else None


RESULTADOS = {'aprovado': 'Aprovado', 'recuperacao': 'Recuperação', 'pendente': 'Pendente', 'reprovado': 'Reprovado',
              'reprovado_frequencia': 'Reprovado por frequência', 'acompanhamento': 'Acompanhamento'}


def _texto(html_doc):
    limpo = re.sub(r'<style.*?</style>', '', html_doc, flags=re.S)
    blocos = re.split(r'</(?:p|h1|h2|h3|tr|table|div)>', limpo)
    linhas = []
    for bloco in blocos:
        partes = [html.unescape(re.sub(r'<[^>]+>', ' ', c)).strip() for c in re.split(r'</t[dh]>', bloco)]
        linha = ' | '.join(' '.join(p.split()) for p in partes if p.strip())
        if linha:
            linhas.append(linha)
    return linhas


def para_odt(html_doc):
    """ODT mínimo (ISO 26300), aberto por LibreOffice, Google Docs e Word."""
    corpo = ''.join(f'<text:p>{html.escape(l, quote=False)}</text:p>' for l in _texto(html_doc))
    conteudo = ('<?xml version="1.0" encoding="UTF-8"?><office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
                'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" office:version="1.3"><office:body><office:text>'
                f'{corpo}</office:text></office:body></office:document-content>')
    manifesto = ('<?xml version="1.0" encoding="UTF-8"?><manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.3">'
                 '<manifest:file-entry manifest:full-path="/" manifest:version="1.3" manifest:media-type="application/vnd.oasis.opendocument.text"/>'
                 '<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/></manifest:manifest>')
    saida = io.BytesIO()
    with zipfile.ZipFile(saida, 'w') as z:
        z.writestr(zipfile.ZipInfo('mimetype'), 'application/vnd.oasis.opendocument.text', zipfile.ZIP_STORED)
        z.writestr('content.xml', conteudo, zipfile.ZIP_DEFLATED)
        z.writestr('META-INF/manifest.xml', manifesto, zipfile.ZIP_DEFLATED)
    return saida.getvalue()


def libreoffice():
    for nome in ('soffice', 'libreoffice'):
        achado = shutil.which(nome)
        if achado:
            return achado
    for caminho in (r'C:\Program Files\LibreOffice\program\soffice.exe', r'C:\Program Files (x86)\LibreOffice\program\soffice.exe'):
        if os.path.exists(caminho):
            return caminho
    return None


def para_pdf(html_doc):
    """Gera PDF/A pelo LibreOffice, quando instalado; sem ele, o navegador imprime em PDF."""
    programa = libreoffice()
    if not programa:
        return None
    with tempfile.TemporaryDirectory() as pasta:
        origem = os.path.join(pasta, 'doc.html')
        with open(origem, 'w', encoding='utf-8') as f:
            f.write(html_doc)
        filtro = 'pdf:writer_web_pdf_Export:{"SelectPdfVersion":{"type":"long","value":"2"}}'
        subprocess.run([programa, '--headless', f'-env:UserInstallation=file://{pasta}/perfil', '--convert-to', filtro, '--outdir', pasta, origem],
                       check=False, capture_output=True, timeout=120)
        destino = os.path.join(pasta, 'doc.pdf')
        if not os.path.exists(destino):
            return None
        with open(destino, 'rb') as f:
            return f.read()
