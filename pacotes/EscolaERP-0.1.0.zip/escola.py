#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ESCOLA-ERP — gestão escolar que funciona sem internet.

Servidor local só com a biblioteca padrão do Python (3.9 ou superior). Roda em Windows e Linux.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import argparse
import datetime as dt
import getpass
import hashlib
import hmac
import http.cookies
import json
import mimetypes
import os
import re
import secrets
import socket
import sys
import threading
import time
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import atualizacao  # noqa: E402
import backup  # noqa: E402
import banco as bd  # noqa: E402
import celular  # noqa: E402
import cofre as cf  # noqa: E402
import documentos  # noqa: E402
import oficial  # noqa: E402
import regras  # noqa: E402
import servico  # noqa: E402

VERSAO = '0.1.0'
CREDITO = 'Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com'
PORTA_LOCAL = 8460
PORTA_LAN = 8461
LIMITE_CORPO = 8 * 1024 * 1024
SESSAO_S = 12 * 3600
ESCOPOS = ('leitura', 'frequencia', 'sinal', 'ponto', 'conteudo')
WEB = os.path.join(BASE_DIR, 'web')
SENHA_MINIMA = 10


class App:
    def __init__(self, dados, hospedado=False):
        self.dados = dados
        self.hospedado = hospedado
        os.makedirs(dados, exist_ok=True)
        if os.name != 'nt':
            os.chmod(dados, 0o700)
        self.b = bd.Banco(os.path.join(dados, 'escola.db'))
        self.chave = self._carregar_chave()
        self.b.chave_auditoria = hmac.new(self.chave, b'escola-erp/auditoria', hashlib.sha256).digest()
        self.cofre = cf.Cofre(self.chave)
        self.e = servico.Escola(self.b, self.cofre)
        self.doc = documentos.Documentos(self.e)
        self.of = oficial.Oficial(self.e)
        self.tentativas = {}
        self.trava = threading.Lock()
        self.vagas_scrypt = threading.BoundedSemaphore(4)
        self.hash_falso = cf.hash_senha(secrets.token_hex(16))
        self.atu = atualizacao.Atualizador(BASE_DIR, dados, VERSAO, log=lambda *_: None)

    def _carregar_chave(self):
        caminho = os.path.join(self.dados, 'escola.chave')
        if os.path.exists(caminho):
            with open(caminho, 'rb') as f:
                return f.read()
        chave = secrets.token_bytes(32)
        descritor = os.open(caminho, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descritor, 'wb') as f:
            f.write(chave)
        return chave

    def configurado(self):
        return self.b.um('SELECT 1 FROM usuario LIMIT 1') is not None

    def instalar(self, dados):
        if self.configurado():
            raise servico.Erro('escola já configurada', 409)
        for campo in ('nome_escola', 'login', 'nome', 'senha'):
            if not str(dados.get(campo, '')).strip():
                raise servico.Erro(f'campo obrigatório: {campo}')
        self.validar_senha(dados['senha'], dados['login'])
        codigo = cf.codigo_recuperacao()
        self.b.gravar('escola', {'nome': dados['nome_escola'].strip(), 'rede': str(dados.get('rede', '')).strip(), 'inep': str(dados.get('inep', '')).strip()})
        self.b.gravar('envelope', cf.envelopar(self.chave, codigo))
        self.gravar_chave_rede(secrets.token_bytes(32))
        with self.b.transacao() as c:
            c.execute('INSERT INTO usuario (login,nome,papel,senha,criado_em) VALUES (?,?,?,?,?)',
                      (dados['login'].strip(), dados['nome'].strip(), 'direcao', cf.hash_senha(dados['senha']), bd.agora()))
            self.b.auditar(c, None, 'instalar', 'config', 'escola', 'configuração inicial')
        return {'codigo_recuperacao': codigo}

    @staticmethod
    def validar_senha(senha, login=''):
        senha = str(senha)
        if len(senha) < SENHA_MINIMA:
            raise servico.Erro(f'a senha precisa de ao menos {SENHA_MINIMA} caracteres')
        if login and login.lower() in senha.lower():
            raise servico.Erro('a senha não pode conter o login')

    def gravar_chave_rede(self, chave):
        self.b.gravar('chave_rede', self.cofre_rede().cifrar(cf._b64e(chave)))

    def cofre_rede(self):
        return cf.Cofre(self.chave)

    def chave_rede(self):
        return cf._b64d(self.cofre_rede().decifrar(self.b.obter('chave_rede')))

    def _reservar_tentativa(self, chave, ip):
        """Conta antes do scrypt: pedidos simultâneos não passam do limite."""
        agora = time.time()
        with self.trava:
            if len(self.tentativas) > 10000:
                self.tentativas = {k: v for k, v in self.tentativas.items() if v and agora - v[-1] < 300}
            por_login = [t for t in self.tentativas.get(chave, []) if agora - t < 300]
            por_ip = [t for t in self.tentativas.get(ip, []) if agora - t < 300]
            if len(por_login) >= 5 or len(por_ip) >= 30:
                raise servico.Erro('muitas tentativas; aguarde 5 minutos', 429)
            self.tentativas[chave] = por_login + [agora]
            self.tentativas[ip] = por_ip + [agora]

    def entrar(self, login, senha, ip, aparelho):
        chave = f'{ip}|{str(login).lower()}'
        self._reservar_tentativa(chave, ip)
        u = self.b.um('SELECT * FROM usuario WHERE login=? AND ativo=1', str(login))
        guardado = u['senha'] if u else self.hash_falso
        with self.vagas_scrypt:
            certo = cf.conferir_senha(str(senha), guardado)
        if not certo or not u:
            with self.b.transacao() as c:
                self.b.auditar(c, None, 'falha_login', 'sessao', str(login)[:60], 'acesso ao sistema', ip)
            raise servico.Erro('login ou senha incorretos', 401)
        with self.trava:
            self.tentativas.pop(chave, None)
        token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(24)
        with self.b.transacao() as c:
            c.execute('DELETE FROM sessao WHERE visto_em<?', (time.time() - SESSAO_S,))
            c.execute('INSERT INTO sessao VALUES (?,?,?,?,?,?)', (cf.hash_token(token), u['id'], csrf, time.time(), time.time(), aparelho[:80]))
            self.b.auditar(c, dict(u), 'entrar', 'sessao', u['id'], 'acesso ao sistema', ip)
        return token, csrf, self.publico(u)

    @staticmethod
    def publico(u):
        return {'id': u['id'], 'login': u['login'], 'nome': u['nome'], 'papel': u['papel'], 'pessoa_id': u['pessoa_id'], 'trocar_senha': u['trocar_senha']}

    def sessao(self, token):
        if not token:
            return None, None
        l = self.b.um("""SELECT s.csrf, s.visto_em, u.* FROM sessao s JOIN usuario u ON u.id=s.usuario_id WHERE s.token_hash=? AND u.ativo=1""", cf.hash_token(token))
        if not l or time.time() - l['visto_em'] > SESSAO_S:
            return None, None
        return self.publico(l), l['csrf']

    def criar_usuario(self, dados, ator):
        servico.exigir(ator, 'direcao')
        papel = dados.get('papel')
        if papel not in ('direcao', 'secretaria', 'professor', 'coordenacao', 'aluno', 'responsavel', 'rede'):
            raise servico.Erro('papel inválido')
        if papel in ('aluno', 'responsavel') and not dados.get('pessoa_id'):
            raise servico.Erro('escolha a pessoa ligada a este acesso')
        senha = secrets.token_urlsafe(9)
        with self.b.transacao() as c:
            try:
                cur = c.execute('INSERT INTO usuario (login,nome,papel,senha,pessoa_id,trocar_senha,criado_em) VALUES (?,?,?,?,?,1,?)',
                                (str(dados['login']).strip(), str(dados['nome']).strip(), papel, cf.hash_senha(senha), dados.get('pessoa_id'), bd.agora()))
            except bd.sqlite3.IntegrityError as e:
                raise servico.Erro('login já existe') from e
            self.b.auditar(c, ator, 'criar', 'usuario', cur.lastrowid, 'gestão de acesso', papel)
        return {'id': cur.lastrowid, 'senha_provisoria': senha}

    def alterar_acesso(self, usuario_id, ativo, ator):
        servico.exigir(ator, 'direcao')
        if usuario_id == ator['id'] and not ativo:
            raise servico.Erro('você não pode desativar o próprio acesso')
        with self.b.transacao() as c:
            if not c.execute('UPDATE usuario SET ativo=? WHERE id=?', (1 if ativo else 0, usuario_id)).rowcount:
                raise servico.Erro('usuário não encontrado', 404)
            c.execute('DELETE FROM sessao WHERE usuario_id=?', (usuario_id,))
            self.b.auditar(c, ator, 'ativar' if ativo else 'desativar', 'usuario', usuario_id, 'gestão de acesso')
        return {'ok': True}

    def redefinir_senha(self, usuario_id, ator):
        servico.exigir(ator, 'direcao')
        senha = secrets.token_urlsafe(9)
        with self.b.transacao() as c:
            if not c.execute('UPDATE usuario SET senha=?, trocar_senha=1 WHERE id=?', (cf.hash_senha(senha), usuario_id)).rowcount:
                raise servico.Erro('usuário não encontrado', 404)
            c.execute('DELETE FROM sessao WHERE usuario_id=?', (usuario_id,))
            self.b.auditar(c, ator, 'redefinir', 'usuario', usuario_id, 'gestão de acesso')
        return {'senha_provisoria': senha}

    def revogar_token(self, token_id, ator):
        servico.exigir(ator, 'direcao')
        with self.b.transacao() as c:
            if not c.execute('UPDATE token_api SET ativo=0 WHERE id=?', (token_id,)).rowcount:
                raise servico.Erro('chave não encontrada', 404)
            self.b.auditar(c, ator, 'revogar', 'token_api', token_id, 'integração')
        return {'ok': True}

    def gravar_regras(self, dados, ator):
        servico.exigir(ator, 'direcao')
        atuais = regras.configurar(self.b.obter('regras', {}))
        novas = dict(atuais)
        for chave, valor in dados.items():
            if chave not in regras.PADRAO:
                continue
            novas[chave] = bool(valor) if isinstance(regras.PADRAO[chave], bool) else regras.numero_finito(valor, 0)
        self.b.gravar('regras', novas)
        mudou = {k: (atuais[k], v) for k, v in novas.items() if atuais[k] != v}
        with self.b.transacao() as c:
            self.b.auditar(c, ator, 'regras', 'config', 'regras', 'regras da rede', json.dumps(mudou, ensure_ascii=False))
        return {'ok': True}

    def trocar_senha(self, usuario, atual, nova):
        u = self.b.um('SELECT * FROM usuario WHERE id=?', usuario['id'])
        if not cf.conferir_senha(str(atual), u['senha']):
            raise servico.Erro('senha atual incorreta', 401)
        if nova == atual:
            raise servico.Erro('a nova senha precisa ser diferente da atual')
        self.validar_senha(nova, u['login'])
        with self.b.transacao() as c:
            c.execute('UPDATE usuario SET senha=?, trocar_senha=0 WHERE id=?', (cf.hash_senha(nova), u['id']))
            c.execute('DELETE FROM sessao WHERE usuario_id=?', (u['id'],))
            self.b.auditar(c, usuario, 'senha', 'usuario', u['id'], 'gestão de acesso')
        return {'ok': True}

    def pasta_backup(self):
        return self.b.obter('backup_pasta') or os.path.join(self.dados, 'backups')

    def fazer_backup(self, usuario=None):
        try:
            arquivo = backup.gerar(self.b.caminho, self.pasta_backup(), self.chave, self.b.obter('envelope'))
        except Exception as e:
            self.b.gravar('backup_erro', {'quando': bd.agora(), 'erro': str(e)[:200]})
            raise
        self.b.gravar('backup_erro', None)
        nuvem = self.b.obter('backup_webdav')
        enviado = None
        if nuvem:
            enviado = backup.enviar_webdav(arquivo, nuvem['url'], nuvem['usuario'], self.cofre.decifrar(nuvem['senha']))
        with self.b.transacao() as c:
            self.b.auditar(c, usuario, 'backup', 'banco', os.path.basename(arquivo), 'cópia de segurança', f'nuvem={enviado}')
        self.b.gravar('backup_ultimo', {'arquivo': os.path.basename(arquivo), 'quando': bd.agora(), 'nuvem': enviado})
        return {'arquivo': os.path.basename(arquivo), 'nuvem': enviado}

    def token_escopos(self, token):
        l = self.b.um('SELECT * FROM token_api WHERE token_hash=? AND ativo=1', cf.hash_token(token))
        if not l:
            return None
        with self.b.transacao() as c:
            c.execute('UPDATE token_api SET ultimo_uso=? WHERE id=?', (bd.agora(), l['id']))
        return {'id': None, 'login': f'api:{l["nome"]}', 'nome': l['nome'], 'papel': 'secretaria', 'pessoa_id': None, 'escopos': l['escopos'].split(',')}

    def criar_token(self, nome, escopos, usuario):
        servico.exigir(usuario, 'direcao')
        if not escopos or any(e not in ESCOPOS for e in escopos):
            raise servico.Erro('escopo inválido')
        token = cf.token_api()
        with self.b.transacao() as c:
            c.execute('INSERT INTO token_api (nome,token_hash,escopos,criado_em) VALUES (?,?,?,?)', (str(nome).strip(), cf.hash_token(token), ','.join(escopos), bd.agora()))
            self.b.auditar(c, usuario, 'criar', 'token_api', nome, 'integração', ','.join(escopos))
        return {'token': token}


def nome_seguro(texto):
    return re.sub(r'[^A-Za-z0-9._-]+', '-', texto)


class Manipulador(BaseHTTPRequestHandler):
    server_version = 'ESCOLA-ERP'
    sys_version = ''
    protocol_version = 'HTTP/1.1'
    timeout = 60

    def log_message(self, formato, *args):
        pass

    def finish(self):
        try:
            super().finish()
        finally:
            self.app.b.fechar()

    @property
    def app(self):
        return self.server.app

    def _cabecalhos(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        if self.server.tls:
            self.send_header('Strict-Transport-Security', 'max-age=31536000')

    def _enviar(self, codigo, corpo, tipo='application/json; charset=utf-8', extras=()):
        self.send_response(codigo)
        self.send_header('Content-Type', tipo)
        self.send_header('Content-Length', str(len(corpo)))
        self.send_header('Cache-Control', 'no-store')
        self._cabecalhos()
        for k, v in extras:
            self.send_header(k, v)
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(corpo)

    def _json(self, dados, codigo=200, extras=()):
        self._enviar(codigo, json.dumps(dados, ensure_ascii=False).encode('utf-8'), extras=extras)

    def _arquivo(self, conteudo, nome, tipo):
        self._enviar(200, conteudo, tipo, (('Content-Disposition', f'attachment; filename="{nome_seguro(nome)}"'),))

    def _html(self, texto):
        self._enviar(200, texto.encode('utf-8'), 'text/html; charset=utf-8')

    def _corpo(self):
        self.corpo_lido = True
        try:
            tamanho = int(self.headers.get('Content-Length') or 0)
        except ValueError:
            tamanho = -1
        if tamanho < 0:
            self.close_connection = True
            raise servico.Erro('tamanho inválido')
        if tamanho > LIMITE_CORPO:
            self.close_connection = True
            raise servico.Erro('envio grande demais', 413)
        return self.rfile.read(tamanho) if tamanho else b''

    def _sem_csrf(self):
        """Rotas sem sessão: exige JSON e mesma origem, para página externa não conseguir chamar."""
        tipo = (self.headers.get('Content-Type') or '').split(';')[0].strip().lower()
        if tipo != 'application/json':
            raise servico.Erro('envie application/json', 415)
        origem = self.headers.get('Origin')
        if origem and urlparse(origem).netloc != self.headers.get('Host'):
            raise servico.Erro('origem não permitida', 403)

    def _dados(self):
        bruto = self._corpo()
        if not bruto:
            return {}
        try:
            dados = json.loads(bruto)
        except ValueError:
            raise servico.Erro('JSON inválido') from None
        if not isinstance(dados, dict):
            raise servico.Erro('JSON inválido')
        return dados

    def _cookie(self):
        try:
            c = http.cookies.SimpleCookie(self.headers.get('Cookie') or '')
        except http.cookies.CookieError:
            return ''
        return c['escola_s'].value if 'escola_s' in c else ''

    def _local(self):
        return self.client_address[0] in ('127.0.0.1', '::1') and not self.server.tls and not self.app.hospedado

    def _ip(self):
        if self.app.hospedado:
            return (self.headers.get('X-Forwarded-For') or '').split(',')[-1].strip() or self.client_address[0]
        return self.client_address[0]

    def _host_valido(self):
        if self.server.tls or self.app.hospedado:
            return True
        return (self.headers.get('Host') or '').split(':')[0] in ('127.0.0.1', 'localhost')

    def _usuario(self, escrita):
        usuario, csrf = self.app.sessao(self._cookie())
        if not usuario:
            raise servico.Erro('entre novamente', 401)
        if escrita and not secrets.compare_digest(self.headers.get('X-CSRF') or '', csrf):
            raise servico.Erro('sessão inválida; recarregue a página', 403)
        return usuario

    def _executar(self, metodo):
        self.corpo_lido = False
        try:
            self._rotear(metodo)
        finally:
            if metodo != 'GET' and not self.corpo_lido:
                self.close_connection = True

    def _rotear(self, metodo):
        url = urlparse(self.path)
        partes = [p for p in url.path.split('/') if p]
        consulta = {k: v[0] for k, v in parse_qs(url.query).items()}
        try:
            if not self._host_valido():
                raise servico.Erro('endereço não permitido', 403)
            if partes[:2] == ['api', 'v1']:
                return self._api_v1(metodo, partes[2:], consulta)
            if partes[:1] == ['api']:
                return self._api(metodo, partes[1:], consulta)
            if metodo == 'GET':
                return self._estatico(url.path)
            raise servico.Erro('não encontrado', 404)
        except servico.Erro as e:
            self._json({'erro': str(e)}, e.args and e.codigo or 400)
        except (KeyError, TypeError, ValueError) as e:
            self._json({'erro': f'pedido inválido: {e}'}, 400)
        except (BrokenPipeError, ConnectionResetError, socket.timeout):
            self.close_connection = True
        except Exception:
            traceback.print_exc()
            self._json({'erro': 'erro interno'}, 500)

    def do_GET(self):
        self._executar('GET')

    do_HEAD = do_GET

    def do_POST(self):
        self._executar('POST')

    def do_PUT(self):
        self._executar('PUT')

    def _estatico(self, caminho):
        relativo = 'index.html' if caminho in ('/', '') else caminho.lstrip('/')
        final = os.path.realpath(os.path.join(WEB, relativo))
        if not final.startswith(os.path.realpath(WEB) + os.sep) or not os.path.isfile(final):
            raise servico.Erro('não encontrado', 404)
        with open(final, 'rb') as f:
            conteudo = f.read()
        tipo = mimetypes.guess_type(final)[0] or 'application/octet-stream'
        if tipo.startswith('text/') or tipo.endswith('javascript'):
            tipo += '; charset=utf-8'
        self._enviar(200, conteudo, tipo)

    def _entrar(self, dados):
        token, csrf, usuario = self.app.entrar(dados.get('login', ''), dados.get('senha', ''), self._ip(), self.headers.get('User-Agent') or '')
        segura = '; Secure' if self.server.tls or self.app.hospedado else ''
        cookie = f'escola_s={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSAO_S}{segura}'
        self._json({'usuario': usuario, 'csrf': csrf}, extras=(('Set-Cookie', cookie),))

    def _api(self, metodo, p, q):
        a = self.app
        if p == ['estado'] and metodo == 'GET':
            usuario, csrf = a.sessao(self._cookie())
            return self._json({'configurado': a.configurado(), 'local': self._local(), 'versao': VERSAO, 'usuario': usuario, 'csrf': csrf,
                               'escola': a.b.obter('escola', {}).get('nome', ''), 'credito': CREDITO})
        if p == ['instalar'] and metodo == 'POST':
            if not self._local():
                raise servico.Erro('a configuração inicial só pode ser feita neste computador', 403)
            self._sem_csrf()
            return self._json(a.instalar(self._dados()))
        if p == ['entrar'] and metodo == 'POST':
            self._sem_csrf()
            return self._entrar(self._dados())
        if p == ['verificar'] and metodo == 'GET':
            return self._json({'documento': a.doc.verificar(q.get('codigo', ''))})
        escrita = metodo != 'GET'
        u = self._usuario(escrita)
        rota = '/'.join(p)
        if p == ['sair'] and escrita:
            with a.b.transacao() as c:
                c.execute('DELETE FROM sessao WHERE token_hash=?', (cf.hash_token(self._cookie()),))
            return self._json({'ok': True}, extras=(('Set-Cookie', 'escola_s=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict'),))
        if p == ['senha'] and escrita:
            d = self._dados()
            return self._json(a.trocar_senha(u, d.get('atual', ''), d.get('nova', '')))
        if u.get('trocar_senha'):
            raise servico.Erro('troque a senha provisória antes de continuar', 428)
        if metodo == 'GET':
            return self._get(p, q, u)
        d = None
        if not (p[:1] == ['pacote-rede'] and len(p) > 1 and p[1] == 'importar'):
            if p != ['ponto', 'afd']:
                d = self._dados()
        return self._post(rota, p, d, u)

    def _get(self, p, q, u):
        a, e = self.app, self.app.e
        rota = p[0] if p else ''
        if rota == 'painel':
            return self._json(e.painel(u))
        if rota == 'portal':
            return self._json(e.portal(u))
        if rota == 'turmas-minhas':
            return self._json(e.minhas_turmas(u))
        if rota == 'chamada':
            return self._json(e.chamada(int(q['tc']), q['data'], u))
        if rota == 'alunos-turma':
            e.exigir_turma(u, int(q['turma']))
            return self._json(e.alunos_da_turma(int(q['turma'])))
        if rota == 'boletim':
            return self._json(e.boletim(int(q['matricula']), u))
        if rota == 'frequencia-painel':
            return self._json(e.painel_frequencia(u, int(q['turma']) if q.get('turma') else None))
        if rota == 'pedidos':
            return self._json(e.pedidos(u))
        if rota == 'trilha':
            return self._json(e.trilha(u))
        if rota == 'usuarios':
            servico.exigir(u, 'direcao')
            return self._json(a.b.todos('SELECT id,login,nome,papel,ativo FROM usuario ORDER BY nome'))
        if rota == 'tokens':
            servico.exigir(u, 'direcao')
            return self._json(a.b.todos('SELECT id,nome,escopos,criado_em,ultimo_uso FROM token_api WHERE ativo=1 ORDER BY id'))
        if rota == 'pessoa' and len(p) == 2:
            return self._json(e.ler_pessoa(int(p[1]), u))
        if rota == 'avaliacoes':
            servico.exigir(u, *servico.PAPEIS_EQUIPE)
            e._turma_componente(int(q['tc']), u)
            return self._json(a.b.todos('SELECT * FROM avaliacao WHERE turma_componente_id=? ORDER BY id', int(q['tc'])))
        if rota == 'notas':
            return self._json(e.notas_da_avaliacao(int(q['avaliacao']), u))
        if rota == 'metadados':
            return self._json(e.metadados(u))
        if rota == 'atualizacao':
            servico.exigir(u, 'direcao')
            return self._json(a.atu.resumo())
        if rota == 'emprestimos':
            servico.exigir(u, *servico.ADMIN, 'coordenacao')
            return self._json(a.b.todos("""SELECT em.id, ac.titulo, p.nome, em.retirada, em.prazo FROM emprestimo em JOIN acervo ac ON ac.id=em.acervo_id
                                          JOIN pessoa p ON p.id=em.pessoa_id WHERE em.devolucao IS NULL ORDER BY em.retirada"""))
        if rota == 'config':
            servico.exigir(u, 'direcao')
            ult = a.b.obter('backup_ultimo')
            return self._json({'escola': a.b.obter('escola', {}), 'regras': e.cfg(), 'backup_pasta': a.pasta_backup(), 'backup_ultimo': ult,
                               'backup_erro': a.b.obter('backup_erro'), 'auditoria_ok': a.b.conferir_auditoria() is None,
                               'chave_rede': cf._b64e(a.chave_rede()), 'backups': backup.listar(a.pasta_backup())[:10], 'libreoffice': bool(documentos.libreoffice()), 'endereco_lan': a.b.obter('endereco_lan')})
        if rota == 'censo-conferencia':
            return self._json(a.of.conferencia_censo(u))
        if rota == 'documento':
            return self._documento(p[1], q, u)
        if rota == 'exportar':
            return self._exportar(p[1], q, u)
        if rota in servico.RECURSOS:
            filtros = {k: v for k, v in q.items()}
            return self._json(e.listar(rota, u, filtros))
        raise servico.Erro('não encontrado', 404)

    def _documento(self, tipo, q, u):
        d, e = self.app.doc, self.app.e
        servico.exigir(u, *servico.PAPEIS_EQUIPE, 'aluno', 'responsavel')
        if tipo != 'boletim':
            servico.exigir(u, *servico.PAPEIS_EQUIPE)
        if tipo in ('declaracao', 'historico', 'ata'):
            servico.exigir(u, *servico.PAPEIS_GESTAO)
        if tipo == 'boletim':
            texto = d.boletim(int(q['matricula']), u)
        elif tipo == 'declaracao':
            texto = d.declaracao(int(q['matricula']), u)
        elif tipo == 'ata':
            texto = d.ata_resultados(int(q['turma']), u)
        elif tipo == 'historico':
            texto = d.historico(int(q['aluno']), u)
        elif tipo == 'diario':
            texto = d.diario(int(q['tc']), u)
        else:
            raise servico.Erro('documento desconhecido', 404)
        formato = q.get('formato', 'html')
        if formato == 'odt':
            return self._arquivo(documentos.para_odt(texto), f'{tipo}.odt', 'application/vnd.oasis.opendocument.text')
        if formato == 'pdf':
            pdf = documentos.para_pdf(texto)
            if pdf is None:
                raise servico.Erro('instale o LibreOffice para gerar PDF aqui, ou imprima em PDF pelo navegador', 501)
            return self._arquivo(pdf, f'{tipo}.pdf', 'application/pdf')
        return self._html(texto)

    def _exportar(self, tipo, q, u):
        of = self.app.of
        hoje = dt.date.today()
        if tipo in ('frequencia-mensal', 'presenca', 'moodle'):
            with self.app.b.transacao() as c:
                self.app.b.auditar(c, u, 'exportar', tipo, str(hoje), 'envio a sistema oficial ou integração')
        if tipo == 'frequencia-mensal':
            linhas = of.frequencia_mensal(int(q.get('ano', hoje.year)), int(q.get('mes', hoje.month)), u)
            return self._arquivo(oficial.xlsx('Frequencia', linhas), 'frequencia-mensal.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        if tipo == 'presenca':
            linhas = of.lista_presenca(q['de'], q['ate'], u)
            return self._arquivo(oficial.csv_de(linhas), 'sistema-presenca.csv', 'text/csv; charset=utf-8')
        if tipo == 'moodle':
            return self._arquivo(oficial.csv_moodle(of, u), 'moodle-usuarios.csv', 'text/csv; charset=utf-8')
        if tipo == 'oneroster':
            return self._arquivo(of.oneroster(u), 'oneroster.zip', 'application/zip')
        if tipo == 'pacote-rede':
            return self._arquivo(of.pacote_rede(u, self.app.chave_rede()), f'pacote-rede-{hoje}.escola', 'application/octet-stream')
        raise servico.Erro('exportação desconhecida', 404)

    def _post(self, rota, p, d, u):
        a, e = self.app, self.app.e
        if rota == 'matricular':
            return self._json(e.matricular(int(d['aluno_id']), int(d['turma_id']), u, d.get('entrada')))
        if rota == 'saida':
            return self._json(e.sair(int(d['matricula_id']), d['situacao'], u, d.get('escola_outra', ''), d.get('data')))
        if rota == 'remanejar':
            return self._json(e.remanejar(int(d['matricula_id']), int(d['turma_id']), u))
        if rota == 'desvincular':
            return self._json(e.desvincular(int(d['aluno_id']), int(d['responsavel_id']), u))
        if rota == 'periodo/fechar':
            return self._json(e.fechar_periodo(int(d['id']), bool(d.get('fechado', True)), u))
        if rota == 'ano/encerrar':
            return self._json(e.encerrar_ano(int(d['id']), u))
        if rota == 'usuario/ativo':
            return self._json(a.alterar_acesso(int(d['id']), bool(d['ativo']), u))
        if rota == 'usuario/senha':
            return self._json(a.redefinir_senha(int(d['id']), u))
        if rota == 'token/revogar':
            return self._json(a.revogar_token(int(d['id']), u))
        if rota == 'vincular':
            return self._json(e.vincular(int(d['aluno_id']), int(d['responsavel_id']), d.get('parentesco', 'responsável'), u))
        if rota == 'chamada':
            return self._json(e.registrar_aula(d, u, self.headers.get('User-Agent') or ''))
        if rota == 'chamada/lote':
            resultados = []
            for item in d.get('eventos', [])[:200]:
                try:
                    resultados.append({'uid': item.get('uid'), **e.registrar_aula(item, u, self.headers.get('User-Agent') or '')})
                except servico.Erro as x:
                    resultados.append({'uid': item.get('uid'), 'erro': str(x)})
            return self._json({'resultados': resultados})
        if rota == 'movimentar':
            return self._json(e.movimentar(d, u))
        if rota == 'emprestar':
            return self._json(e.emprestar(d, u))
        if rota == 'devolver':
            return self._json(e.devolver(int(d['id']), u))
        if rota == 'atualizacao/verificar':
            servico.exigir(u, 'direcao')
            return self._json(a.atu.verificar(baixar=True))
        if rota == 'atualizacao/instalar':
            servico.exigir(u, 'direcao')
            if not a.atu.pode_aplicar():
                raise servico.Erro('não há atualização pronta')
            self._json({'ok': True, 'reiniciando': True})
            threading.Timer(1, reiniciar).start()
            return None
        if rota == 'validar-aulas':
            return self._json(e.validar_aulas(int(d['tc']), d['ate'], u))
        if rota == 'pedido':
            return self._json(e.decidir_pedido(int(d['id']), bool(d['aprovar']), u))
        if rota == 'avaliacao':
            return self._json(e.criar_avaliacao(d, u))
        if rota == 'notas':
            return self._json(e.lancar_notas(int(d['avaliacao_id']), d['notas'], u))
        if rota == 'parecer':
            return self._json(e.gravar_parecer(d, u))
        if rota == 'conselho':
            return self._json(e.decidir_conselho(d, u))
        if rota == 'usuario':
            return self._json(a.criar_usuario(d, u))
        if rota == 'token':
            return self._json(a.criar_token(d.get('nome', ''), d.get('escopos', []), u))
        if rota == 'anonimizar':
            return self._json(e.anonimizar(int(d['pessoa_id']), d.get('motivo', ''), u))
        if rota == 'backup':
            servico.exigir(u, 'direcao', 'secretaria')
            return self._json(a.fazer_backup(u))
        if rota == 'censo/foto':
            return self._json(a.of.fotografar_censo(int(d['ano']), d['data'], u))
        if rota == 'config/regras':
            return self._json(a.gravar_regras(d, u))
        if rota == 'config/chave-rede':
            servico.exigir(u, 'direcao')
            chave = cf._b64d(str(d.get('chave', '')))
            if len(chave) != 32:
                raise servico.Erro('chave da rede inválida')
            a.gravar_chave_rede(chave)
            with a.b.transacao() as c:
                a.b.auditar(c, u, 'chave', 'config', 'chave_rede', 'integração com a rede')
            return self._json({'ok': True})
        if rota == 'config/backup':
            servico.exigir(u, 'direcao')
            if d.get('pasta'):
                a.b.gravar('backup_pasta', str(d['pasta']))
            if d.get('webdav_url'):
                a.b.gravar('backup_webdav', {'url': d['webdav_url'], 'usuario': d.get('webdav_usuario', ''), 'senha': a.cofre.cifrar(d.get('webdav_senha', ''))})
            return self._json({'ok': True})
        if rota == 'pacote-rede/importar':
            bruto = self._corpo()
            return self._json(a.of.importar_pacote(bruto, u, a.chave_rede()))
        if rota == 'ponto/afd':
            return self._json(a.of.importar_afd(self._corpo().decode('latin-1'), u))
        if len(p) == 1 and p[0] in servico.RECURSOS:
            return self._json(e.criar(p[0], d, u), 201)
        if len(p) == 2 and p[0] in servico.RECURSOS:
            return self._json(e.alterar(p[0], p[1], d, u))
        raise servico.Erro('não encontrado', 404)

    def _api_v1(self, metodo, p, q):
        a = self.app
        if p == ['openapi.json']:
            return self._json(OPENAPI)
        cabecalho = self.headers.get('Authorization') or ''
        ator = a.token_escopos(cabecalho[7:].strip()) if cabecalho.startswith('Bearer ') else None
        if not ator:
            raise servico.Erro('token inválido', 401)

        def exige(escopo):
            if escopo not in ator['escopos']:
                raise servico.Erro(f'token sem o escopo {escopo}', 403)

        rota = '/'.join(p)
        if metodo == 'GET':
            if rota == 'status':
                return self._json({'versao': VERSAO, 'escola': a.b.obter('escola', {}).get('nome', '')})
            if rota == 'sinais':
                exige('sinal')
                return self._json(a.b.todos('SELECT hora, descricao, duracao_s, dias FROM sinal WHERE ativo=1 ORDER BY hora'))
            exige('leitura')
            if rota == 'turmas':
                return self._json(a.b.todos('SELECT t.id, t.nome, t.etapa, t.turno FROM turma t JOIN ano_letivo l ON l.id=t.ano_id WHERE l.encerrado=0 ORDER BY t.nome'))
            if rota == 'matriculas':
                return self._json(a.b.todos("""SELECT m.id, m.codigo, m.turma_id, m.numero, m.situacao, p.nome FROM matricula m JOIN pessoa p ON p.id=m.aluno_id
                                               WHERE m.turma_id=? ORDER BY m.numero""", int(q['turma'])))
            if rota == 'calendario':
                return self._json(a.b.todos('SELECT data, tipo, descricao FROM dia_calendario ORDER BY data'))
        if metodo == 'POST':
            if rota == 'frequencia':
                exige('frequencia')
                return self._json(a.e.registrar_aula(self._dados(), ator, 'api'))
            if rota == 'conteudo':
                exige('conteudo')
                return self._json(a.e.publicar_conteudo(self._dados(), ator), 201)
            if rota == 'ponto/afd':
                exige('ponto')
                return self._json(a.of.importar_afd(self._corpo().decode('latin-1'), ator))
        raise servico.Erro('não encontrado', 404)


OPENAPI = {'openapi': '3.0.3', 'info': {'title': 'ESCOLA-ERP API', 'version': '1'},
           'components': {'securitySchemes': {'token': {'type': 'http', 'scheme': 'bearer'}}}, 'security': [{'token': []}],
           'paths': {'/api/v1/status': {'get': {'summary': 'Versão e nome da escola'}},
                     '/api/v1/turmas': {'get': {'summary': 'Turmas do ano aberto (escopo leitura)'}},
                     '/api/v1/matriculas': {'get': {'summary': 'Alunos de uma turma: ?turma=ID (escopo leitura)'}},
                     '/api/v1/calendario': {'get': {'summary': 'Calendário escolar (escopo leitura)'}},
                     '/api/v1/sinais': {'get': {'summary': 'Horários do sinal (escopo sinal)'}},
                     '/api/v1/frequencia': {'post': {'summary': 'Registra chamada; idempotente por uid (escopo frequencia)'}},
                     '/api/v1/conteudo': {'post': {'summary': 'Publica conteúdo por turma e componente, para hospedagem (escopo conteudo)'}},
                     '/api/v1/ponto/afd': {'post': {'summary': 'Importa arquivo AFD (escopo ponto)'}}}}


class Servidor(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 64

    def __init__(self, endereco, app, contexto=None):
        self.app = app
        self.tls = contexto is not None
        super().__init__(endereco, Manipulador)
        if contexto:
            self.socket = contexto.wrap_socket(self.socket, server_side=True, do_handshake_on_connect=False)

    def handle_error(self, request, client_address):
        pass


def contexto_tls(app):
    ips = celular.ips_locais() or ['127.0.0.1']
    return celular.preparar_certificado(os.path.join(app.dados, 'tls'), ips)[0]


def reiniciar():
    os.execv(sys.executable, [sys.executable, *sys.argv])


def rotina_atualizacao(app, parar):
    while not parar.wait(atualizacao.INTERVALO_VERIFICACAO):
        if app.atu.automatica:
            try:
                app.atu.verificar(baixar=True)
            except (OSError, ValueError):
                pass


def rotina_backup(app, parar):
    while not parar.wait(3600):
        ultimo = app.b.obter('backup_ultimo')
        if not app.configurado() or (ultimo and ultimo['quando'][:10] == dt.date.today().isoformat()):
            continue
        try:
            app.fazer_backup()
        except Exception:
            traceback.print_exc()


def rodar(args):
    app = App(args.dados, args.hospedado)
    if app.atu.pode_aplicar():
        app.atu.aplicar()
        app.b.fechar()
        reiniciar()
    app.atu.confirmar_inicio()
    if not app.b.integro():
        print('ATENÇÃO: o banco falhou na verificação. Restaure o último backup.', file=sys.stderr)
    adulterada = app.b.conferir_auditoria()
    if adulterada is not None:
        print(f'ATENÇÃO: trilha de auditoria alterada a partir da linha {adulterada}.', file=sys.stderr)
    if args.hospedado and args.lan:
        print('Use --hospedado sem --lan: a porta da rede ficaria exposta sem o proxy.', file=sys.stderr)
        return
    servidores = []
    host = '127.0.0.1'
    if args.hospedado and not app.configurado():
        print('Rode primeiro: escola.py configurar', file=sys.stderr)
        return
    servidores.append(Servidor((host, args.porta), app))
    print(f'ESCOLA-ERP {VERSAO}: http://{host}:{args.porta}/', flush=True)
    if args.lan:
        lan = Servidor(('0.0.0.0', args.porta_lan), app, contexto_tls(app))
        servidores.append(lan)
        for ip in celular.ips_locais():
            print(f'Celulares na rede: https://{ip}:{args.porta_lan}/', flush=True)
        app.b.gravar('endereco_lan', [f'https://{ip}:{args.porta_lan}/' for ip in celular.ips_locais()])
    parar = threading.Event()
    threading.Thread(target=rotina_backup, args=(app, parar), daemon=True).start()
    threading.Thread(target=rotina_atualizacao, args=(app, parar), daemon=True).start()
    for s in servidores[1:]:
        threading.Thread(target=s.serve_forever, daemon=True).start()
    try:
        servidores[0].serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        parar.set()


def restaurar(args):
    if em_uso(PORTA_LOCAL):
        raise SystemExit('Pare o ESCOLA-ERP antes de restaurar.')
    codigo = args.codigo or getpass.getpass('Código de recuperação: ')
    chave = backup.chave_do_backup(args.arquivo, codigo)
    os.makedirs(args.dados, exist_ok=True)
    backup.restaurar(args.arquivo, chave, os.path.join(args.dados, 'escola.db'))
    caminho = os.path.join(args.dados, 'escola.chave')
    if os.path.exists(caminho):
        os.replace(caminho, caminho + '.antiga')
    descritor = os.open(caminho, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descritor, 'wb') as f:
        f.write(chave)
    print('Banco restaurado.')


def configurar(args):
    app = App(args.dados)
    if app.configurado():
        print('Escola já configurada.')
        return
    r = app.instalar({'nome_escola': input('Nome da escola: '), 'rede': input('Rede: '), 'inep': input('Código INEP: '), 'nome': input('Seu nome: '),
                      'login': input('Login: '), 'senha': getpass.getpass('Senha: ')})
    print('Guarde o código de recuperação:', r['codigo_recuperacao'])


def verificar():
    faltando = [n for n in ('web/index.html', 'web/app.js', 'web/app.css') if not os.path.isfile(os.path.join(BASE_DIR, n))]
    print('VERIFICACAO-FALHOU: ' + ', '.join(faltando) if faltando else f'VERIFICACAO-OK {VERSAO}')
    sys.exit(1 if faltando else 0)


def em_uso(porta):
    with socket.socket() as s:
        s.settimeout(1)
        return s.connect_ex(('127.0.0.1', porta)) == 0


def pasta_padrao():
    if os.name == 'nt':
        return os.path.join(os.environ.get('LOCALAPPDATA', BASE_DIR), 'EscolaERP', 'dados')
    return os.path.join(os.path.expanduser('~'), '.local', 'share', 'escola-erp')


def principal():
    p = argparse.ArgumentParser(description=f'ESCOLA-ERP {VERSAO}. {CREDITO}')
    p.add_argument('--dados', default=os.environ.get('ESCOLA_ERP_DADOS') or pasta_padrao())
    p.add_argument('--verificar', action='store_true', help='confere os arquivos do programa e sai')
    p.add_argument('--abrir', action='store_true', help='abre o navegador e inicia o servidor, se ainda não estiver no ar')
    sub = p.add_subparsers(dest='comando')
    r = sub.add_parser('rodar')
    r.add_argument('--porta', type=int, default=PORTA_LOCAL)
    r.add_argument('--porta-lan', type=int, default=PORTA_LAN)
    r.add_argument('--lan', action='store_true', help='libera celulares e computadores da rede por HTTPS')
    r.add_argument('--hospedado', action='store_true', help='atrás de proxy HTTPS, para hospedagem')
    x = sub.add_parser('restaurar')
    x.add_argument('arquivo')
    x.add_argument('--codigo', default='')
    sub.add_parser('versao')
    sub.add_parser('configurar')
    args = p.parse_args()
    if args.verificar:
        return verificar()
    if args.comando == 'configurar':
        return configurar(args)
    if args.comando == 'restaurar':
        return restaurar(args)
    if args.comando == 'versao':
        print(VERSAO)
        return None
    if args.comando is None:
        if args.abrir:
            threading.Timer(1.5, webbrowser.open, (f'http://127.0.0.1:{PORTA_LOCAL}/',)).start()
            if em_uso(PORTA_LOCAL):
                return None
        args = p.parse_args(['--dados', args.dados, 'rodar', '--lan'])
    return rodar(args)


if __name__ == '__main__':
    if os.name != 'nt':
        os.umask(0o077)
    mimetypes.add_type('text/javascript', '.js')
    principal()
